# -*- coding: utf-8 -*-
"""
MasterKodi IL Wizard - Backup/Restore System
"""
import os
import json
import shutil
import zipfile
import xbmc
import xbmcvfs
import xbmcgui
import xbmcaddon
from datetime import datetime

from resources.libs.config import (
    ADDON_ID, ADDON_NAME, BACKUPS_FOLDER, TEMP_FOLDER, USERDATA, ADDON_DATA_PATH,
    POV_ADDON_ID, FENLIGHT_ADDON_ID, DEBRID_SERVICES, TRAKT_SETTINGS,
    GUISETTINGS, SOURCES, FAVOURITES, COLOR_SUCCESS, COLOR_ERROR, COLOR_WARNING
)


def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f'[{ADDON_ID}] Backup: {msg}', level)


class SaveDataBackup:
    def __init__(self):
        self.dialog = xbmcgui.Dialog()
        
    def read_setting(self, addon_id, setting):
        try:
            return xbmcaddon.Addon(addon_id).getSetting(setting)
        except:
            return None
    
    def write_setting(self, addon_id, setting, value):
        try:
            xbmcaddon.Addon(addon_id).setSetting(setting, value)
            return True
        except:
            return False

    def extract_debrid(self):
        data = {}
        for service, info in DEBRID_SERVICES.items():
            data[service] = {'name': info['name'], 'pov': {}, 'fenlight': {}}
            for s in info['settings']:
                v = self.read_setting(POV_ADDON_ID, s)
                if v: data[service]['pov'][s] = v
                v = self.read_setting(FENLIGHT_ADDON_ID, s)
                if v: data[service]['fenlight'][s] = v
        return data
    
    def extract_trakt(self):
        data = {'pov': {}, 'fenlight': {}}
        for s in TRAKT_SETTINGS:
            v = self.read_setting(POV_ADDON_ID, s)
            if v: data['pov'][s] = v
            v = self.read_setting(FENLIGHT_ADDON_ID, s)
            if v: data['fenlight'][s] = v
        return data

    def create_backup(self, name=None, progress_callback=None):
        try:
            if not name:
                name = f"SaveData_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            
            temp = os.path.join(TEMP_FOLDER, 'SaveData')
            if os.path.exists(temp):
                shutil.rmtree(temp)
            
            for f in ['debrid', 'trakt', 'xmls']:
                os.makedirs(os.path.join(temp, f))
            
            if progress_callback:
                progress_callback("Extracting Debrid data...", 20)
            
            debrid = self.extract_debrid()
            for service, data in debrid.items():
                if data['pov'] or data['fenlight']:
                    with open(os.path.join(temp, 'debrid', f'{service}.json'), 'w') as f:
                        json.dump(data, f, indent=2)
            
            if progress_callback:
                progress_callback("Extracting Trakt data...", 40)
            
            trakt = self.extract_trakt()
            if trakt['pov'] or trakt['fenlight']:
                with open(os.path.join(temp, 'trakt', 'trakt.json'), 'w') as f:
                    json.dump(trakt, f, indent=2)
            
            if progress_callback:
                progress_callback("Copying XML files...", 60)
            
            for src, fname in [(GUISETTINGS, 'guisettings.xml'), (SOURCES, 'sources.xml'), (FAVOURITES, 'favourites.xml')]:
                if os.path.exists(src):
                    shutil.copy2(src, os.path.join(temp, 'xmls', fname))
            
            if progress_callback:
                progress_callback("Creating ZIP...", 80)
            
            # Metadata
            with open(os.path.join(temp, 'metadata.json'), 'w') as f:
                json.dump({
                    'date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    'name': name
                }, f, indent=2)
            
            # ZIP
            zip_path = os.path.join(BACKUPS_FOLDER, f'{name}.zip')
            with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as z:
                for root, _, files in os.walk(temp):
                    for f in files:
                        fp = os.path.join(root, f)
                        z.write(fp, os.path.relpath(fp, temp))
            
            shutil.rmtree(temp)
            
            if progress_callback:
                progress_callback("Backup complete!", 100)
            
            log(f"Backup created: {zip_path}")
            return zip_path
            
        except Exception as e:
            log(f"Backup error: {e}", xbmc.LOGERROR)
            return None

    def restore_backup(self, zip_path, options=None, progress_callback=None):
        try:
            if not options:
                options = {'debrid': True, 'trakt': True, 'xmls': True}
            
            temp = os.path.join(TEMP_FOLDER, 'restore')
            if os.path.exists(temp):
                shutil.rmtree(temp)
            
            if progress_callback:
                progress_callback("Extracting backup...", 10)
            
            with zipfile.ZipFile(zip_path, 'r') as z:
                z.extractall(temp)
            
            restored = []
            
            if options.get('debrid'):
                if progress_callback:
                    progress_callback("Restoring Debrid...", 30)
                
                debrid_dir = os.path.join(temp, 'debrid')
                if os.path.exists(debrid_dir):
                    for f in os.listdir(debrid_dir):
                        if f.endswith('.json'):
                            with open(os.path.join(debrid_dir, f)) as fp:
                                data = json.load(fp)
                            for setting, val in data.get('pov', {}).items():
                                self.write_setting(POV_ADDON_ID, setting, val)
                            for setting, val in data.get('fenlight', {}).items():
                                self.write_setting(FENLIGHT_ADDON_ID, setting, val)
                            restored.append(f"Debrid: {data.get('name', f)}")
            
            if options.get('trakt'):
                if progress_callback:
                    progress_callback("Restoring Trakt...", 50)
                
                trakt_file = os.path.join(temp, 'trakt', 'trakt.json')
                if os.path.exists(trakt_file):
                    with open(trakt_file) as f:
                        data = json.load(f)
                    for setting, val in data.get('pov', {}).items():
                        self.write_setting(POV_ADDON_ID, setting, val)
                    for setting, val in data.get('fenlight', {}).items():
                        self.write_setting(FENLIGHT_ADDON_ID, setting, val)
                    restored.append("Trakt")
            
            if options.get('xmls'):
                if progress_callback:
                    progress_callback("Restoring XMLs...", 70)
                
                xmls_dir = os.path.join(temp, 'xmls')
                if os.path.exists(xmls_dir):
                    for fname, dest in [('guisettings.xml', GUISETTINGS), ('sources.xml', SOURCES), ('favourites.xml', FAVOURITES)]:
                        src = os.path.join(xmls_dir, fname)
                        if os.path.exists(src):
                            shutil.copy2(src, dest)
                            restored.append(f"XML: {fname}")
            
            shutil.rmtree(temp)
            
            if progress_callback:
                progress_callback("Restore complete!", 100)
            
            return restored
            
        except Exception as e:
            log(f"Restore error: {e}", xbmc.LOGERROR)
            return None

    def list_backups(self):
        backups = []
        if not os.path.exists(BACKUPS_FOLDER):
            return backups
        
        for f in os.listdir(BACKUPS_FOLDER):
            if f.endswith('.zip'):
                path = os.path.join(BACKUPS_FOLDER, f)
                meta = None
                try:
                    with zipfile.ZipFile(path) as z:
                        if 'metadata.json' in z.namelist():
                            meta = json.loads(z.read('metadata.json').decode())
                except:
                    pass
                
                backups.append({
                    'filename': f,
                    'path': path,
                    'size': os.path.getsize(path),
                    'date': datetime.fromtimestamp(os.path.getmtime(path)).strftime('%Y-%m-%d %H:%M'),
                    'metadata': meta
                })
        
        backups.sort(key=lambda x: x['date'], reverse=True)
        return backups

    def delete_backup(self, path):
        try:
            os.remove(path)
            return True
        except:
            return False


def backup_menu():
    backup = SaveDataBackup()
    dialog = xbmcgui.Dialog()
    progress = xbmcgui.DialogProgress()
    
    name = dialog.input("Backup Name", defaultt=f"SaveData_{datetime.now().strftime('%Y%m%d')}")
    if not name:
        return
    
    progress.create(ADDON_NAME, "Creating backup...")
    result = backup.create_backup(name, lambda m, p: progress.update(p, m))
    progress.close()
    
    if result:
        dialog.ok(ADDON_NAME, f"[COLOR {COLOR_SUCCESS}]Backup created![/COLOR]\n\n{result}")
    else:
        dialog.ok(ADDON_NAME, f"[COLOR {COLOR_ERROR}]Backup failed![/COLOR]")


def restore_menu():
    backup = SaveDataBackup()
    dialog = xbmcgui.Dialog()
    progress = xbmcgui.DialogProgress()
    
    backups = backup.list_backups()
    if not backups:
        dialog.ok(ADDON_NAME, "No backups found.")
        return
    
    items = [f"{b['filename']} ({b['size']//1024//1024:.1f}MB) - {b['date']}" for b in backups]
    sel = dialog.select("Select Backup", items)
    if sel < 0:
        return
    
    selected = backups[sel]
    
    opts = dialog.multiselect("What to restore?", 
        ["Debrid (PM, RD, ED, TB)", "Trakt", "XML Files (sources, favourites)"],
        preselect=[0, 1, 2])
    
    if opts is None:
        return
    
    options = {'debrid': 0 in opts, 'trakt': 1 in opts, 'xmls': 2 in opts}
    
    if not dialog.yesno(ADDON_NAME, 
        f"Restore {selected['filename']}?\n\nThis will replace current settings.",
        yeslabel="[B]Restore[/B]", nolabel="Cancel"):
        return
    
    progress.create(ADDON_NAME, "Restoring...")
    result = backup.restore_backup(selected['path'], options, lambda m, p: progress.update(p, m))
    progress.close()
    
    if result:
        if dialog.yesno(ADDON_NAME,
            f"[COLOR {COLOR_SUCCESS}]Restore complete![/COLOR]\n\n"
            f"Restored: {', '.join(result)}\n\nRestart Kodi now?",
            yeslabel="[B]Restart[/B]", nolabel="Later"):
            xbmc.executebuiltin('Quit')
    else:
        dialog.ok(ADDON_NAME, f"[COLOR {COLOR_ERROR}]Restore failed![/COLOR]")


def manage_backups():
    backup = SaveDataBackup()
    dialog = xbmcgui.Dialog()
    
    backups = backup.list_backups()
    if not backups:
        dialog.ok(ADDON_NAME, "No backups found.")
        return
    
    items = [f"{b['filename']} ({b['size']//1024//1024:.1f}MB)" for b in backups]
    items.append("[COLOR red]Delete All[/COLOR]")
    items.append("[COLOR gray]< Back[/COLOR]")
    
    sel = dialog.select("Manage Backups", items)
    
    if sel < 0 or sel == len(items) - 1:
        return
    
    if sel == len(items) - 2:
        if dialog.yesno(ADDON_NAME, "Delete ALL backups?"):
            for b in backups:
                backup.delete_backup(b['path'])
            dialog.ok(ADDON_NAME, "All backups deleted.")
    else:
        if dialog.yesno(ADDON_NAME, f"Delete {backups[sel]['filename']}?"):
            backup.delete_backup(backups[sel]['path'])
            dialog.ok(ADDON_NAME, "Backup deleted.")
