# -*- coding: utf-8 -*-
"""
POV Hebrew Subtitles Installer
Downloads and installs Hebrew subtitle matching files to POV
With backup/restore functionality
"""
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
import os
import json
import shutil
import hashlib
import time

try:
    from urllib.request import urlopen, Request
except ImportError:
    from urllib2 import urlopen, Request

import zipfile
import io

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_DATA = xbmcvfs.translatePath(f'special://userdata/addon_data/{ADDON_ID}')

# GitHub raw URLs for the files
GITHUB_BASE_URL = "https://raw.githubusercontent.com/asaf27064/pov-modified-heb/main"
VERSION_URL = f"{GITHUB_BASE_URL}/version.json"
ZIP_URL = f"{GITHUB_BASE_URL}/pov_hebrew_subtitles.zip"

# Backup location
BACKUP_FOLDER = os.path.join(ADDON_DATA, 'pov_backup')


def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f'[{ADDON_ID}] {msg}', level)


class POVHebrewInstaller:
    def __init__(self):
        self.pov_addon_id = 'plugin.video.pov'
        self.pov_path = None
        self.version_file = os.path.join(ADDON_DATA, 'installed_version.json')
        self.backup_folder = BACKUP_FOLDER
        self._find_pov_path()
    
    def _find_pov_path(self):
        """Find POV addon path"""
        try:
            pov_addon = xbmcaddon.Addon(self.pov_addon_id)
            self.pov_path = pov_addon.getAddonInfo('path')
            log(f"Found POV at: {self.pov_path}")
        except Exception as e:
            log(f"POV not found: {e}", xbmc.LOGWARNING)
            self.pov_path = None
    
    def is_pov_installed(self):
        """Check if POV is installed"""
        return self.pov_path is not None and os.path.exists(self.pov_path)
    
    def is_installed(self):
        """Check if Hebrew subtitles are installed"""
        if not self.is_pov_installed():
            return False
        
        # Check for key files
        kodirdil_path = os.path.join(self.pov_path, 'resources', 'lib', 'kodirdil')
        return os.path.exists(kodirdil_path)
    
    def has_backup(self):
        """Check if backup exists"""
        if not os.path.exists(self.backup_folder):
            return False
        backup_info = os.path.join(self.backup_folder, 'backup_info.json')
        return os.path.exists(backup_info)
    
    def get_backup_info(self):
        """Get backup information"""
        try:
            backup_info_file = os.path.join(self.backup_folder, 'backup_info.json')
            if os.path.exists(backup_info_file):
                with open(backup_info_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
        except Exception as e:
            log(f"Error reading backup info: {e}")
        return None
    
    def backup_pov_files(self, progress_callback=None):
        """Backup original POV files before installing
        
        Returns:
            bool: True if backup successful
        """
        if not self.is_pov_installed():
            log("POV not installed, cannot backup")
            return False
        
        try:
            # Create backup folder
            if not os.path.exists(self.backup_folder):
                os.makedirs(self.backup_folder)
            
            if progress_callback:
                progress_callback("Backing up original files...", 5)
            
            # Files to backup
            files_to_backup = [
                ('resources/lib/windows/sources.py', 'windows_sources.py'),
                ('resources/lib/modules/sources.py', 'modules_sources.py'),
                ('resources/lib/modules/source_objects.py', 'source_objects.py'),
                ('resources/settings.xml', 'settings.xml'),
                ('resources/lib/service.py', 'service.py'),
            ]
            
            backed_up_files = []
            pov_addon = xbmcaddon.Addon(self.pov_addon_id)
            pov_version = pov_addon.getAddonInfo('version')
            
            for src_rel, backup_name in files_to_backup:
                src_path = os.path.join(self.pov_path, src_rel)
                backup_path = os.path.join(self.backup_folder, backup_name)
                
                if os.path.exists(src_path):
                    shutil.copy2(src_path, backup_path)
                    backed_up_files.append({
                        'original': src_rel,
                        'backup': backup_name
                    })
                    log(f"Backed up: {src_rel}")
            
            # Save backup info
            backup_info = {
                'pov_version': pov_version,
                'backup_date': time.strftime('%Y-%m-%d %H:%M:%S'),
                'files': backed_up_files
            }
            
            with open(os.path.join(self.backup_folder, 'backup_info.json'), 'w', encoding='utf-8') as f:
                json.dump(backup_info, f, indent=2)
            
            log(f"Backup complete. POV version: {pov_version}")
            return True
            
        except Exception as e:
            log(f"Backup error: {e}", xbmc.LOGERROR)
            return False
    
    def restore_pov_files(self, progress_callback=None):
        """Restore original POV files from backup
        
        Returns:
            bool: True if restore successful
        """
        if not self.has_backup():
            log("No backup found")
            return False
        
        if not self.is_pov_installed():
            log("POV not installed")
            return False
        
        try:
            if progress_callback:
                progress_callback("Restoring original files...", 10)
            
            backup_info = self.get_backup_info()
            if not backup_info:
                return False
            
            files = backup_info.get('files', [])
            total = len(files)
            
            for i, file_info in enumerate(files):
                if progress_callback:
                    pct = 10 + int((i / total) * 80)
                    progress_callback(f"Restoring: {file_info['original']}", pct)
                
                backup_path = os.path.join(self.backup_folder, file_info['backup'])
                restore_path = os.path.join(self.pov_path, file_info['original'])
                
                if os.path.exists(backup_path):
                    # Create directory if needed
                    restore_dir = os.path.dirname(restore_path)
                    if not os.path.exists(restore_dir):
                        os.makedirs(restore_dir)
                    
                    shutil.copy2(backup_path, restore_path)
                    log(f"Restored: {file_info['original']}")
            
            # Remove kodirdil folder if exists
            kodirdil_path = os.path.join(self.pov_path, 'resources', 'lib', 'kodirdil')
            if os.path.exists(kodirdil_path):
                shutil.rmtree(kodirdil_path)
                log("Removed kodirdil folder")
            
            # Remove version file
            if os.path.exists(self.version_file):
                os.remove(self.version_file)
            
            if progress_callback:
                progress_callback("Restore completed!", 100)
            
            log("Restore complete!")
            return True
            
        except Exception as e:
            log(f"Restore error: {e}", xbmc.LOGERROR)
            return False
    
    def get_installed_version(self):
        """Get currently installed version"""
        try:
            if os.path.exists(self.version_file):
                with open(self.version_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    return data.get('version', 'unknown')
        except Exception as e:
            log(f"Error reading version file: {e}")
        return None
    
    def _save_installed_version(self, version):
        """Save installed version"""
        try:
            os.makedirs(os.path.dirname(self.version_file), exist_ok=True)
            with open(self.version_file, 'w', encoding='utf-8') as f:
                json.dump({'version': version}, f)
        except Exception as e:
            log(f"Error saving version file: {e}", xbmc.LOGERROR)
    
    def check_for_updates(self):
        """Check if there's a newer version available
        Returns: (has_update: bool, remote_version: str)
        """
        try:
            # Get remote version
            req = Request(VERSION_URL, headers={'User-Agent': 'Kodi'})
            response = urlopen(req, timeout=10)
            remote_data = json.loads(response.read().decode('utf-8'))
            remote_version = remote_data.get('version', '0.0.0')
            
            # Compare with installed
            installed_version = self.get_installed_version()
            
            if installed_version is None:
                return True, remote_version
            
            # Simple version comparison
            has_update = remote_version != installed_version
            return has_update, remote_version
            
        except Exception as e:
            log(f"Error checking for updates: {e}", xbmc.LOGERROR)
            raise
    
    def install(self, progress_callback=None):
        """Download and install Hebrew subtitles files
        
        Args:
            progress_callback: Optional callback function(message, percent)
        
        Returns:
            bool: True if successful
        """
        if not self.is_pov_installed():
            log("POV not installed!", xbmc.LOGERROR)
            return False
        
        try:
            # Step 0: Backup original files first (if no backup exists)
            if not self.has_backup():
                if progress_callback:
                    progress_callback("Backing up original files...", 5)
                
                if not self.backup_pov_files(progress_callback):
                    log("Backup failed, but continuing with install...")
            else:
                log("Backup already exists, skipping backup")
            
            # Step 1: Download ZIP
            if progress_callback:
                progress_callback("Downloading files...", 15)
            
            log(f"Downloading from {ZIP_URL}")
            req = Request(ZIP_URL, headers={'User-Agent': 'Kodi'})
            response = urlopen(req, timeout=60)
            zip_data = response.read()
            
            if progress_callback:
                progress_callback("Extracting files...", 40)
            
            # Step 2: Extract and install
            log("Extracting files...")
            zip_buffer = io.BytesIO(zip_data)
            
            with zipfile.ZipFile(zip_buffer, 'r') as zf:
                file_list = zf.namelist()
                total_files = len(file_list)
                settings_content = None
                
                log(f"ZIP contains {total_files} files: {file_list}")
                
                for i, file_name in enumerate(file_list):
                    if progress_callback:
                        pct = 40 + int((i / total_files) * 50)
                        progress_callback(f"Installing: {os.path.basename(file_name)}", pct)
                    
                    # Determine destination path
                    dest_path = self._get_destination_path(file_name)
                    log(f"File: {file_name} -> Dest: {dest_path}")
                    
                    if dest_path is None:
                        log(f"Skipping (no dest): {file_name}")
                        continue
                    
                    # Skip directories
                    if file_name.endswith('/'):
                        log(f"Skipping (directory): {file_name}")
                        continue
                    
                    # Special handling for settings.xml - merge instead of replace
                    if dest_path == '__MERGE_SETTINGS__':
                        with zf.open(file_name) as src:
                            settings_content = src.read()
                        log(f"Saved settings.xml for merge")
                        continue
                    
                    # Create directory if needed
                    dest_dir = os.path.dirname(dest_path)
                    if not os.path.exists(dest_dir):
                        os.makedirs(dest_dir)
                        log(f"Created directory: {dest_dir}")
                    
                    # Extract file
                    with zf.open(file_name) as src:
                        with open(dest_path, 'wb') as dst:
                            dst.write(src.read())
                    
                    log(f"Installed: {dest_path}")
                
                # Merge settings.xml if we have it
                if settings_content:
                    if progress_callback:
                        progress_callback("Merging settings...", 92)
                    self._merge_settings_xml(settings_content)
            
            # Step 3: Get and save version
            if progress_callback:
                progress_callback("Finishing installation...", 95)
            
            try:
                req = Request(VERSION_URL, headers={'User-Agent': 'Kodi'})
                response = urlopen(req, timeout=10)
                remote_data = json.loads(response.read().decode('utf-8'))
                version = remote_data.get('version', '1.0.0')
            except:
                version = '1.0.0'
            
            self._save_installed_version(version)
            
            # Also save to ADDON settings for service to check
            ADDON.setSetting('pov_hebrew_version', version)
            
            # Save current POV version
            try:
                pov_addon = xbmcaddon.Addon(self.pov_addon_id)
                pov_version = pov_addon.getAddonInfo('version')
                ADDON.setSetting('last_pov_version', pov_version)
            except:
                pass
            
            if progress_callback:
                progress_callback("Installation completed!", 100)
            
            log("Installation complete!")
            return True
            
        except Exception as e:
            log(f"Installation error: {e}", xbmc.LOGERROR)
            return False
    
    def _get_destination_path(self, zip_file_path):
        """Map ZIP file path to destination path in POV"""
        # Expected ZIP structure:
        # kodirdil/                     -> resources/lib/kodirdil/
        # windows/sources.py            -> resources/lib/windows/sources.py
        # modules/sources.py            -> resources/lib/modules/sources.py
        # modules/source_objects.py     -> resources/lib/modules/source_objects.py
        # settings.xml                  -> SPECIAL HANDLING (merge)
        # service.py                    -> service.py (root)
        
        pov_resources = os.path.join(self.pov_path, 'resources')
        pov_lib = os.path.join(pov_resources, 'lib')
        
        parts = zip_file_path.split('/')
        
        if zip_file_path.startswith('kodirdil/'):
            return os.path.join(pov_lib, zip_file_path)
        
        elif zip_file_path.startswith('windows/'):
            return os.path.join(pov_lib, zip_file_path)
        
        elif zip_file_path.startswith('modules/'):
            return os.path.join(pov_lib, zip_file_path)
        
        elif zip_file_path == 'settings.xml':
            # Special handling - return None, we'll merge separately
            return '__MERGE_SETTINGS__'
        
        elif zip_file_path == 'service.py':
            return os.path.join(pov_lib, 'service.py')
        
        return None
    
    def _merge_settings_xml(self, new_settings_content):
        """Merge Hebrew Subtitles settings into existing POV settings.xml
        This preserves all user settings while adding Hebrew Subtitles category.
        """
        import re
        
        pov_settings_path = os.path.join(self.pov_path, 'resources', 'settings.xml')
        
        if not os.path.exists(pov_settings_path):
            # No existing settings, just write the new one
            with open(pov_settings_path, 'wb') as f:
                f.write(new_settings_content)
            log("No existing settings.xml, wrote new one")
            return
        
        # Read existing settings
        with open(pov_settings_path, 'r', encoding='utf-8') as f:
            existing_content = f.read()
        
        new_content = new_settings_content.decode('utf-8')
        
        # Check if Hebrew Subtitles category already exists
        if 'Hebrew Subtitles' in existing_content:
            log("Hebrew Subtitles settings already present, removing old one first...")
            # Remove old Hebrew Subtitles category (handles label="Hebrew Subtitles")
            existing_content = re.sub(
                r'\s*<!-- Hebrew Subtitles -->.*?<category label="Hebrew Subtitles">.*?</category>',
                '',
                existing_content,
                flags=re.DOTALL
            )
        
        # Extract Hebrew Subtitles category from new settings (including the comment)
        match = re.search(
            r'(<!-- Hebrew Subtitles -->\s*<category label="Hebrew Subtitles">.*?</category>)',
            new_content,
            re.DOTALL
        )
        
        if not match:
            # Try without comment
            match = re.search(
                r'(<category label="Hebrew Subtitles">.*?</category>)',
                new_content,
                re.DOTALL
            )
        
        if not match:
            log("Could not find Hebrew Subtitles category in new settings!", xbmc.LOGERROR)
            log(f"New content preview: {new_content[:500]}", xbmc.LOGERROR)
            return
        
        hebrew_category = match.group(1)
        log(f"Found Hebrew category, length: {len(hebrew_category)}")
        
        # Insert Hebrew Subtitles category before closing </settings> tag
        if '</settings>' in existing_content:
            merged_content = existing_content.replace(
                '</settings>',
                f'\n\t{hebrew_category}\n</settings>'
            )
            
            # Write merged settings
            with open(pov_settings_path, 'w', encoding='utf-8') as f:
                f.write(merged_content)
            
            log("Settings merged successfully")
        else:
            log("Could not find </settings> tag!", xbmc.LOGERROR)
    
    def uninstall(self):
        """Remove Hebrew subtitles files from POV
        
        Returns:
            bool: True if successful
        """
        if not self.is_pov_installed():
            return False
        
        try:
            # Remove kodirdil folder
            kodirdil_path = os.path.join(self.pov_path, 'resources', 'lib', 'kodirdil')
            if os.path.exists(kodirdil_path):
                shutil.rmtree(kodirdil_path)
                log(f"Removed: {kodirdil_path}")
            
            # Remove version file
            if os.path.exists(self.version_file):
                os.remove(self.version_file)
            
            # Note: We don't restore original files since POV will re-download on next update
            
            log("Uninstall complete!")
            return True
            
        except Exception as e:
            log(f"Uninstall error: {e}", xbmc.LOGERROR)
            return False


# ============================================================================
# ARCTIC FUSE HEBREW INSTALLER
# ============================================================================

# Skin GitHub URLs
SKIN_GITHUB_BASE_URL = "https://raw.githubusercontent.com/asaf27064/pov-modified-heb/main"
SKIN_VERSION_URL = f"{SKIN_GITHUB_BASE_URL}/skin_version.json"
SKIN_ZIP_URL = f"{SKIN_GITHUB_BASE_URL}/skin_hebrew_files.zip"

# Jurialmunkey Repo
JURIALMUNKEY_REPO_URL = "https://jurialmunkey.github.io/repository.jurialmunkey/repository.jurialmunkey-3.4.zip"
JURIALMUNKEY_REPO_ID = "repository.jurialmunkey"

# Arctic Fuse Skin
ARCTIC_FUSE_ADDON_ID = "skin.arctic.fuse.3"

# Backup location for skin
SKIN_BACKUP_FOLDER = os.path.join(ADDON_DATA, 'skin_backup')


class ArcticFuseHebrewInstaller:
    def __init__(self):
        self.skin_addon_id = ARCTIC_FUSE_ADDON_ID
        self.skin_path = None
        self.version_file = os.path.join(ADDON_DATA, 'skin_installed_version.json')
        self.backup_folder = SKIN_BACKUP_FOLDER
        self._find_skin_path()
    
    def _find_skin_path(self):
        """Find Arctic Fuse skin path"""
        try:
            skin_addon = xbmcaddon.Addon(self.skin_addon_id)
            self.skin_path = skin_addon.getAddonInfo('path')
            log(f"Found Arctic Fuse at: {self.skin_path}")
        except Exception as e:
            log(f"Arctic Fuse not found: {e}", xbmc.LOGWARNING)
            self.skin_path = None
    
    def is_skin_installed(self):
        """Check if Arctic Fuse skin is installed"""
        return self.skin_path is not None and os.path.exists(self.skin_path)
    
    def is_repo_installed(self):
        """Check if Jurialmunkey repo is installed"""
        try:
            xbmcaddon.Addon(JURIALMUNKEY_REPO_ID)
            return True
        except:
            return False
    
    def is_hebrew_installed(self):
        """Check if Hebrew files are installed in skin"""
        if not self.is_skin_installed():
            return False
        
        # Check for Hebrew font file
        hebrew_font = os.path.join(self.skin_path, 'fonts', 'Rubik-VariableFont_wght.ttf')
        return os.path.exists(hebrew_font)
    
    def has_backup(self):
        """Check if backup exists"""
        if not os.path.exists(self.backup_folder):
            return False
        backup_info = os.path.join(self.backup_folder, 'backup_info.json')
        return os.path.exists(backup_info)
    
    def get_backup_info(self):
        """Get backup information"""
        try:
            backup_info_file = os.path.join(self.backup_folder, 'backup_info.json')
            if os.path.exists(backup_info_file):
                with open(backup_info_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
        except Exception as e:
            log(f"Error reading skin backup info: {e}")
        return None
    
    def get_installed_version(self):
        """Get currently installed Hebrew skin version"""
        try:
            if os.path.exists(self.version_file):
                with open(self.version_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    return data.get('version', 'unknown')
        except Exception as e:
            log(f"Error reading skin version file: {e}")
        return None
    
    def _save_installed_version(self, version):
        """Save installed version"""
        try:
            os.makedirs(os.path.dirname(self.version_file), exist_ok=True)
            with open(self.version_file, 'w', encoding='utf-8') as f:
                json.dump({'version': version}, f)
        except Exception as e:
            log(f"Error saving skin version file: {e}", xbmc.LOGERROR)
    
    def get_skin_version(self):
        """Get current Arctic Fuse version"""
        try:
            if self.is_skin_installed():
                skin_addon = xbmcaddon.Addon(self.skin_addon_id)
                return skin_addon.getAddonInfo('version')
        except:
            pass
        return None
    
    def backup_skin_files(self, progress_callback=None):
        """Backup original skin files before installing Hebrew"""
        if not self.is_skin_installed():
            log("Skin not installed, cannot backup")
            return False
        
        try:
            if not os.path.exists(self.backup_folder):
                os.makedirs(self.backup_folder)
            
            if progress_callback:
                progress_callback("Backing up skin files...", 5)
            
            # Files to backup
            files_to_backup = [
                ('1080i/Font.xml', 'Font.xml'),
                ('1080i/Includes_Font.xml', 'Includes_Font.xml'),
            ]
            
            backed_up_files = []
            skin_version = self.get_skin_version()
            
            for src_rel, backup_name in files_to_backup:
                src_path = os.path.join(self.skin_path, src_rel)
                backup_path = os.path.join(self.backup_folder, backup_name)
                
                if os.path.exists(src_path):
                    shutil.copy2(src_path, backup_path)
                    backed_up_files.append({
                        'original': src_rel,
                        'backup': backup_name
                    })
                    log(f"Backed up skin file: {src_rel}")
            
            # Save backup info
            backup_info = {
                'skin_version': skin_version,
                'backup_date': time.strftime('%Y-%m-%d %H:%M:%S'),
                'files': backed_up_files
            }
            
            with open(os.path.join(self.backup_folder, 'backup_info.json'), 'w', encoding='utf-8') as f:
                json.dump(backup_info, f, indent=2)
            
            log(f"Skin backup complete. Version: {skin_version}")
            return True
            
        except Exception as e:
            log(f"Skin backup error: {e}", xbmc.LOGERROR)
            return False
    
    def restore_skin_files(self, progress_callback=None):
        """Restore original skin files from backup"""
        if not self.has_backup():
            log("No skin backup found")
            return False
        
        if not self.is_skin_installed():
            log("Skin not installed")
            return False
        
        try:
            if progress_callback:
                progress_callback("Restoring skin files...", 10)
            
            backup_info = self.get_backup_info()
            if not backup_info:
                return False
            
            files = backup_info.get('files', [])
            total = len(files)
            
            for i, file_info in enumerate(files):
                if progress_callback:
                    pct = 10 + int((i / total) * 80)
                    progress_callback(f"Restoring: {file_info['original']}", pct)
                
                backup_path = os.path.join(self.backup_folder, file_info['backup'])
                restore_path = os.path.join(self.skin_path, file_info['original'])
                
                if os.path.exists(backup_path):
                    restore_dir = os.path.dirname(restore_path)
                    if not os.path.exists(restore_dir):
                        os.makedirs(restore_dir)
                    
                    shutil.copy2(backup_path, restore_path)
                    log(f"Restored skin file: {file_info['original']}")
            
            # Remove Hebrew fonts
            fonts_to_remove = [
                'fonts/Rubik-VariableFont_wght.ttf',
                'fonts/Rubik-Italic-VariableFont_wght.ttf'
            ]
            for font in fonts_to_remove:
                font_path = os.path.join(self.skin_path, font)
                if os.path.exists(font_path):
                    os.remove(font_path)
                    log(f"Removed Hebrew font: {font}")
            
            # Remove Hebrew language folder
            hebrew_lang = os.path.join(self.skin_path, 'language', 'resource.language.he_il')
            if os.path.exists(hebrew_lang):
                shutil.rmtree(hebrew_lang)
                log("Removed Hebrew language folder")
            
            # Remove version file
            if os.path.exists(self.version_file):
                os.remove(self.version_file)
            
            if progress_callback:
                progress_callback("Restore completed!", 100)
            
            log("Skin restore complete!")
            return True
            
        except Exception as e:
            log(f"Skin restore error: {e}", xbmc.LOGERROR)
            return False
    
    def install_repo(self, progress_callback=None):
        """Install Jurialmunkey repository"""
        if self.is_repo_installed():
            log("Jurialmunkey repo already installed")
            return True
        
        try:
            if progress_callback:
                progress_callback("Downloading Jurialmunkey repo...", 10)
            
            # Download repo ZIP
            log(f"Downloading repo from {JURIALMUNKEY_REPO_URL}")
            req = Request(JURIALMUNKEY_REPO_URL, headers={'User-Agent': 'Kodi'})
            response = urlopen(req, timeout=60)
            zip_data = response.read()
            
            if progress_callback:
                progress_callback("Installing repo...", 30)
            
            # Extract to addons folder
            addons_path = xbmcvfs.translatePath('special://home/addons/')
            zip_buffer = io.BytesIO(zip_data)
            
            with zipfile.ZipFile(zip_buffer, 'r') as zf:
                zf.extractall(addons_path)
            
            log(f"Jurialmunkey repo extracted to {addons_path}")
            
            if progress_callback:
                progress_callback("Enabling repo...", 40)
            
            # Force Kodi to scan for new addons
            xbmc.executebuiltin('UpdateLocalAddons')
            xbmc.sleep(2000)
            
            # Enable the repo addon
            xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"repository.jurialmunkey","enabled":true},"id":1}')
            xbmc.sleep(1000)
            
            # Refresh repositories
            xbmc.executebuiltin('UpdateAddonRepos')
            xbmc.sleep(3000)
            
            if progress_callback:
                progress_callback("Repo installed!", 50)
            
            log("Jurialmunkey repo installed and enabled")
            return True
            
        except Exception as e:
            log(f"Repo install error: {e}", xbmc.LOGERROR)
            return False
    
    def install_skin(self, progress_callback=None):
        """Guide user to install Arctic Fuse 3 skin from repo"""
        if self.is_skin_installed():
            log("Arctic Fuse already installed")
            return True
        
        dialog = xbmcgui.Dialog()
        
        # Open directly to the repo's skins section
        # Path: addons://install/repository.jurialmunkey/kodi.resource.skin/
        xbmc.executebuiltin('ActivateWindow(AddonBrowser,addons://install/repository.jurialmunkey/kodi.resource.skin/,return)')
        
        dialog.ok(
            ADDON_NAME,
            "[COLOR yellow]Install Arctic Fuse 3[/COLOR]\n\n"
            "The Skins list should now be open.\n\n"
            "Please select and install: [COLOR lime]Arctic Fuse 3[/COLOR]\n\n"
            "Press OK when installation is complete."
        )
        
        # Check if installed now
        self._find_skin_path()
        
        if self.is_skin_installed():
            log("Arctic Fuse 3 installed by user")
            return True
        
        # Not installed yet - try again
        if dialog.yesno(
            ADDON_NAME,
            "[COLOR red]Skin not detected![/COLOR]\n\n"
            "Try again?",
            yeslabel="Yes",
            nolabel="Cancel"
        ):
            xbmc.executebuiltin('ActivateWindow(AddonBrowser,addons://install/repository.jurialmunkey/kodi.resource.skin/,return)')
            
            dialog.ok(
                ADDON_NAME,
                "Please install [COLOR lime]Arctic Fuse 3[/COLOR]\n\n"
                "Press OK when done."
            )
            
            self._find_skin_path()
            if self.is_skin_installed():
                return True
        
        return False
    
    def install_hebrew_files(self, progress_callback=None):
        """Download and install Hebrew files to skin"""
        if not self.is_skin_installed():
            log("Skin not installed!")
            return False
        
        try:
            # Backup first if no backup exists
            if not self.has_backup():
                if progress_callback:
                    progress_callback("Backing up original files...", 5)
                self.backup_skin_files(progress_callback)
            
            # Download Hebrew files
            if progress_callback:
                progress_callback("Downloading Hebrew files...", 20)
            
            log(f"Downloading from {SKIN_ZIP_URL}")
            req = Request(SKIN_ZIP_URL, headers={'User-Agent': 'Kodi'})
            response = urlopen(req, timeout=60)
            zip_data = response.read()
            
            if progress_callback:
                progress_callback("Extracting files...", 40)
            
            # Extract and install
            zip_buffer = io.BytesIO(zip_data)
            
            with zipfile.ZipFile(zip_buffer, 'r') as zf:
                file_list = zf.namelist()
                total_files = len(file_list)
                
                for i, file_name in enumerate(file_list):
                    if progress_callback:
                        pct = 40 + int((i / total_files) * 50)
                        progress_callback(f"Installing: {os.path.basename(file_name)}", pct)
                    
                    # Skip directories
                    if file_name.endswith('/'):
                        continue
                    
                    # Remove skin.arctic.fuse.3/ prefix if exists
                    if file_name.startswith('skin.arctic.fuse.3/'):
                        dest_rel = file_name[len('skin.arctic.fuse.3/'):]
                    else:
                        dest_rel = file_name
                    
                    if not dest_rel:
                        continue
                    
                    dest_path = os.path.join(self.skin_path, dest_rel)
                    
                    # Create directory if needed
                    dest_dir = os.path.dirname(dest_path)
                    if not os.path.exists(dest_dir):
                        os.makedirs(dest_dir)
                    
                    # Extract file
                    with zf.open(file_name) as src:
                        with open(dest_path, 'wb') as dst:
                            dst.write(src.read())
                    
                    log(f"Installed skin file: {dest_path}")
            
            # Save version
            if progress_callback:
                progress_callback("Finishing...", 95)
            
            try:
                req = Request(SKIN_VERSION_URL, headers={'User-Agent': 'Kodi'})
                response = urlopen(req, timeout=10)
                remote_data = json.loads(response.read().decode('utf-8'))
                version = remote_data.get('version', '1.0.0')
            except:
                version = '1.0.0'
            
            self._save_installed_version(version)
            
            # Also save to ADDON settings for service to check
            ADDON.setSetting('skin_hebrew_version', version)
            
            # Save current skin version
            skin_version = self.get_skin_version()
            if skin_version:
                ADDON.setSetting('last_skin_version', skin_version)
            
            if progress_callback:
                progress_callback("Installation completed!", 100)
            
            log("Hebrew skin files installed!")
            return True
            
        except Exception as e:
            log(f"Hebrew skin install error: {e}", xbmc.LOGERROR)
            return False
    
    def check_for_updates(self):
        """Check if there's a newer version available"""
        try:
            req = Request(SKIN_VERSION_URL, headers={'User-Agent': 'Kodi'})
            response = urlopen(req, timeout=10)
            remote_data = json.loads(response.read().decode('utf-8'))
            remote_version = remote_data.get('version', '0.0.0')
            
            installed_version = self.get_installed_version()
            
            if installed_version is None:
                return True, remote_version
            
            has_update = remote_version != installed_version
            return has_update, remote_version
            
        except Exception as e:
            log(f"Error checking skin updates: {e}", xbmc.LOGERROR)
            raise
    
    def full_install(self, progress_callback=None):
        """Full installation: Repo + Skin + Hebrew files"""
        try:
            # Step 1: Install repo if needed
            if not self.is_repo_installed():
                if not self.install_repo(progress_callback):
                    return False
            
            # Step 2: Install skin if needed
            if not self.is_skin_installed():
                result = self.install_skin(progress_callback)
                # Refresh skin path
                self._find_skin_path()
                
                if not self.is_skin_installed():
                    log("Skin still not installed after install_skin")
                    return False
            
            # Step 3: Install Hebrew files
            if not self.install_hebrew_files(progress_callback):
                return False
            
            return True
            
        except Exception as e:
            log(f"Full install error: {e}", xbmc.LOGERROR)
            return False
    
    def uninstall(self):
        """Remove Hebrew files from skin"""
        return self.restore_skin_files()


# FenLight GitHub URLs
FENLIGHT_GITHUB_BASE_URL = "https://raw.githubusercontent.com/asaf27064/pov-modified-heb/main"
FENLIGHT_VERSION_URL = f"{FENLIGHT_GITHUB_BASE_URL}/fenlight_version.json"
FENLIGHT_ZIP_URL = f"{FENLIGHT_GITHUB_BASE_URL}/fenlight_hebrew_subtitles.zip"

# FenLight Backup location
FENLIGHT_BACKUP_FOLDER = os.path.join(ADDON_DATA, 'fenlight_backup')


class FenLightHebrewInstaller:
    """Installer for Hebrew subtitles support in FenLight"""
    
    def __init__(self):
        self.addon_id = 'plugin.video.fenlight'
        self.addon_path = None
        self.version_file = os.path.join(ADDON_DATA, 'fenlight_installed_version.json')
        self.backup_folder = FENLIGHT_BACKUP_FOLDER
        self._find_addon_path()
    
    def _find_addon_path(self):
        """Find FenLight addon path"""
        try:
            addon = xbmcaddon.Addon(self.addon_id)
            self.addon_path = addon.getAddonInfo('path')
            log(f"Found FenLight at: {self.addon_path}")
        except Exception as e:
            log(f"FenLight not found: {e}", xbmc.LOGWARNING)
            self.addon_path = None
    
    def is_addon_installed(self):
        """Check if FenLight is installed"""
        return self.addon_path is not None and os.path.exists(self.addon_path)
    
    def is_hebrew_installed(self):
        """Check if Hebrew files are installed"""
        if not self.is_addon_installed():
            return False
        kodirdil_path = os.path.join(self.addon_path, 'resources', 'lib', 'kodirdil')
        return os.path.exists(kodirdil_path)
    
    def has_backup(self):
        """Check if backup exists"""
        if not os.path.exists(self.backup_folder):
            return False
        backup_info = os.path.join(self.backup_folder, 'backup_info.json')
        return os.path.exists(backup_info)
    
    def get_backup_info(self):
        """Get backup information"""
        try:
            backup_info_file = os.path.join(self.backup_folder, 'backup_info.json')
            if os.path.exists(backup_info_file):
                with open(backup_info_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
        except Exception as e:
            log(f"Error reading FenLight backup info: {e}")
        return None
    
    def get_installed_version(self):
        """Get currently installed Hebrew version"""
        try:
            if os.path.exists(self.version_file):
                with open(self.version_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    return data.get('version', 'unknown')
        except Exception as e:
            log(f"Error reading FenLight version file: {e}")
        return None
    
    def _save_installed_version(self, version):
        """Save installed version"""
        try:
            os.makedirs(os.path.dirname(self.version_file), exist_ok=True)
            with open(self.version_file, 'w', encoding='utf-8') as f:
                json.dump({'version': version}, f)
        except Exception as e:
            log(f"Error saving FenLight version file: {e}", xbmc.LOGERROR)
    
    def get_addon_version(self):
        """Get current FenLight addon version"""
        try:
            if self.is_addon_installed():
                addon = xbmcaddon.Addon(self.addon_id)
                return addon.getAddonInfo('version')
        except:
            pass
        return None
    
    def check_for_updates(self):
        """Check GitHub for newer version"""
        try:
            log(f"Checking for FenLight Hebrew updates from {FENLIGHT_VERSION_URL}")
            req = Request(FENLIGHT_VERSION_URL, headers={'User-Agent': 'Kodi'})
            response = urlopen(req, timeout=15)
            remote_data = json.loads(response.read().decode('utf-8'))
            
            remote_version = remote_data.get('version', '0')
            local_version = self.get_installed_version() or '0'
            
            log(f"FenLight Hebrew: Local version: {local_version}, Remote version: {remote_version}")
            
            if self._version_compare(remote_version, local_version) > 0:
                return {
                    'has_update': True,
                    'local_version': local_version,
                    'remote_version': remote_version,
                    'changelog': remote_data.get('changelog', '')
                }
            
            return {'has_update': False, 'local_version': local_version, 'remote_version': remote_version}
            
        except Exception as e:
            log(f"Error checking for FenLight updates: {e}", xbmc.LOGERROR)
            return {'has_update': False, 'error': str(e)}
    
    def _version_compare(self, v1, v2):
        """Compare version strings"""
        def normalize(v):
            return [int(x) for x in v.split('.')]
        try:
            v1_parts = normalize(v1)
            v2_parts = normalize(v2)
            for i in range(max(len(v1_parts), len(v2_parts))):
                v1_val = v1_parts[i] if i < len(v1_parts) else 0
                v2_val = v2_parts[i] if i < len(v2_parts) else 0
                if v1_val > v2_val:
                    return 1
                elif v1_val < v2_val:
                    return -1
            return 0
        except:
            return 0
    
    def backup_original_files(self, progress_callback=None):
        """Backup original FenLight files before installation"""
        if not self.is_addon_installed():
            return False
        
        try:
            if progress_callback:
                progress_callback("Backing up original files...", 10)
            
            os.makedirs(self.backup_folder, exist_ok=True)
            
            lib_path = os.path.join(self.addon_path, 'resources', 'lib')
            resources_path = os.path.join(self.addon_path, 'resources')
            backed_up_files = []
            
            # Files to backup from lib folder
            lib_files_to_backup = [
                ('modules', 'sources.py'),
                ('windows', 'sources.py'),
                ('caches', 'settings_cache.py'),
                ('apis', 'tmdb_api.py')
            ]
            
            for subdir, filename in lib_files_to_backup:
                src = os.path.join(lib_path, subdir, filename)
                if os.path.exists(src):
                    dest_dir = os.path.join(self.backup_folder, 'lib', subdir)
                    os.makedirs(dest_dir, exist_ok=True)
                    dest = os.path.join(dest_dir, filename)
                    shutil.copy2(src, dest)
                    backed_up_files.append(os.path.join('lib', subdir, filename))
                    log(f"Backed up: {src}")
            
            # Backup settings_manager.xml from skins folder
            settings_manager_src = os.path.join(resources_path, 'skins', 'Default', '1080i', 'settings_manager.xml')
            if os.path.exists(settings_manager_src):
                dest_dir = os.path.join(self.backup_folder, 'skins', 'Default', '1080i')
                os.makedirs(dest_dir, exist_ok=True)
                dest = os.path.join(dest_dir, 'settings_manager.xml')
                shutil.copy2(settings_manager_src, dest)
                backed_up_files.append(os.path.join('skins', 'Default', '1080i', 'settings_manager.xml'))
                log(f"Backed up: {settings_manager_src}")
            
            # Save backup info
            backup_info = {
                'backup_date': time.strftime('%Y-%m-%d %H:%M:%S'),
                'addon_version': self.get_addon_version(),
                'backed_up_files': backed_up_files
            }
            
            with open(os.path.join(self.backup_folder, 'backup_info.json'), 'w', encoding='utf-8') as f:
                json.dump(backup_info, f, indent=2)
            
            log("FenLight backup complete!")
            return True
            
        except Exception as e:
            log(f"FenLight backup error: {e}", xbmc.LOGERROR)
            return False
    
    def install_hebrew_files(self, progress_callback=None):
        """Download and install Hebrew files to FenLight"""
        if not self.is_addon_installed():
            log("FenLight not installed!")
            return False
        
        try:
            # Backup first if no backup exists
            if not self.has_backup():
                if progress_callback:
                    progress_callback("Creating backup...", 5)
                self.backup_original_files(progress_callback)
            
            if progress_callback:
                progress_callback("Downloading Hebrew files...", 20)
            
            # Download ZIP
            log(f"Downloading FenLight Hebrew from {FENLIGHT_ZIP_URL}")
            req = Request(FENLIGHT_ZIP_URL, headers={'User-Agent': 'Kodi'})
            response = urlopen(req, timeout=60)
            zip_data = response.read()
            
            if progress_callback:
                progress_callback("Extracting files...", 50)
            
            # Extract files
            lib_path = os.path.join(self.addon_path, 'resources', 'lib')
            resources_path = os.path.join(self.addon_path, 'resources')
            zip_buffer = io.BytesIO(zip_data)
            
            with zipfile.ZipFile(zip_buffer, 'r') as zf:
                for member in zf.namelist():
                    # Determine destination
                    if member.startswith('kodirdil/'):
                        dest = os.path.join(lib_path, member)
                    elif member.startswith('modules/'):
                        dest = os.path.join(lib_path, member)
                    elif member.startswith('windows/'):
                        dest = os.path.join(lib_path, member)
                    elif member.startswith('caches/'):
                        dest = os.path.join(lib_path, member)
                    elif member.startswith('apis/'):
                        dest = os.path.join(lib_path, member)
                    elif member.startswith('skins/'):
                        dest = os.path.join(resources_path, member)
                    else:
                        continue
                    
                    if member.endswith('/'):
                        os.makedirs(dest, exist_ok=True)
                    else:
                        os.makedirs(os.path.dirname(dest), exist_ok=True)
                        with zf.open(member) as src, open(dest, 'wb') as dst:
                            dst.write(src.read())
                        log(f"Installed: {dest}")
            
            if progress_callback:
                progress_callback("Saving version info...", 90)
            
            # Get and save version
            try:
                req = Request(FENLIGHT_VERSION_URL, headers={'User-Agent': 'Kodi'})
                response = urlopen(req, timeout=10)
                version_data = json.loads(response.read().decode('utf-8'))
                version = version_data.get('version', '1.0.0')
                self._save_installed_version(version)
                # Also save to ADDON settings for service to check
                ADDON.setSetting('fenlight_hebrew_version', version)
            except:
                self._save_installed_version('1.0.0')
                ADDON.setSetting('fenlight_hebrew_version', '1.0.0')
            
            # Save FenLight version for update detection
            ADDON.setSetting('last_fenlight_version', self.get_addon_version() or '')
            
            if progress_callback:
                progress_callback("Installation complete!", 100)
            
            log("FenLight Hebrew installation complete!")
            return True
            
        except Exception as e:
            log(f"FenLight installation error: {e}", xbmc.LOGERROR)
            return False
    
    def restore_original_files(self, progress_callback=None):
        """Restore original FenLight files from backup"""
        if not self.has_backup():
            log("No FenLight backup found!")
            return False
        
        if not self.is_addon_installed():
            log("FenLight not installed!")
            return False
        
        try:
            if progress_callback:
                progress_callback("Restoring original files...", 20)
            
            lib_path = os.path.join(self.addon_path, 'resources', 'lib')
            
            # Restore backed up files
            backup_info = self.get_backup_info()
            if backup_info and 'backed_up_files' in backup_info:
                for rel_path in backup_info['backed_up_files']:
                    src = os.path.join(self.backup_folder, rel_path)
                    dest = os.path.join(lib_path, rel_path)
                    if os.path.exists(src):
                        shutil.copy2(src, dest)
                        log(f"Restored: {dest}")
            
            if progress_callback:
                progress_callback("Removing Hebrew files...", 60)
            
            # Remove kodirdil folder
            kodirdil_path = os.path.join(lib_path, 'kodirdil')
            if os.path.exists(kodirdil_path):
                shutil.rmtree(kodirdil_path)
                log("Removed kodirdil folder")
            
            # Remove version file
            if os.path.exists(self.version_file):
                os.remove(self.version_file)
            
            if progress_callback:
                progress_callback("Restore complete!", 100)
            
            log("FenLight restore complete!")
            return True
            
        except Exception as e:
            log(f"FenLight restore error: {e}", xbmc.LOGERROR)
            return False
    
    def uninstall(self):
        """Remove Hebrew files from FenLight"""
        return self.restore_original_files()
