# -*- coding: utf-8 -*-
"""
POV Hebrew Subtitles Wizard - Service
- Checks for FenLight updates on startup
- Monitors for POV updates via Kodi notifications
- Reinstalls Hebrew files after updates
"""
import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import json
import os
import re
import shutil
import zipfile
import urllib.request
import ssl

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')

ADDONS_PATH = xbmcvfs.translatePath('special://home/addons/')
PACKAGES_PATH = xbmcvfs.translatePath('special://home/addons/packages/')

# FenLight update sources
FENLIGHT_SOURCES = [
    {
        'name': 'FenlightAnonyMouse GitHub',
        'version_url': 'https://raw.githubusercontent.com/FenlightAnonyMouse/FenlightAnonyMouse.github.io/main/packages/fen_light_version',
        'zip_url': 'https://raw.githubusercontent.com/FenlightAnonyMouse/FenlightAnonyMouse.github.io/main/packages/plugin.video.fenlight-{version}.zip',
        'api_url': 'https://api.github.com/repos/FenlightAnonyMouse/FenlightAnonyMouse.github.io/contents/packages'
    },
    {
        'name': 'FenlightAnonyMouse Pages',
        'version_url': None,
        'zip_url': 'https://fenlightanonymouse.github.io/packages/plugin.video.fenlight-{version}.zip',
        'list_url': 'https://fenlightanonymouse.github.io/packages/'
    },
    {
        'name': 'tikipeter Repository',
        'version_url': 'https://github.com/tikimaniac/repository.tikipeter/raw/main/packages/fen_light_version',
        'zip_url': 'https://github.com/tikimaniac/repository.tikipeter/raw/main/packages/plugin.video.fenlight-{version}.zip',
    }
]


def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f'[{ADDON_ID}] {msg}', level)


log("Service loading...")


def url_get(url, timeout=15):
    """Download URL content"""
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        
        req = urllib.request.Request(url, headers={'User-Agent': 'Kodi/20.0'})
        with urllib.request.urlopen(req, timeout=timeout, context=ctx) as response:
            return response.read()
    except Exception as e:
        log(f"URL fetch error for {url}: {e}")
        return None


def get_addon_version(addon_id):
    """Get addon version from addon.xml"""
    try:
        addon_xml = os.path.join(ADDONS_PATH, addon_id, 'addon.xml')
        if os.path.exists(addon_xml):
            with open(addon_xml, 'r', encoding='utf-8') as f:
                content = f.read()
                match = re.search(r'<addon[^>]*version="([^"]+)"', content)
                if match:
                    return match.group(1)
    except:
        pass
    return None


def version_compare(v1, v2):
    """Compare versions. Returns: 1 if v1>v2, -1 if v1<v2, 0 if equal"""
    try:
        def normalize(v):
            parts = []
            for part in v.split('.'):
                num = ''.join(c for c in part if c.isdigit())
                parts.append(int(num) if num else 0)
            return parts
        
        v1_parts = normalize(v1)
        v2_parts = normalize(v2)
        
        max_len = max(len(v1_parts), len(v2_parts))
        v1_parts.extend([0] * (max_len - len(v1_parts)))
        v2_parts.extend([0] * (max_len - len(v2_parts)))
        
        for i in range(max_len):
            if v1_parts[i] > v2_parts[i]:
                return 1
            elif v1_parts[i] < v2_parts[i]:
                return -1
        return 0
    except:
        return 0


def find_latest_version_from_api(api_url):
    """Find latest version by scanning GitHub API"""
    try:
        data = url_get(api_url)
        if not data:
            return None
        
        files = json.loads(data.decode('utf-8'))
        versions = []
        
        for f in files:
            name = f.get('name', '')
            match = re.match(r'plugin\.video\.fenlight-(\d+\.\d+\.\d+)\.zip', name)
            if match:
                versions.append(match.group(1))
        
        if versions:
            versions.sort(key=lambda v: [int(x) for x in v.split('.')], reverse=True)
            return versions[0]
    except Exception as e:
        log(f"Error scanning API: {e}")
    return None


def find_latest_version_from_html(list_url):
    """Find latest version by scanning HTML directory listing"""
    try:
        data = url_get(list_url)
        if not data:
            return None
        
        html = data.decode('utf-8')
        versions = re.findall(r'plugin\.video\.fenlight-(\d+\.\d+\.\d+)\.zip', html)
        
        if versions:
            versions = list(set(versions))
            versions.sort(key=lambda v: [int(x) for x in v.split('.')], reverse=True)
            return versions[0]
    except Exception as e:
        log(f"Error scanning HTML: {e}")
    return None


def get_fenlight_online_version_and_url():
    """Try all sources to get latest FenLight version and download URL"""
    for source in FENLIGHT_SOURCES:
        log(f"Trying source: {source['name']}")
        
        online_version = None
        
        if source.get('version_url'):
            data = url_get(source['version_url'])
            if data:
                online_version = data.decode('utf-8').replace('\n', '').strip()
                log(f"Got version from version file: {online_version}")
        
        if not online_version and source.get('api_url'):
            online_version = find_latest_version_from_api(source['api_url'])
            if online_version:
                log(f"Got version from API: {online_version}")
        
        if not online_version and source.get('list_url'):
            online_version = find_latest_version_from_html(source['list_url'])
            if online_version:
                log(f"Got version from HTML: {online_version}")
        
        if online_version:
            zip_url = source['zip_url'].format(version=online_version)
            return online_version, zip_url, source['name']
    
    return None, None, None


class POVHebrewService(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        log("Service initialized")
        
        # Store versions to detect changes
        self.pov_version = get_addon_version('plugin.video.pov')
        self.fenlight_version = get_addon_version('plugin.video.fenlight')
        
        log(f"Initial versions - POV: {self.pov_version}, FenLight: {self.fenlight_version}")
    
    def onNotification(self, sender, method, data):
        """Handle Kodi notifications - detect POV updates via repo"""
        
        # POV updates come through Kodi repo, which triggers these notifications
        if method in ('Addon.OnInstalled', 'Addon.OnEnabled'):
            try:
                data_dict = json.loads(data)
                addon_id = data_dict.get('id', '')
                
                log(f"Notification: {method} for {addon_id}")
                
                if addon_id == 'plugin.video.pov':
                    # Check if version changed
                    new_version = get_addon_version('plugin.video.pov')
                    if new_version and new_version != self.pov_version:
                        log(f"POV updated: {self.pov_version} -> {new_version}")
                        self.pov_version = new_version
                        xbmc.sleep(3000)  # Wait for addon to fully load
                        self.reinstall_pov_hebrew(new_version)
                        
            except Exception as e:
                log(f"Error handling notification: {e}")
    
    def reinstall_pov_hebrew(self, new_version):
        """Reinstall Hebrew files for POV after update"""
        if not ADDON.getSettingBool('auto_reinstall_pov'):
            log("Auto reinstall for POV is disabled")
            return
        
        try:
            from resources.libs.installer import POVHebrewInstaller
            installer = POVHebrewInstaller()
            
            if not installer.is_installed():
                log("Hebrew was not installed for POV, skipping")
                return
            
            dialog = xbmcgui.Dialog()
            
            dialog.notification(
                ADDON_NAME,
                f"POV updated to {new_version}. Reinstalling Hebrew...",
                xbmcgui.NOTIFICATION_INFO,
                3000
            )
            
            xbmc.sleep(1000)
            
            progress = xbmcgui.DialogProgress()
            progress.create(ADDON_NAME, f"POV updated to {new_version}\nReinstalling Hebrew files...")
            
            success = installer.install(
                progress_callback=lambda msg, pct: progress.update(pct, msg)
            )
            
            progress.close()
            
            if success:
                ADDON.setSetting('last_pov_version', new_version)
                dialog.ok(
                    ADDON_NAME,
                    f"[COLOR lime]POV updated to {new_version}[/COLOR]\n\n"
                    "Hebrew files reinstalled successfully!\n\n"
                    "Kodi will now restart."
                )
                xbmc.executebuiltin('Quit')
            else:
                dialog.ok(ADDON_NAME, "[COLOR red]Hebrew reinstallation failed![/COLOR]")
                
        except Exception as e:
            log(f"Error reinstalling POV Hebrew: {e}")
    
    def run(self):
        """Main service loop"""
        log("Service started, waiting 30 seconds...")
        xbmc.sleep(30000)
        
        # Check for Hebrew files updates first
        log("Checking for Hebrew files updates...")
        self.check_hebrew_updates()
        
        # Then check for FenLight addon update
        log("Starting FenLight update check...")
        self.check_and_update_fenlight()
        
        # Keep service alive to catch notifications
        while not self.abortRequested():
            if self.waitForAbort(300):
                break
        
        log("Service stopped")
    
    def check_hebrew_updates(self):
        """Check if Hebrew files have updates available"""
        
        if not ADDON.getSettingBool('auto_update_check'):
            log("Auto update check is disabled")
            return
        
        # GitHub URL (same as in installer.py)
        GITHUB_BASE = "https://raw.githubusercontent.com/asaf27064/pov-modified-heb/main/"
        log(f"Checking Hebrew updates from: {GITHUB_BASE}")
        
        updates_available = []
        
        # Check POV Hebrew
        if ADDON.getSettingBool('auto_reinstall_pov'):
            try:
                from resources.libs.installer import POVHebrewInstaller
                installer = POVHebrewInstaller()
                if installer.is_installed():
                    local_ver = ADDON.getSetting('pov_hebrew_version') or '0'
                    online_data = url_get(GITHUB_BASE + 'version.json')
                    if online_data:
                        online_info = json.loads(online_data.decode('utf-8'))
                        online_ver = online_info.get('version', '0')
                        if version_compare(online_ver, local_ver) > 0:
                            updates_available.append(('POV', local_ver, online_ver, installer, 'pov_hebrew_version'))
                            log(f"POV Hebrew update: {local_ver} -> {online_ver}")
            except Exception as e:
                log(f"Error checking POV Hebrew: {e}")
        
        # Check FenLight Hebrew
        if ADDON.getSettingBool('auto_reinstall_fenlight'):
            try:
                from resources.libs.installer import FenLightHebrewInstaller
                installer = FenLightHebrewInstaller()
                if installer.is_hebrew_installed():
                    local_ver = ADDON.getSetting('fenlight_hebrew_version') or '0'
                    online_data = url_get(GITHUB_BASE + 'fenlight_version.json')
                    if online_data:
                        online_info = json.loads(online_data.decode('utf-8'))
                        online_ver = online_info.get('version', '0')
                        if version_compare(online_ver, local_ver) > 0:
                            updates_available.append(('FenLight', local_ver, online_ver, installer, 'fenlight_hebrew_version'))
                            log(f"FenLight Hebrew update: {local_ver} -> {online_ver}")
            except Exception as e:
                log(f"Error checking FenLight Hebrew: {e}")
        
        # Check Skin Hebrew
        if ADDON.getSettingBool('auto_reinstall_skin'):
            try:
                from resources.libs.installer import SkinHebrewInstaller
                installer = SkinHebrewInstaller()
                if installer.is_installed():
                    local_ver = ADDON.getSetting('skin_hebrew_version') or '0'
                    online_data = url_get(GITHUB_BASE + 'skin_version.json')
                    if online_data:
                        online_info = json.loads(online_data.decode('utf-8'))
                        online_ver = online_info.get('version', '0')
                        if version_compare(online_ver, local_ver) > 0:
                            updates_available.append(('Skin', local_ver, online_ver, installer, 'skin_hebrew_version'))
                            log(f"Skin Hebrew update: {local_ver} -> {online_ver}")
            except Exception as e:
                log(f"Error checking Skin Hebrew: {e}")
        
        if not updates_available:
            log("All Hebrew files are up to date")
            return
        
        # Show update prompt
        update_text = "\n".join([f"• {name}: {old} → {new}" for name, old, new, _, _ in updates_available])
        
        dialog = xbmcgui.Dialog()
        if not dialog.yesno(
            ADDON_NAME,
            f"[COLOR yellow]Hebrew Files Updates Available[/COLOR]\n\n{update_text}\n\nUpdate now?",
            yeslabel="Update",
            nolabel="Later"
        ):
            log("User declined Hebrew updates")
            return
        
        # Perform updates
        progress = xbmcgui.DialogProgress()
        progress.create(ADDON_NAME, "Updating Hebrew files...")
        
        success_count = 0
        total = len(updates_available)
        
        for i, (name, old_ver, new_ver, installer, setting_key) in enumerate(updates_available):
            progress.update(int((i / total) * 100), f"Updating {name} Hebrew...")
            
            try:
                if hasattr(installer, 'install'):
                    result = installer.install(progress_callback=lambda msg, pct: None)
                elif hasattr(installer, 'install_hebrew_files'):
                    result = installer.install_hebrew_files(progress_callback=lambda msg, pct: None)
                else:
                    result = False
                
                if result:
                    ADDON.setSetting(setting_key, new_ver)
                    success_count += 1
                    log(f"{name} Hebrew updated to {new_ver}")
            except Exception as e:
                log(f"Error updating {name} Hebrew: {e}")
        
        progress.close()
        
        if success_count > 0:
            dialog.ok(
                ADDON_NAME,
                f"[COLOR lime]Updated {success_count}/{total} Hebrew files[/COLOR]\n\n"
                "Kodi will restart to apply changes."
            )
            xbmc.executebuiltin('Quit')
        else:
            dialog.ok(ADDON_NAME, "[COLOR red]Hebrew updates failed![/COLOR]")
    
    def check_and_update_fenlight(self):
        """Check for FenLight updates"""
        if not ADDON.getSettingBool('auto_reinstall_fenlight'):
            log("Auto reinstall for FenLight is disabled")
            return
        
        fenlight_path = os.path.join(ADDONS_PATH, 'plugin.video.fenlight')
        if not os.path.exists(fenlight_path):
            log("FenLight not installed")
            return
        
        try:
            from resources.libs.installer import FenLightHebrewInstaller
            installer = FenLightHebrewInstaller()
            if not installer.is_hebrew_installed():
                log("Hebrew not installed for FenLight, skipping")
                return
        except Exception as e:
            log(f"Error checking Hebrew: {e}")
            return
        
        current_version = get_addon_version('plugin.video.fenlight')
        if not current_version:
            log("Could not get current FenLight version")
            return
        log(f"Current FenLight version: {current_version}")
        
        online_version, zip_url, source_name = get_fenlight_online_version_and_url()
        
        if not online_version:
            log("Could not get online version from any source")
            return
        
        log(f"Online version: {online_version} (from {source_name})")
        
        if version_compare(online_version, current_version) <= 0:
            log("FenLight is up to date")
            return
        
        log(f"UPDATE AVAILABLE: {current_version} -> {online_version}")
        
        dialog = xbmcgui.Dialog()
        if not dialog.yesno(
            ADDON_NAME,
            f"[COLOR yellow]FenLight Update Available[/COLOR]\n\n"
            f"Current: {current_version}\n"
            f"New: {online_version}\n"
            f"Source: {source_name}\n\n"
            "Update now and reinstall Hebrew files?",
            yeslabel="Update",
            nolabel="Later"
        ):
            log("User declined")
            return
        
        self.perform_fenlight_update(zip_url, online_version, installer)
    
    def perform_fenlight_update(self, zip_url, version, installer):
        """Perform the actual FenLight update"""
        log(f"Starting FenLight update to {version}")
        
        progress = xbmcgui.DialogProgress()
        progress.create(ADDON_NAME, "Updating FenLight...")
        
        try:
            progress.update(10, f"Downloading FenLight {version}...")
            log(f"Downloading: {zip_url}")
            
            zip_data = url_get(zip_url, timeout=120)
            if not zip_data:
                raise Exception("Download failed")
            
            log(f"Downloaded {len(zip_data)} bytes")
            
            progress.update(30, "Saving package...")
            zip_name = f'plugin.video.fenlight-{version}.zip'
            zip_location = os.path.join(PACKAGES_PATH, zip_name)
            os.makedirs(PACKAGES_PATH, exist_ok=True)
            
            with open(zip_location, 'wb') as f:
                f.write(zip_data)
            
            progress.update(40, "Removing old FenLight...")
            fenlight_path = os.path.join(ADDONS_PATH, 'plugin.video.fenlight')
            if os.path.exists(fenlight_path):
                shutil.rmtree(fenlight_path)
            
            progress.update(50, "Installing new FenLight...")
            with zipfile.ZipFile(zip_location, 'r') as zf:
                zf.extractall(ADDONS_PATH)
            
            try:
                os.remove(zip_location)
            except:
                pass
            
            progress.update(60, "Updating Kodi database...")
            xbmc.executebuiltin('UpdateLocalAddons')
            xbmc.sleep(2000)
            
            progress.update(70, "Installing Hebrew files...")
            hebrew_success = installer.install_hebrew_files(
                progress_callback=lambda msg, pct: progress.update(70 + int(pct * 0.25), msg)
            )
            
            progress.close()
            
            dialog = xbmcgui.Dialog()
            if hebrew_success:
                ADDON.setSetting('last_fenlight_version', version)
                dialog.ok(
                    ADDON_NAME,
                    f"[COLOR lime]Success![/COLOR]\n\n"
                    f"FenLight updated to {version}\n"
                    "Hebrew files installed\n\n"
                    "Kodi will restart now."
                )
            else:
                dialog.ok(
                    ADDON_NAME,
                    f"[COLOR yellow]FenLight updated to {version}[/COLOR]\n\n"
                    "[COLOR red]Hebrew installation failed![/COLOR]\n"
                    "Please install manually."
                )
            
            xbmc.executebuiltin('Quit')
                
        except Exception as e:
            log(f"Update error: {e}", xbmc.LOGERROR)
            progress.close()
            xbmcgui.Dialog().ok(ADDON_NAME, f"[COLOR red]Update failed![/COLOR]\n\n{str(e)}")


if __name__ == '__main__':
    service = POVHebrewService()
    service.run()
