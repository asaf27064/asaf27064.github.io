# -*- coding: utf-8 -*-
"""
POV Hebrew Subtitles Wizard - Main Menu
"""
import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin
import sys
import os

from urllib.parse import parse_qsl

from resources.libs.installer import POVHebrewInstaller, ArcticFuseHebrewInstaller, FenLightHebrewInstaller

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_PATH = ADDON.getAddonInfo('path')
ADDON_ICON = ADDON.getAddonInfo('icon')

HANDLE = int(sys.argv[1])


def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f'[{ADDON_ID}] {msg}', level)


def reinstall_fenlight_after_update():
    """Called automatically after FenLight updates itself"""
    if not ADDON.getSettingBool('auto_reinstall_fenlight'):
        log("Auto re-install for FenLight is disabled")
        return
    
    installer = FenLightHebrewInstaller()
    
    if not installer.is_hebrew_installed():
        log("Hebrew files not installed for FenLight, skipping")
        return
    
    dialog = xbmcgui.Dialog()
    
    # Get new version
    new_version = installer.get_addon_version() or "unknown"
    log(f"FenLight updated to {new_version}, re-installing Hebrew files...")
    
    dialog.notification(
        ADDON_NAME,
        f"FenLight updated! Re-installing Hebrew...",
        xbmcgui.NOTIFICATION_INFO,
        3000
    )
    
    xbmc.sleep(2000)  # Wait for FenLight update to fully complete
    
    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, f"FenLight updated to {new_version}\nRe-installing Hebrew files...")
    
    try:
        success = installer.install_hebrew_files(
            progress_callback=lambda msg, pct: progress.update(pct, msg)
        )
        progress.close()
        
        if success:
            ADDON.setSetting('last_fenlight_version', new_version)
            log("FenLight Hebrew re-installed successfully")
            dialog.ok(
                ADDON_NAME,
                f"[COLOR lime]FenLight updated to {new_version}[/COLOR]\n\n"
                "Hebrew files re-installed successfully!\n\n"
                "Kodi will now restart."
            )
            xbmc.executebuiltin('Quit')
        else:
            log("FenLight Hebrew re-install failed", xbmc.LOGERROR)
            dialog.ok(ADDON_NAME, "[COLOR red]Hebrew re-installation failed![/COLOR]")
    except Exception as e:
        progress.close()
        log(f"Error reinstalling FenLight Hebrew: {e}", xbmc.LOGERROR)
        dialog.ok(ADDON_NAME, f"[COLOR red]Error:[/COLOR] {str(e)}")


def reinstall_pov_after_update():
    """Called automatically after POV updates itself"""
    if not ADDON.getSettingBool('auto_reinstall_pov'):
        log("Auto re-install for POV is disabled")
        return
    
    installer = POVHebrewInstaller()
    
    if not installer.is_installed():
        log("Hebrew files not installed for POV, skipping")
        return
    
    dialog = xbmcgui.Dialog()
    
    # Get new version
    try:
        pov_addon = xbmcaddon.Addon('plugin.video.pov')
        new_version = pov_addon.getAddonInfo('version')
    except:
        new_version = "unknown"
    
    log(f"POV updated to {new_version}, re-installing Hebrew files...")
    
    dialog.notification(
        ADDON_NAME,
        f"POV updated! Re-installing Hebrew...",
        xbmcgui.NOTIFICATION_INFO,
        3000
    )
    
    xbmc.sleep(2000)
    
    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, f"POV updated to {new_version}\nRe-installing Hebrew Subtitles...")
    
    try:
        success = installer.install(
            progress_callback=lambda msg, pct: progress.update(pct, msg)
        )
        progress.close()
        
        if success:
            ADDON.setSetting('last_pov_version', new_version)
            log("POV Hebrew re-installed successfully")
            dialog.ok(
                ADDON_NAME,
                f"[COLOR lime]POV updated to {new_version}[/COLOR]\n\n"
                "Hebrew Subtitles re-installed successfully!\n\n"
                "Kodi will now restart."
            )
            xbmc.executebuiltin('Quit')
        else:
            log("POV Hebrew re-install failed", xbmc.LOGERROR)
            dialog.ok(ADDON_NAME, "[COLOR red]Hebrew re-installation failed![/COLOR]")
    except Exception as e:
        progress.close()
        log(f"Error reinstalling POV Hebrew: {e}", xbmc.LOGERROR)
        dialog.ok(ADDON_NAME, f"[COLOR red]Error:[/COLOR] {str(e)}")


def reinstall_skin_after_update():
    """Called automatically after Arctic Fuse updates itself"""
    if not ADDON.getSettingBool('auto_reinstall_skin'):
        log("Auto re-install for skin is disabled")
        return
    
    installer = ArcticFuseHebrewInstaller()
    
    if not installer.is_hebrew_installed():
        log("Hebrew files not installed for skin, skipping")
        return
    
    dialog = xbmcgui.Dialog()
    new_version = installer.get_skin_version() or "unknown"
    
    log(f"Arctic Fuse updated to {new_version}, re-installing Hebrew files...")
    
    dialog.notification(
        ADDON_NAME,
        f"Arctic Fuse updated! Re-installing Hebrew...",
        xbmcgui.NOTIFICATION_INFO,
        3000
    )
    
    xbmc.sleep(2000)
    
    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, f"Arctic Fuse updated to {new_version}\nRe-installing Hebrew files...")
    
    try:
        success = installer.install_hebrew_files(
            progress_callback=lambda msg, pct: progress.update(pct, msg)
        )
        progress.close()
        
        if success:
            ADDON.setSetting('last_skin_version', new_version)
            log("Skin Hebrew re-installed successfully")
            dialog.ok(
                ADDON_NAME,
                f"[COLOR lime]Arctic Fuse updated to {new_version}[/COLOR]\n\n"
                "Hebrew files re-installed successfully!\n\n"
                "Kodi will now restart."
            )
            xbmc.executebuiltin('Quit')
        else:
            log("Skin Hebrew re-install failed", xbmc.LOGERROR)
            dialog.ok(ADDON_NAME, "[COLOR red]Hebrew re-installation failed![/COLOR]")
    except Exception as e:
        progress.close()
        log(f"Error reinstalling skin Hebrew: {e}", xbmc.LOGERROR)
        dialog.ok(ADDON_NAME, f"[COLOR red]Error:[/COLOR] {str(e)}")


def build_url(query):
    return f'plugin://{ADDON_ID}/?{urlencode(query)}'


def main_menu():
    """Show main menu"""
    dialog = xbmcgui.Dialog()
    
    menu_items = [
        "[COLOR cyan]--- POV Hebrew Subtitles ---[/COLOR]",
        "[COLOR yellow]  Install / Update POV Hebrew[/COLOR]",
        "[COLOR cyan]--- FenLight Hebrew Subtitles ---[/COLOR]",
        "[COLOR yellow]  Install / Update FenLight Hebrew[/COLOR]",
        "[COLOR cyan]--- Arctic Fuse 3 Hebrew ---[/COLOR]",
        "[COLOR yellow]  Install / Update Skin Hebrew[/COLOR]",
        "[COLOR cyan]--- Tools ---[/COLOR]",
        "[COLOR orange]  Check for Updates[/COLOR]",
        "[COLOR red]  Restore / Uninstall[/COLOR]",
        "[COLOR gray]  Settings[/COLOR]"
    ]
    
    selection = dialog.select(
        f"[COLOR cyan]{ADDON_NAME}[/COLOR]",
        menu_items
    )
    
    if selection == 1:
        # POV Install/Update
        pov_menu()
    elif selection == 3:
        # FenLight Install/Update
        fenlight_menu()
    elif selection == 5:
        # Skin Install/Update
        skin_menu()
    elif selection == 7:
        # Check for updates
        check_all_updates()
    elif selection == 8:
        # Restore/Uninstall
        restore_menu()
    elif selection == 9:
        # Settings
        ADDON.openSettings()


def pov_menu():
    """POV Hebrew Subtitles menu"""
    dialog = xbmcgui.Dialog()
    installer = POVHebrewInstaller()
    
    is_installed = installer.is_installed()
    has_backup = installer.has_backup()
    current_version = installer.get_installed_version() if is_installed else "Not Installed"
    pov_installed = installer.is_pov_installed()
    
    status = f"[COLOR lime]Installed[/COLOR] (v{current_version})" if is_installed else "[COLOR red]Not Installed[/COLOR]"
    pov_status = "[COLOR lime]POV Found[/COLOR]" if pov_installed else "[COLOR red]POV Not Found[/COLOR]"
    
    menu_items = [
        f"Status: {status}",
        f"POV: {pov_status}",
        "[COLOR yellow]Install / Update[/COLOR]",
    ]
    
    if has_backup:
        backup_info = installer.get_backup_info()
        backup_date = backup_info.get('backup_date', 'Unknown') if backup_info else 'Unknown'
        menu_items.append(f"[COLOR red]Restore Original[/COLOR] ({backup_date})")
    
    if is_installed:
        menu_items.append("[COLOR red]Uninstall[/COLOR]")
    
    menu_items.append("[COLOR gray]< Back[/COLOR]")
    
    selection = dialog.select("POV Hebrew Subtitles", menu_items)
    
    if selection == 2:
        install_hebrew_subtitles(installer)
    elif selection == 3 and has_backup:
        restore_original_pov(installer)
    elif (selection == 3 and not has_backup and is_installed) or (selection == 4 and has_backup):
        uninstall_hebrew_subtitles(installer)


def skin_menu():
    """Arctic Fuse Hebrew menu"""
    dialog = xbmcgui.Dialog()
    installer = ArcticFuseHebrewInstaller()
    
    skin_installed = installer.is_skin_installed()
    hebrew_installed = installer.is_hebrew_installed()
    has_backup = installer.has_backup()
    current_version = installer.get_installed_version() if hebrew_installed else "Not Installed"
    
    skin_status = "[COLOR lime]Installed[/COLOR]" if skin_installed else "[COLOR red]Not Installed[/COLOR]"
    hebrew_status = f"[COLOR lime]Installed[/COLOR] (v{current_version})" if hebrew_installed else "[COLOR red]Not Installed[/COLOR]"
    
    menu_items = [
        f"Arctic Fuse 3: {skin_status}",
        f"Hebrew Files: {hebrew_status}",
        "[COLOR yellow]Install Skin + Hebrew[/COLOR]" if not skin_installed else "[COLOR yellow]Update Hebrew Files[/COLOR]",
    ]
    
    if has_backup:
        backup_info = installer.get_backup_info()
        backup_date = backup_info.get('backup_date', 'Unknown') if backup_info else 'Unknown'
        menu_items.append(f"[COLOR red]Restore Original Skin[/COLOR] ({backup_date})")
    
    menu_items.append("[COLOR gray]< Back[/COLOR]")
    
    selection = dialog.select("Arctic Fuse 3 Hebrew", menu_items)
    
    if selection == 2:
        install_skin_hebrew(installer)
    elif selection == 3 and has_backup:
        restore_original_skin(installer)


def fenlight_menu():
    """FenLight Hebrew Subtitles menu"""
    dialog = xbmcgui.Dialog()
    installer = FenLightHebrewInstaller()
    
    addon_installed = installer.is_addon_installed()
    hebrew_installed = installer.is_hebrew_installed()
    has_backup = installer.has_backup()
    current_version = installer.get_installed_version() if hebrew_installed else "Not Installed"
    
    addon_status = "[COLOR lime]Installed[/COLOR]" if addon_installed else "[COLOR red]Not Installed[/COLOR]"
    hebrew_status = f"[COLOR lime]Installed[/COLOR] (v{current_version})" if hebrew_installed else "[COLOR red]Not Installed[/COLOR]"
    
    menu_items = [
        f"FenLight: {addon_status}",
        f"Hebrew Subtitles: {hebrew_status}",
    ]
    
    if addon_installed:
        menu_items.append("[COLOR yellow]Install / Update Hebrew Files[/COLOR]")
    else:
        menu_items.append("[COLOR gray]FenLight not installed[/COLOR]")
    
    if has_backup:
        backup_info = installer.get_backup_info()
        backup_date = backup_info.get('backup_date', 'Unknown') if backup_info else 'Unknown'
        menu_items.append(f"[COLOR red]Restore Original[/COLOR] ({backup_date})")
    
    menu_items.append("[COLOR gray]< Back[/COLOR]")
    
    selection = dialog.select("FenLight Hebrew Subtitles", menu_items)
    
    if selection == 2 and addon_installed:
        install_fenlight_hebrew(installer)
    elif selection == 3 and has_backup:
        restore_original_fenlight(installer)


def install_fenlight_hebrew(installer):
    """Install Hebrew subtitles support to FenLight"""
    dialog = xbmcgui.Dialog()
    progress = xbmcgui.DialogProgress()
    
    hebrew_installed = installer.is_hebrew_installed()
    
    if hebrew_installed:
        msg = "Update Hebrew subtitles files for FenLight?"
    else:
        msg = "Install Hebrew subtitles support for FenLight?\n\n" \
              "This will:\n" \
              "1. Backup original files\n" \
              "2. Install Hebrew subtitle matching\n\n" \
              "Continue?"
    
    if not dialog.yesno(ADDON_NAME, msg, yeslabel="[B]Install[/B]", nolabel="Cancel"):
        return
    
    progress.create(ADDON_NAME, "Installing Hebrew subtitles support...")
    
    try:
        success = installer.install_hebrew_files(
            progress_callback=lambda msg, pct: progress.update(pct, msg)
        )
        
        progress.close()
        
        if success:
            if dialog.yesno(
                ADDON_NAME,
                "[COLOR lime]Installation completed![/COLOR]\n\n"
                "Kodi needs to restart for changes to take effect.\n\n"
                "Restart now?",
                yeslabel="[B]Restart[/B]",
                nolabel="Later"
            ):
                xbmc.executebuiltin('Quit')
        else:
            dialog.ok(ADDON_NAME, "[COLOR red]Installation failed![/COLOR]\n\nCheck the log for details.")
    
    except Exception as e:
        progress.close()
        log(f"FenLight install error: {e}", xbmc.LOGERROR)
        dialog.ok(ADDON_NAME, f"[COLOR red]Error:[/COLOR] {str(e)}")


def restore_original_fenlight(installer):
    """Restore original FenLight files"""
    dialog = xbmcgui.Dialog()
    progress = xbmcgui.DialogProgress()
    
    backup_info = installer.get_backup_info()
    backup_date = backup_info.get('backup_date', 'Unknown') if backup_info else 'Unknown'
    
    if not dialog.yesno(
        ADDON_NAME,
        f"[COLOR yellow]Restore Original FenLight[/COLOR]\n\n"
        f"Backup date: {backup_date}\n\n"
        "This will remove Hebrew subtitle support.\n\n"
        "Continue?",
        yeslabel="[B]Restore[/B]",
        nolabel="Cancel"
    ):
        return
    
    progress.create(ADDON_NAME, "Restoring...")
    
    try:
        success = installer.restore_original_files(
            progress_callback=lambda msg, pct: progress.update(pct, msg)
        )
        progress.close()
        
        if success:
            if dialog.yesno(
                ADDON_NAME,
                "[COLOR lime]Restore completed![/COLOR]\n\n"
                "Kodi needs to restart for changes to take effect.\n\n"
                "Restart now?",
                yeslabel="[B]Restart[/B]",
                nolabel="Later"
            ):
                xbmc.executebuiltin('Quit')
        else:
            dialog.ok(ADDON_NAME, "[COLOR red]Restore failed![/COLOR]\n\nCheck the log for details.")
    
    except Exception as e:
        progress.close()
        log(f"FenLight restore error: {e}", xbmc.LOGERROR)
        dialog.ok(ADDON_NAME, f"[COLOR red]Error:[/COLOR] {str(e)}")


def install_skin_hebrew(installer):
    """Install Arctic Fuse 3 with Hebrew support"""
    dialog = xbmcgui.Dialog()
    progress = xbmcgui.DialogProgress()
    
    skin_installed = installer.is_skin_installed()
    
    if skin_installed:
        # Skin already installed - just update Hebrew files
        if not dialog.yesno(ADDON_NAME, "Update Hebrew files for Arctic Fuse 3?", yeslabel="[B]Update[/B]", nolabel="Cancel"):
            return
        
        progress.create(ADDON_NAME, "Installing Hebrew files...")
        
        try:
            success = installer.install_hebrew_files(
                progress_callback=lambda msg, pct: progress.update(pct, msg)
            )
            progress.close()
            
            if success:
                if dialog.yesno(
                    ADDON_NAME,
                    "[COLOR lime]Installation completed![/COLOR]\n\n"
                    "Kodi needs to restart for skin changes.\n\n"
                    "Restart now?",
                    yeslabel="[B]Restart[/B]",
                    nolabel="Later"
                ):
                    xbmc.executebuiltin('Quit')
            else:
                dialog.ok(ADDON_NAME, "[COLOR red]Installation failed![/COLOR]\n\nCheck the log for details.")
        except Exception as e:
            progress.close()
            log(f"Skin Hebrew install error: {e}", xbmc.LOGERROR)
            dialog.ok(ADDON_NAME, f"[COLOR red]Error:[/COLOR] {str(e)}")
    
    else:
        # Skin not installed - need full install
        msg = "This will install:\n\n" \
              "1. Jurialmunkey Repository\n" \
              "2. Arctic Fuse 3 Skin\n" \
              "3. Hebrew language support\n\n" \
              "Continue?"
        
        if not dialog.yesno(ADDON_NAME, msg, yeslabel="[B]Install[/B]", nolabel="Cancel"):
            return
        
        # Step 1: Install repo
        progress.create(ADDON_NAME, "Installing repository...")
        
        try:
            if not installer.is_repo_installed():
                success = installer.install_repo(
                    progress_callback=lambda msg, pct: progress.update(pct, msg)
                )
                if not success:
                    progress.close()
                    dialog.ok(ADDON_NAME, "[COLOR red]Failed to install repository![/COLOR]")
                    return
            
            progress.close()
            
            # Step 2: Guide user to install skin (this opens addon browser)
            installer.install_skin()
            
            # Check if skin was installed
            installer._find_skin_path()
            
            if not installer.is_skin_installed():
                dialog.ok(
                    ADDON_NAME,
                    "[COLOR yellow]Skin not installed![/COLOR]\n\n"
                    "Please install Arctic Fuse 3 from the repo first,\n"
                    "then run this wizard again to add Hebrew support."
                )
                return
            
            # Step 3: Install Hebrew files
            progress.create(ADDON_NAME, "Installing Hebrew files...")
            
            success = installer.install_hebrew_files(
                progress_callback=lambda msg, pct: progress.update(pct, msg)
            )
            progress.close()
            
            if success:
                if dialog.yesno(
                    ADDON_NAME,
                    "[COLOR lime]Installation completed![/COLOR]\n\n"
                    "Kodi needs to restart for skin changes.\n\n"
                    "Restart now?",
                    yeslabel="[B]Restart[/B]",
                    nolabel="Later"
                ):
                    xbmc.executebuiltin('Quit')
            else:
                dialog.ok(ADDON_NAME, "[COLOR red]Hebrew files installation failed![/COLOR]\n\nCheck the log for details.")
        
        except Exception as e:
            progress.close()
            log(f"Skin install error: {e}", xbmc.LOGERROR)
            dialog.ok(ADDON_NAME, f"[COLOR red]Error:[/COLOR] {str(e)}")


def restore_original_skin(installer):
    """Restore original skin files"""
    dialog = xbmcgui.Dialog()
    progress = xbmcgui.DialogProgress()
    
    backup_info = installer.get_backup_info()
    backup_date = backup_info.get('backup_date', 'Unknown') if backup_info else 'Unknown'
    
    if not dialog.yesno(
        ADDON_NAME,
        f"[COLOR yellow]Restore Original Skin[/COLOR]\n\n"
        f"Backup date: {backup_date}\n\n"
        "This will remove Hebrew support from Arctic Fuse 3.\n\n"
        "Continue?",
        yeslabel="[B]Restore[/B]",
        nolabel="Cancel"
    ):
        return
    
    progress.create(ADDON_NAME, "Restoring...")
    
    try:
        success = installer.restore_skin_files(
            progress_callback=lambda msg, pct: progress.update(pct, msg)
        )
        progress.close()
        
        if success:
            if dialog.yesno(
                ADDON_NAME,
                "[COLOR lime]Restore completed![/COLOR]\n\n"
                "Restart Kodi now?",
                yeslabel="[B]Restart[/B]",
                nolabel="Later"
            ):
                xbmc.executebuiltin('Quit')
        else:
            dialog.ok(ADDON_NAME, "[COLOR red]Restore failed![/COLOR]")
    
    except Exception as e:
        progress.close()
        dialog.ok(ADDON_NAME, f"[COLOR red]Error:[/COLOR] {str(e)}")


def check_all_updates():
    """Check for updates for POV, FenLight and Skin"""
    dialog = xbmcgui.Dialog()
    progress = xbmcgui.DialogProgress()
    
    progress.create(ADDON_NAME, "Checking for updates...")
    
    updates = []
    
    try:
        # Check POV
        progress.update(20, "Checking POV Hebrew...")
        pov_installer = POVHebrewInstaller()
        if pov_installer.is_installed():
            try:
                has_update, version = pov_installer.check_for_updates()
                if has_update:
                    updates.append(f"POV Hebrew: {version}")
            except:
                pass
        
        # Check FenLight
        progress.update(50, "Checking FenLight Hebrew...")
        fenlight_installer = FenLightHebrewInstaller()
        if fenlight_installer.is_hebrew_installed():
            try:
                update_info = fenlight_installer.check_for_updates()
                if update_info.get('has_update'):
                    updates.append(f"FenLight Hebrew: v{update_info['remote_version']}")
            except:
                pass
        
        # Check Skin
        progress.update(80, "Checking Skin Hebrew...")
        skin_installer = ArcticFuseHebrewInstaller()
        if skin_installer.is_hebrew_installed():
            try:
                has_update, version = skin_installer.check_for_updates()
                if has_update:
                    updates.append(f"Skin Hebrew: {version}")
            except:
                pass
        
        progress.close()
        
        if updates:
            dialog.ok(ADDON_NAME, f"[COLOR lime]Updates available:[/COLOR]\n\n" + "\n".join(updates))
        else:
            dialog.ok(ADDON_NAME, "[COLOR lime]Everything is up to date![/COLOR]")
    
    except Exception as e:
        progress.close()
        dialog.ok(ADDON_NAME, f"[COLOR red]Error:[/COLOR] {str(e)}")


def restore_menu():
    """Restore/Uninstall menu"""
    dialog = xbmcgui.Dialog()
    
    pov_installer = POVHebrewInstaller()
    fenlight_installer = FenLightHebrewInstaller()
    skin_installer = ArcticFuseHebrewInstaller()
    
    menu_items = []
    actions = []
    
    if pov_installer.has_backup():
        menu_items.append("[COLOR red]Restore Original POV[/COLOR]")
        actions.append(('pov_restore', pov_installer))
    
    if pov_installer.is_installed():
        menu_items.append("[COLOR red]Uninstall POV Hebrew[/COLOR]")
        actions.append(('pov_uninstall', pov_installer))
    
    if fenlight_installer.has_backup():
        menu_items.append("[COLOR red]Restore Original FenLight[/COLOR]")
        actions.append(('fenlight_restore', fenlight_installer))
    
    if fenlight_installer.is_hebrew_installed():
        menu_items.append("[COLOR red]Uninstall FenLight Hebrew[/COLOR]")
        actions.append(('fenlight_uninstall', fenlight_installer))
    
    if skin_installer.has_backup():
        menu_items.append("[COLOR red]Restore Original Skin[/COLOR]")
        actions.append(('skin_restore', skin_installer))
    
    if not menu_items:
        dialog.ok(ADDON_NAME, "Nothing to restore or uninstall.")
        return
    
    menu_items.append("[COLOR gray]< Back[/COLOR]")
    
    selection = dialog.select("Restore / Uninstall", menu_items)
    
    if selection >= 0 and selection < len(actions):
        action, installer = actions[selection]
        if action == 'pov_restore':
            restore_original_pov(installer)
        elif action == 'pov_uninstall':
            uninstall_hebrew_subtitles(installer)
        elif action == 'fenlight_restore':
            restore_original_fenlight(installer)
        elif action == 'fenlight_uninstall':
            restore_original_fenlight(installer)
        elif action == 'skin_restore':
            restore_original_skin(installer)


def install_hebrew_subtitles(installer):
    """Install or update Hebrew subtitles feature"""
    dialog = xbmcgui.Dialog()
    progress = xbmcgui.DialogProgress()
    
    # Confirm installation
    if not dialog.yesno(
        ADDON_NAME,
        "[COLOR yellow]Install Hebrew Subtitles feature for POV?[/COLOR]\n\n"
        "This will download and install the required files.",
        yeslabel="[B]Install[/B]",
        nolabel="Cancel"
    ):
        return
    
    progress.create(ADDON_NAME, "Starting installation...")
    
    try:
        success = installer.install(progress_callback=lambda msg, pct: progress.update(pct, msg))
        progress.close()
        
        if success:
            if dialog.yesno(
                ADDON_NAME,
                "[COLOR lime]Installation completed successfully![/COLOR]\n\n"
                "Kodi needs to restart for changes to take effect.\n\n"
                "Restart now?",
                yeslabel="[B]Restart[/B]",
                nolabel="Later"
            ):
                xbmc.executebuiltin('Quit')
        else:
            dialog.ok(
                ADDON_NAME,
                "[COLOR red]Installation failed![/COLOR]\n\n"
                "Check the log for more details."
            )
    except Exception as e:
        progress.close()
        log(f"Installation error: {e}", xbmc.LOGERROR)
        dialog.ok(ADDON_NAME, f"[COLOR red]Error:[/COLOR] {str(e)}")


def check_updates(installer):
    """Check for updates"""
    dialog = xbmcgui.Dialog()
    progress = xbmcgui.DialogProgress()
    
    progress.create(ADDON_NAME, "Checking for updates...")
    
    try:
        has_update, remote_version = installer.check_for_updates()
        progress.close()
        
        if has_update:
            if dialog.yesno(
                ADDON_NAME,
                f"[COLOR lime]Update available![/COLOR]\n\n"
                f"Current version: {installer.get_installed_version()}\n"
                f"New version: {remote_version}\n\n"
                "Update now?",
                yeslabel="[B]Update[/B]",
                nolabel="Later"
            ):
                install_hebrew_subtitles(installer)
        else:
            dialog.ok(
                ADDON_NAME,
                "[COLOR lime]You are up to date![/COLOR]\n\n"
                f"Current version: {installer.get_installed_version()}"
            )
    except Exception as e:
        progress.close()
        log(f"Update check error: {e}", xbmc.LOGERROR)
        dialog.ok(ADDON_NAME, f"[COLOR red]Error checking for updates:[/COLOR]\n{str(e)}")


def uninstall_hebrew_subtitles(installer):
    """Uninstall Hebrew subtitles feature"""
    dialog = xbmcgui.Dialog()
    
    if not dialog.yesno(
        ADDON_NAME,
        "[COLOR red]Remove Hebrew Subtitles feature?[/COLOR]\n\n"
        "This will remove all files added to POV.",
        yeslabel="[B]Remove[/B]",
        nolabel="Cancel"
    ):
        return
    
    try:
        success = installer.uninstall()
        
        if success:
            dialog.ok(ADDON_NAME, "[COLOR lime]Uninstall completed successfully![/COLOR]")
        else:
            dialog.ok(ADDON_NAME, "[COLOR red]Uninstall failed![/COLOR]")
    except Exception as e:
        log(f"Uninstall error: {e}", xbmc.LOGERROR)
        dialog.ok(ADDON_NAME, f"[COLOR red]Error:[/COLOR] {str(e)}")


def restore_original_pov(installer):
    """Restore original POV files from backup"""
    dialog = xbmcgui.Dialog()
    progress = xbmcgui.DialogProgress()
    
    backup_info = installer.get_backup_info()
    backup_date = backup_info.get('backup_date', 'Unknown') if backup_info else 'Unknown'
    pov_version = backup_info.get('pov_version', 'Unknown') if backup_info else 'Unknown'
    
    if not dialog.yesno(
        ADDON_NAME,
        f"[COLOR yellow]Restore Original POV[/COLOR]\n\n"
        f"Backup date: {backup_date}\n"
        f"POV version: {pov_version}\n\n"
        "[COLOR red]This will remove the Hebrew Subtitles feature\n"
        "and restore POV to its original state.[/COLOR]\n\n"
        "Continue?",
        yeslabel="[B]Restore[/B]",
        nolabel="Cancel"
    ):
        return
    
    progress.create(ADDON_NAME, "Restoring original files...")
    
    try:
        success = installer.restore_pov_files(
            progress_callback=lambda msg, pct: progress.update(pct, msg)
        )
        progress.close()
        
        if success:
            dialog.ok(
                ADDON_NAME,
                "[COLOR lime]Restore completed successfully![/COLOR]\n\n"
                "POV has been restored to its original state.\n"
                "Recommended to restart Kodi."
            )
        else:
            dialog.ok(
                ADDON_NAME,
                "[COLOR red]Restore failed![/COLOR]\n\n"
                "Check the log for more details."
            )
    except Exception as e:
        progress.close()
        log(f"Restore error: {e}", xbmc.LOGERROR)
        dialog.ok(ADDON_NAME, f"[COLOR red]Error:[/COLOR] {str(e)}")


if __name__ == '__main__':
    # Parse URL parameters
    params = dict(parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    mode = params.get('mode', '')
    
    if mode == 'reinstall_fenlight':
        # Called from FenLight updater after FenLight updates itself
        reinstall_fenlight_after_update()
    elif mode == 'reinstall_pov':
        # Called from POV updater after POV updates itself
        reinstall_pov_after_update()
    elif mode == 'reinstall_skin':
        # Called after skin updates itself
        reinstall_skin_after_update()
    else:
        main_menu()
