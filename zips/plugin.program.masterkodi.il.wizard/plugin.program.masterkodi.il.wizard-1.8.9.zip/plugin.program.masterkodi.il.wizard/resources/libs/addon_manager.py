# -*- coding: utf-8 -*-
"""
MasterKodi IL Wizard - Addon Manager
"""
import os
import json
import xbmc
import xbmcgui
import xbmcaddon

from resources.libs.config import (
    ADDON_ID, ADDON_NAME, ADDONS, POV_ADDON_ID, FENLIGHT_ADDON_ID,
    COLOR_SUCCESS, COLOR_ERROR
)


def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f'[{ADDON_ID}] AddonManager: {msg}', level)


class AddonManager:
    def __init__(self):
        self.dialog = xbmcgui.Dialog()
    
    def is_installed(self, addon_id):
        return os.path.exists(os.path.join(ADDONS, addon_id))
    
    def is_enabled(self, addon_id):
        try:
            query = {"jsonrpc": "2.0", "method": "Addons.GetAddonDetails",
                     "params": {"addonid": addon_id, "properties": ["enabled"]}, "id": 1}
            resp = json.loads(xbmc.executeJSONRPC(json.dumps(query)))
            return resp.get('result', {}).get('addon', {}).get('enabled', False)
        except:
            return False
    
    def set_enabled(self, addon_id, enabled):
        try:
            query = {"jsonrpc": "2.0", "method": "Addons.SetAddonEnabled",
                     "params": {"addonid": addon_id, "enabled": enabled}, "id": 1}
            resp = json.loads(xbmc.executeJSONRPC(json.dumps(query)))
            return resp.get('result') == 'OK'
        except:
            return False
    
    def get_version(self, addon_id):
        try:
            return xbmcaddon.Addon(addon_id).getAddonInfo('version')
        except:
            return None
    
    def get_status(self):
        return {
            'pov': {
                'installed': self.is_installed(POV_ADDON_ID),
                'enabled': self.is_enabled(POV_ADDON_ID),
                'version': self.get_version(POV_ADDON_ID)
            },
            'fenlight': {
                'installed': self.is_installed(FENLIGHT_ADDON_ID),
                'enabled': self.is_enabled(FENLIGHT_ADDON_ID),
                'version': self.get_version(FENLIGHT_ADDON_ID)
            }
        }
    
    def switch_to_pov(self):
        s = True
        if self.is_installed(POV_ADDON_ID):
            s = self.set_enabled(POV_ADDON_ID, True) and s
        if self.is_installed(FENLIGHT_ADDON_ID):
            s = self.set_enabled(FENLIGHT_ADDON_ID, False) and s
        return s
    
    def switch_to_fenlight(self):
        s = True
        if self.is_installed(FENLIGHT_ADDON_ID):
            s = self.set_enabled(FENLIGHT_ADDON_ID, True) and s
        if self.is_installed(POV_ADDON_ID):
            s = self.set_enabled(POV_ADDON_ID, False) and s
        return s
    
    def enable_both(self):
        s = True
        if self.is_installed(POV_ADDON_ID):
            s = self.set_enabled(POV_ADDON_ID, True) and s
        if self.is_installed(FENLIGHT_ADDON_ID):
            s = self.set_enabled(FENLIGHT_ADDON_ID, True) and s
        return s


def addon_manager_menu():
    dialog = xbmcgui.Dialog()
    manager = AddonManager()
    
    while True:
        status = manager.get_status()
        
        pov_str = "[COLOR gray]Not Installed[/COLOR]"
        if status['pov']['installed']:
            pov_str = f"[COLOR {'lime' if status['pov']['enabled'] else 'red'}]{'Enabled' if status['pov']['enabled'] else 'Disabled'}[/COLOR] v{status['pov']['version']}"
        
        fen_str = "[COLOR gray]Not Installed[/COLOR]"
        if status['fenlight']['installed']:
            fen_str = f"[COLOR {'lime' if status['fenlight']['enabled'] else 'red'}]{'Enabled' if status['fenlight']['enabled'] else 'Disabled'}[/COLOR] v{status['fenlight']['version']}"
        
        items = [
            f"[COLOR cyan]POV:[/COLOR] {pov_str}",
            f"[COLOR cyan]FenLight:[/COLOR] {fen_str}",
            "",
            "[COLOR yellow]Use POV Only[/COLOR]",
            "[COLOR yellow]Use FenLight Only[/COLOR]",
            "[COLOR yellow]Enable Both[/COLOR]",
            "",
            "[COLOR gray]< Back[/COLOR]"
        ]
        
        sel = dialog.select("Addon Manager", items)
        
        if sel < 0 or sel == len(items) - 1:
            break
        
        if sel == 3:
            if not status['pov']['installed']:
                dialog.ok(ADDON_NAME, "POV is not installed!")
                continue
            if manager.switch_to_pov():
                dialog.notification(ADDON_NAME, "Switched to POV", xbmcgui.NOTIFICATION_INFO, 3000)
        
        elif sel == 4:
            if not status['fenlight']['installed']:
                dialog.ok(ADDON_NAME, "FenLight is not installed!")
                continue
            if manager.switch_to_fenlight():
                dialog.notification(ADDON_NAME, "Switched to FenLight", xbmcgui.NOTIFICATION_INFO, 3000)
        
        elif sel == 5:
            if manager.enable_both():
                dialog.notification(ADDON_NAME, "Both addons enabled", xbmcgui.NOTIFICATION_INFO, 3000)
