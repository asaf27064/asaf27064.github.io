# -*- coding: utf-8 -*-
"""
Hebrew Files Installer for POV, FenLight, and Arctic Fuse Skin
With version detection from installed files
"""
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
import os
import json
import shutil
import time
import re

try:
    from urllib.request import urlopen, Request
except ImportError:
    from urllib2 import urlopen, Request

import zipfile
import io

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_DATA = xbmcvfs.translatePath(f'special://userdata/addon_data/{ADDON_ID}')
ADDONS_PATH = xbmcvfs.translatePath('special://home/addons/')

# GitHub URLs
GITHUB_BASE_URL = "https://raw.githubusercontent.com/asaf27064/pov-modified-heb/main"
POV_VERSION_URL = f"{GITHUB_BASE_URL}/version.json"
POV_ZIP_URL = f"{GITHUB_BASE_URL}/pov_hebrew_subtitles.zip"
FENLIGHT_VERSION_URL = f"{GITHUB_BASE_URL}/fenlight_version.json"
FENLIGHT_ZIP_URL = f"{GITHUB_BASE_URL}/fenlight_hebrew_subtitles.zip"
SKIN_VERSION_URL = f"{GITHUB_BASE_URL}/skin_version.json"
SKIN_ZIP_URL = f"{GITHUB_BASE_URL}/skin_hebrew_files.zip"

# Backup folders
POV_BACKUP_FOLDER = os.path.join(ADDON_DATA, 'pov_backup')
FENLIGHT_BACKUP_FOLDER = os.path.join(ADDON_DATA, 'fenlight_backup')
SKIN_BACKUP_FOLDER = os.path.join(ADDON_DATA, 'skin_backup')


def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f'[{ADDON_ID}] {msg}', level)


def get_version_from_file(filepath):
    """Read version from a version.txt file"""
    try:
        if os.path.exists(filepath):
            with open(filepath, 'r', encoding='utf-8') as f:
                return f.read().strip()
    except Exception as e:
        log(f"Error reading version file {filepath}: {e}")
    return None


def get_version_from_settings_xml(settings_path, setting_id='hebrew_subtitles.installed_version'):
    """Read version from settings.xml default value"""
    try:
        if os.path.exists(settings_path):
            with open(settings_path, 'r', encoding='utf-8') as f:
                content = f.read()
            # Look for the version setting
            match = re.search(rf'id="{setting_id}"[^>]*default="([^"]+)"', content)
            if match:
                return match.group(1)
            # Also check for version in comment
            match = re.search(r'Version:\s*(\d+\.\d+\.\d+)', content)
            if match:
                return match.group(1)
    except Exception as e:
        log(f"Error reading settings.xml {settings_path}: {e}")
    return None


# ============================================
# POV HEBREW INSTALLER
# ============================================
class POVHebrewInstaller:
    def __init__(self):
        self.addon_id = 'plugin.video.pov'
        self.addon_path = None
        self.backup_folder = POV_BACKUP_FOLDER
        self._find_addon_path()
    
    def _find_addon_path(self):
        """Find POV addon path"""
        try:
            addon = xbmcaddon.Addon(self.addon_id)
            self.addon_path = addon.getAddonInfo('path')
            log(f"Found POV at: {self.addon_path}")
        except Exception as e:
            log(f"POV not found: {e}", xbmc.LOGWARNING)
            self.addon_path = None
    
    def is_pov_installed(self):
        """Check if POV is installed"""
        return self.addon_path is not None and os.path.exists(self.addon_path)
    
    def is_installed(self):
        """Check if Hebrew files are installed"""
        if not self.is_pov_installed():
            return False
        kodirdil_path = os.path.join(self.addon_path, 'resources', 'lib', 'kodirdil')
        return os.path.exists(kodirdil_path)
    
    def get_installed_version(self):
        """Get installed Hebrew version from multiple sources"""
        if not self.is_installed():
            return None
        
        # Method 1: Check version.txt in kodirdil folder
        version_file = os.path.join(self.addon_path, 'resources', 'lib', 'kodirdil', 'version.txt')
        version = get_version_from_file(version_file)
        if version:
            log(f"POV Hebrew version from file: {version}")
            return version
        
        # Method 2: Check addon's settings for hebrew_subtitles.installed_version
        try:
            addon = xbmcaddon.Addon(self.addon_id)
            version = addon.getSetting('hebrew_subtitles.installed_version')
            if version:
                log(f"POV Hebrew version from settings: {version}")
                return version
        except:
            pass
        
        # Method 3: Check wizard's saved setting
        version = ADDON.getSetting('pov_hebrew_version')
        if version and version != '0' and version != '':
            log(f"POV Hebrew version from wizard settings: {version}")
            return version
        
        # Installed but version unknown
        log("POV Hebrew installed but version unknown")
        return 'installed'
    
    def has_backup(self):
        """Check if backup exists"""
        if not os.path.exists(self.backup_folder):
            return False
        return os.path.exists(os.path.join(self.backup_folder, 'backup_info.json'))
    
    def backup_files(self, progress_callback=None):
        """Backup original POV files"""
        if not self.is_pov_installed():
            return False
        
        try:
            os.makedirs(self.backup_folder, exist_ok=True)
            
            if progress_callback:
                progress_callback("Backing up original files...", 5)
            
            files_to_backup = [
                ('resources/lib/windows/sources.py', 'windows_sources.py'),
                ('resources/lib/modules/sources.py', 'modules_sources.py'),
            ]
            
            backed_up = []
            for src_rel, backup_name in files_to_backup:
                src = os.path.join(self.addon_path, src_rel)
                dst = os.path.join(self.backup_folder, backup_name)
                if os.path.exists(src):
                    shutil.copy2(src, dst)
                    backed_up.append({'original': src_rel, 'backup': backup_name})
            
            # Save backup info
            backup_info = {
                'backup_date': time.strftime('%Y-%m-%d %H:%M:%S'),
                'files': backed_up
            }
            with open(os.path.join(self.backup_folder, 'backup_info.json'), 'w') as f:
                json.dump(backup_info, f, indent=2)
            
            return True
        except Exception as e:
            log(f"POV backup error: {e}", xbmc.LOGERROR)
            return False
    
    def install(self, progress_callback=None):
        """Download and install Hebrew files"""
        if not self.is_pov_installed():
            log("POV not installed!")
            return False
        
        try:
            # Backup first
            if not self.has_backup():
                self.backup_files(progress_callback)
            
            if progress_callback:
                progress_callback("Downloading Hebrew files...", 15)
            
            # Download ZIP
            log(f"Downloading POV Hebrew from {POV_ZIP_URL}")
            req = Request(POV_ZIP_URL, headers={'User-Agent': 'Kodi'})
            response = urlopen(req, timeout=60)
            zip_data = response.read()
            
            if progress_callback:
                progress_callback("Extracting files...", 40)
            
            # Extract files
            lib_path = os.path.join(self.addon_path, 'resources', 'lib')
            resources_path = os.path.join(self.addon_path, 'resources')
            
            zip_buffer = io.BytesIO(zip_data)
            with zipfile.ZipFile(zip_buffer, 'r') as zf:
                for member in zf.namelist():
                    if member.endswith('/'):
                        continue
                    
                    # Determine destination
                    if member.startswith('kodirdil/'):
                        dest = os.path.join(lib_path, member)
                    elif member.startswith('modules/'):
                        dest = os.path.join(lib_path, member)
                    elif member.startswith('windows/'):
                        dest = os.path.join(lib_path, member)
                    elif member == 'settings.xml':
                        # Merge settings - handled separately
                        settings_content = zf.read(member)
                        self._merge_settings(settings_content)
                        continue
                    else:
                        continue
                    
                    os.makedirs(os.path.dirname(dest), exist_ok=True)
                    with zf.open(member) as src, open(dest, 'wb') as dst:
                        dst.write(src.read())
                    log(f"Installed: {dest}")
            
            if progress_callback:
                progress_callback("Saving version...", 90)
            
            # Get and save version
            try:
                req = Request(POV_VERSION_URL, headers={'User-Agent': 'Kodi'})
                response = urlopen(req, timeout=10)
                version_data = json.loads(response.read().decode('utf-8'))
                version = version_data.get('version', '1.0.0')
            except:
                version = '1.0.0'
            
            ADDON.setSetting('pov_hebrew_version', version)
            
            if progress_callback:
                progress_callback("Installation complete!", 100)
            
            log(f"POV Hebrew installation complete! Version: {version}")
            return True
            
        except Exception as e:
            log(f"POV installation error: {e}", xbmc.LOGERROR)
            return False
    
    def _merge_settings(self, new_settings_content):
        """Merge Hebrew settings into POV's settings.xml"""
        try:
            pov_settings_path = os.path.join(self.addon_path, 'resources', 'settings.xml')
            
            if not os.path.exists(pov_settings_path):
                log("POV settings.xml not found!")
                return
            
            with open(pov_settings_path, 'r', encoding='utf-8') as f:
                original = f.read()
            
            # Check if Hebrew settings already exist
            if 'Hebrew Subtitles' in original:
                log("Hebrew settings already in POV settings.xml")
                return
            
            # Parse the new settings to get just the category content
            new_content = new_settings_content.decode('utf-8')
            match = re.search(r'(<category label="Hebrew Subtitles">.*?</category>)', new_content, re.DOTALL)
            if not match:
                log("Could not find Hebrew category in new settings")
                return
            
            hebrew_category = match.group(1)
            
            # Insert before </settings>
            merged = original.replace('</settings>', f'\n\t{hebrew_category}\n</settings>')
            
            with open(pov_settings_path, 'w', encoding='utf-8') as f:
                f.write(merged)
            
            log("Merged Hebrew settings into POV settings.xml")
            
        except Exception as e:
            log(f"Error merging settings: {e}", xbmc.LOGERROR)
    
    def uninstall(self, progress_callback=None):
        """Remove Hebrew files"""
        if not self.is_pov_installed():
            return False
        
        try:
            lib_path = os.path.join(self.addon_path, 'resources', 'lib')
            
            # Remove kodirdil folder
            kodirdil_path = os.path.join(lib_path, 'kodirdil')
            if os.path.exists(kodirdil_path):
                shutil.rmtree(kodirdil_path)
                log("Removed kodirdil folder")
            
            # Restore backed up files if available
            if self.has_backup():
                with open(os.path.join(self.backup_folder, 'backup_info.json'), 'r') as f:
                    backup_info = json.load(f)
                
                for file_info in backup_info.get('files', []):
                    src = os.path.join(self.backup_folder, file_info['backup'])
                    dst = os.path.join(self.addon_path, file_info['original'])
                    if os.path.exists(src):
                        shutil.copy2(src, dst)
                        log(f"Restored: {dst}")
            
            ADDON.setSetting('pov_hebrew_version', '')
            log("POV Hebrew uninstalled")
            return True
            
        except Exception as e:
            log(f"POV uninstall error: {e}", xbmc.LOGERROR)
            return False


# ============================================
# FENLIGHT HEBREW INSTALLER
# ============================================
class FenLightHebrewInstaller:
    def __init__(self):
        self.addon_id = 'plugin.video.fenlight'
        self.addon_path = None
        self.backup_folder = FENLIGHT_BACKUP_FOLDER
        self._find_addon_path()
    
    def _find_addon_path(self):
        """Find FenLight addon path"""
        try:
            addon = xbmcaddon.Addon(self.addon_id)
            self.addon_path = addon.getAddonInfo('path')
            log(f"Found FenLight at: {self.addon_path}")
        except Exception as e:
            log(f"FenLight not found: {e}", xbmc.LOGWARNING)
            self.addon_path = None
    
    def is_addon_installed(self):
        """Check if FenLight is installed"""
        return self.addon_path is not None and os.path.exists(self.addon_path)
    
    def is_hebrew_installed(self):
        """Check if Hebrew files are installed"""
        if not self.is_addon_installed():
            return False
        kodirdil_path = os.path.join(self.addon_path, 'resources', 'lib', 'kodirdil')
        return os.path.exists(kodirdil_path)
    
    def is_installed(self):
        """Alias for is_hebrew_installed"""
        return self.is_hebrew_installed()
    
    def get_installed_version(self):
        """Get installed Hebrew version"""
        if not self.is_hebrew_installed():
            return None
        
        # Method 1: Check version.txt in kodirdil folder
        version_file = os.path.join(self.addon_path, 'resources', 'lib', 'kodirdil', 'version.txt')
        version = get_version_from_file(version_file)
        if version:
            log(f"FenLight Hebrew version from file: {version}")
            return version
        
        # Method 2: Check wizard's saved setting
        version = ADDON.getSetting('fenlight_hebrew_version')
        if version and version != '0' and version != '':
            log(f"FenLight Hebrew version from wizard settings: {version}")
            return version
        
        log("FenLight Hebrew installed but version unknown")
        return 'installed'
    
    def has_backup(self):
        """Check if backup exists"""
        if not os.path.exists(self.backup_folder):
            return False
        return os.path.exists(os.path.join(self.backup_folder, 'backup_info.json'))
    
    def backup_files(self, progress_callback=None):
        """Backup original files"""
        if not self.is_addon_installed():
            return False
        
        try:
            os.makedirs(self.backup_folder, exist_ok=True)
            
            files_to_backup = [
                ('resources/lib/modules/sources.py', 'modules_sources.py'),
                ('resources/lib/windows/sources.py', 'windows_sources.py'),
                ('resources/lib/caches/settings_cache.py', 'settings_cache.py'),
                ('resources/lib/apis/tmdb_api.py', 'tmdb_api.py'),
                ('resources/skins/Default/1080i/settings_manager.xml', 'settings_manager.xml'),
            ]
            
            backed_up = []
            for src_rel, backup_name in files_to_backup:
                src = os.path.join(self.addon_path, src_rel)
                dst = os.path.join(self.backup_folder, backup_name)
                if os.path.exists(src):
                    shutil.copy2(src, dst)
                    backed_up.append({'original': src_rel, 'backup': backup_name})
            
            backup_info = {
                'backup_date': time.strftime('%Y-%m-%d %H:%M:%S'),
                'files': backed_up
            }
            with open(os.path.join(self.backup_folder, 'backup_info.json'), 'w') as f:
                json.dump(backup_info, f, indent=2)
            
            return True
        except Exception as e:
            log(f"FenLight backup error: {e}", xbmc.LOGERROR)
            return False
    
    def install_hebrew_files(self, progress_callback=None):
        """Download and install Hebrew files"""
        if not self.is_addon_installed():
            log("FenLight not installed!")
            return False
        
        try:
            if not self.has_backup():
                self.backup_files(progress_callback)
            
            if progress_callback:
                progress_callback("Downloading Hebrew files...", 15)
            
            log(f"Downloading FenLight Hebrew from {FENLIGHT_ZIP_URL}")
            req = Request(FENLIGHT_ZIP_URL, headers={'User-Agent': 'Kodi'})
            response = urlopen(req, timeout=60)
            zip_data = response.read()
            
            if progress_callback:
                progress_callback("Extracting files...", 40)
            
            lib_path = os.path.join(self.addon_path, 'resources', 'lib')
            resources_path = os.path.join(self.addon_path, 'resources')
            
            zip_buffer = io.BytesIO(zip_data)
            with zipfile.ZipFile(zip_buffer, 'r') as zf:
                for member in zf.namelist():
                    if member.endswith('/'):
                        continue
                    
                    if member.startswith('kodirdil/'):
                        dest = os.path.join(lib_path, member)
                    elif member.startswith('modules/'):
                        dest = os.path.join(lib_path, member)
                    elif member.startswith('windows/'):
                        dest = os.path.join(lib_path, member)
                    elif member.startswith('caches/'):
                        dest = os.path.join(lib_path, member)
                    elif member.startswith('apis/'):
                        dest = os.path.join(lib_path, member)
                    elif member.startswith('indexers/'):
                        dest = os.path.join(lib_path, member)
                    elif member.startswith('skins/'):
                        dest = os.path.join(resources_path, member)
                    elif member == 'service.py':
                        dest = os.path.join(lib_path, member)
                    else:
                        continue
                    
                    os.makedirs(os.path.dirname(dest), exist_ok=True)
                    with zf.open(member) as src, open(dest, 'wb') as dst:
                        dst.write(src.read())
                    log(f"Installed: {dest}")
            
            if progress_callback:
                progress_callback("Saving version...", 90)
            
            try:
                req = Request(FENLIGHT_VERSION_URL, headers={'User-Agent': 'Kodi'})
                response = urlopen(req, timeout=10)
                version_data = json.loads(response.read().decode('utf-8'))
                version = version_data.get('version', '1.0.0')
            except:
                version = '1.0.0'
            
            ADDON.setSetting('fenlight_hebrew_version', version)
            
            if progress_callback:
                progress_callback("Installation complete!", 100)
            
            log(f"FenLight Hebrew installation complete! Version: {version}")
            return True
            
        except Exception as e:
            log(f"FenLight installation error: {e}", xbmc.LOGERROR)
            return False
    
    def install(self, progress_callback=None):
        """Alias for install_hebrew_files"""
        return self.install_hebrew_files(progress_callback)
    
    def uninstall(self, progress_callback=None):
        """Remove Hebrew files"""
        if not self.is_addon_installed():
            return False
        
        try:
            lib_path = os.path.join(self.addon_path, 'resources', 'lib')
            
            kodirdil_path = os.path.join(lib_path, 'kodirdil')
            if os.path.exists(kodirdil_path):
                shutil.rmtree(kodirdil_path)
            
            if self.has_backup():
                with open(os.path.join(self.backup_folder, 'backup_info.json'), 'r') as f:
                    backup_info = json.load(f)
                
                for file_info in backup_info.get('files', []):
                    src = os.path.join(self.backup_folder, file_info['backup'])
                    dst = os.path.join(self.addon_path, file_info['original'])
                    if os.path.exists(src):
                        shutil.copy2(src, dst)
            
            ADDON.setSetting('fenlight_hebrew_version', '')
            log("FenLight Hebrew uninstalled")
            return True
            
        except Exception as e:
            log(f"FenLight uninstall error: {e}", xbmc.LOGERROR)
            return False


# ============================================
# SKIN HEBREW INSTALLER (Arctic Fuse)
# ============================================
class ArcticFuseHebrewInstaller:
    def __init__(self):
        self.skin_id = 'skin.arctic.fuse.3'
        self.skin_path = os.path.join(ADDONS_PATH, self.skin_id)
        self.backup_folder = SKIN_BACKUP_FOLDER
    
    def is_skin_installed(self):
        """Check if Arctic Fuse skin is installed"""
        return os.path.exists(self.skin_path)
    
    def is_installed(self):
        """Check if Hebrew files are installed"""
        if not self.is_skin_installed():
            return False
        # Check for Hebrew font
        font_path = os.path.join(self.skin_path, 'fonts', 'Rubik-VariableFont_wght.ttf')
        return os.path.exists(font_path)
    
    def is_hebrew_installed(self):
        """Alias for is_installed - for compatibility with default.py"""
        return self.is_installed()
    
    def get_installed_version(self):
        """Get installed Hebrew version"""
        if not self.is_installed():
            return None
        
        # Method 1: Check version file
        version_file = os.path.join(self.skin_path, 'hebrew_version.txt')
        version = get_version_from_file(version_file)
        if version:
            log(f"Skin Hebrew version from file: {version}")
            return version
        
        # Method 2: Check wizard setting
        version = ADDON.getSetting('skin_hebrew_version')
        if version and version != '0' and version != '':
            log(f"Skin Hebrew version from wizard settings: {version}")
            return version
        
        log("Skin Hebrew installed but version unknown")
        return 'installed'
    
    def has_backup(self):
        """Check if backup exists"""
        if not os.path.exists(self.backup_folder):
            return False
        return os.path.exists(os.path.join(self.backup_folder, 'backup_info.json'))
    
    def backup_files(self, progress_callback=None):
        """Backup original files"""
        if not self.is_skin_installed():
            return False
        
        try:
            os.makedirs(self.backup_folder, exist_ok=True)
            
            files_to_backup = [
                ('1080i/Font.xml', 'Font.xml'),
                ('1080i/Includes_Font.xml', 'Includes_Font.xml'),
            ]
            
            backed_up = []
            for src_rel, backup_name in files_to_backup:
                src = os.path.join(self.skin_path, src_rel)
                dst = os.path.join(self.backup_folder, backup_name)
                if os.path.exists(src):
                    shutil.copy2(src, dst)
                    backed_up.append({'original': src_rel, 'backup': backup_name})
            
            backup_info = {
                'backup_date': time.strftime('%Y-%m-%d %H:%M:%S'),
                'files': backed_up
            }
            with open(os.path.join(self.backup_folder, 'backup_info.json'), 'w') as f:
                json.dump(backup_info, f, indent=2)
            
            return True
        except Exception as e:
            log(f"Skin backup error: {e}", xbmc.LOGERROR)
            return False
    
    def install(self, progress_callback=None):
        """Download and install Hebrew files"""
        if not self.is_skin_installed():
            log("Arctic Fuse skin not installed!")
            return False
        
        try:
            if not self.has_backup():
                self.backup_files(progress_callback)
            
            if progress_callback:
                progress_callback("Downloading Hebrew files...", 15)
            
            log(f"Downloading Skin Hebrew from {SKIN_ZIP_URL}")
            req = Request(SKIN_ZIP_URL, headers={'User-Agent': 'Kodi'})
            response = urlopen(req, timeout=60)
            zip_data = response.read()
            
            if progress_callback:
                progress_callback("Extracting files...", 40)
            
            installed_count = 0
            zip_buffer = io.BytesIO(zip_data)
            with zipfile.ZipFile(zip_buffer, 'r') as zf:
                for member in zf.namelist():
                    if member.endswith('/'):
                        continue
                    
                    # Handle both formats:
                    # 1. skin_hebrew_files/skin.arctic.fuse.3/...
                    # 2. skin.arctic.fuse.3/...
                    rel_path = None
                    if 'skin.arctic.fuse.3/' in member:
                        # Find where skin.arctic.fuse.3/ starts and take everything after it
                        idx = member.find('skin.arctic.fuse.3/')
                        rel_path = member[idx + len('skin.arctic.fuse.3/'):]
                    
                    if rel_path:
                        dest = os.path.join(self.skin_path, rel_path)
                        
                        os.makedirs(os.path.dirname(dest), exist_ok=True)
                        with zf.open(member) as src, open(dest, 'wb') as dst:
                            dst.write(src.read())
                        log(f"Installed: {dest}")
                        installed_count += 1
            
            log(f"Total files installed: {installed_count}")
            
            if progress_callback:
                progress_callback("Saving version...", 90)
            
            try:
                req = Request(SKIN_VERSION_URL, headers={'User-Agent': 'Kodi'})
                response = urlopen(req, timeout=10)
                version_data = json.loads(response.read().decode('utf-8'))
                version = version_data.get('version', '1.0.0')
            except:
                version = '1.0.0'
            
            ADDON.setSetting('skin_hebrew_version', version)
            
            if progress_callback:
                progress_callback("Installation complete!", 100)
            
            log(f"Skin Hebrew installation complete! Version: {version}")
            return True
            
        except Exception as e:
            log(f"Skin installation error: {e}", xbmc.LOGERROR)
            return False
    
    def install_hebrew_files(self, progress_callback=None):
        """Alias for install - for compatibility with default.py"""
        return self.install(progress_callback)
    
    def uninstall(self, progress_callback=None):
        """Remove Hebrew files"""
        if not self.is_skin_installed():
            return False
        
        try:
            # Remove fonts
            fonts_to_remove = [
                'fonts/Rubik-VariableFont_wght.ttf',
                'fonts/Rubik-Italic-VariableFont_wght.ttf',
            ]
            for font in fonts_to_remove:
                path = os.path.join(self.skin_path, font)
                if os.path.exists(path):
                    os.remove(path)
            
            # Remove Hebrew language folder
            he_lang = os.path.join(self.skin_path, 'language', 'resource.language.he_il')
            if os.path.exists(he_lang):
                shutil.rmtree(he_lang)
            
            # Remove version file
            version_file = os.path.join(self.skin_path, 'hebrew_version.txt')
            if os.path.exists(version_file):
                os.remove(version_file)
            
            # Restore backed up files
            if self.has_backup():
                with open(os.path.join(self.backup_folder, 'backup_info.json'), 'r') as f:
                    backup_info = json.load(f)
                
                for file_info in backup_info.get('files', []):
                    src = os.path.join(self.backup_folder, file_info['backup'])
                    dst = os.path.join(self.skin_path, file_info['original'])
                    if os.path.exists(src):
                        shutil.copy2(src, dst)
            
            ADDON.setSetting('skin_hebrew_version', '')
            log("Skin Hebrew uninstalled")
            return True
            
        except Exception as e:
            log(f"Skin uninstall error: {e}", xbmc.LOGERROR)
            return False


# Alias for backwards compatibility
SkinHebrewInstaller = ArcticFuseHebrewInstaller


# ============================================
# HELPER FUNCTIONS
# ============================================
def detect_hebrew_installed_version(addon_type):
    """
    Detect installed Hebrew version for an addon.
    
    Args:
        addon_type: 'pov', 'fenlight', or 'skin'
    
    Returns:
        str: Version string, 'installed' if version unknown, or None if not installed
    """
    if addon_type == 'pov':
        installer = POVHebrewInstaller()
        if installer.is_installed():
            return installer.get_installed_version()
        return None
        
    elif addon_type == 'fenlight':
        installer = FenLightHebrewInstaller()
        if installer.is_hebrew_installed():
            return installer.get_installed_version()
        return None
        
    elif addon_type == 'skin':
        installer = ArcticFuseHebrewInstaller()
        if installer.is_installed():
            return installer.get_installed_version()
        return None
    
    return None
