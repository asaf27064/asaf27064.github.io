# -*- coding: utf-8 -*-
"""
MasterKodi IL Wizard - Beautiful Dialog-Based UI
"""
import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import os
import sys
import json

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_PATH = ADDON.getAddonInfo('path')
ADDON_VERSION = ADDON.getAddonInfo('version')
ADDON_DATA = xbmcvfs.translatePath(f'special://userdata/addon_data/{ADDON_ID}')

# Colors
COLOR_HEADER = 'FF00BFFF'  # Deep Sky Blue
COLOR_SUCCESS = 'FF00FF00'  # Lime
COLOR_WARNING = 'FFFFFF00'  # Yellow
COLOR_ERROR = 'FFFF0000'   # Red
COLOR_INFO = 'FF87CEEB'    # Sky Blue
COLOR_GOLD = 'FFFFD700'    # Gold
COLOR_WHITE = 'FFFFFFFF'
COLOR_GRAY = 'FFA0A0A0'


def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f'[{ADDON_ID}] {msg}', level)


def color(text, hex_color):
    """Wrap text with color"""
    return f'[COLOR {hex_color}]{text}[/COLOR]'


def bold(text):
    """Make text bold"""
    return f'[B]{text}[/B]'


# ============================================
# STATUS HELPERS
# ============================================
def get_pov_status():
    """Get POV Hebrew installation status"""
    try:
        from resources.libs.installer import POVHebrewInstaller
        installer = POVHebrewInstaller()
        
        if not installer.is_pov_installed():
            return {'addon': False, 'hebrew': False, 'version': None}
        
        hebrew_installed = installer.is_installed()
        version = installer.get_installed_version() if hebrew_installed else None
        
        return {'addon': True, 'hebrew': hebrew_installed, 'version': version}
    except Exception as e:
        log(f"Error getting POV status: {e}")
        return {'addon': False, 'hebrew': False, 'version': None}


def get_fenlight_status():
    """Get FenLight Hebrew installation status"""
    try:
        from resources.libs.installer import FenLightHebrewInstaller
        installer = FenLightHebrewInstaller()
        
        if not installer.is_addon_installed():
            return {'addon': False, 'hebrew': False, 'version': None}
        
        hebrew_installed = installer.is_hebrew_installed()
        version = installer.get_installed_version() if hebrew_installed else None
        
        return {'addon': True, 'hebrew': hebrew_installed, 'version': version}
    except Exception as e:
        log(f"Error getting FenLight status: {e}")
        return {'addon': False, 'hebrew': False, 'version': None}


def get_skin_status():
    """Get Skin Hebrew installation status"""
    try:
        from resources.libs.installer import ArcticFuseHebrewInstaller
        installer = ArcticFuseHebrewInstaller()
        
        if not installer.is_skin_installed():
            return {'addon': False, 'hebrew': False, 'version': None}
        
        hebrew_installed = installer.is_installed()
        version = installer.get_installed_version() if hebrew_installed else None
        
        return {'addon': True, 'hebrew': hebrew_installed, 'version': version}
    except Exception as e:
        log(f"Error getting Skin status: {e}")
        return {'addon': False, 'hebrew': False, 'version': None}


def format_status(status):
    """Format status for display"""
    if not status['addon']:
        return color('לא מותקן', COLOR_GRAY)
    elif not status['hebrew']:
        return color('עברית לא מותקנת', COLOR_WARNING)
    else:
        ver = status['version'] if status['version'] and status['version'] != 'installed' else ''
        if ver:
            return color(f'מותקן (v{ver})', COLOR_SUCCESS)
        else:
            return color('מותקן', COLOR_SUCCESS)


# ============================================
# MAIN MENU
# ============================================
def main_menu():
    """Show beautiful main menu"""
    dialog = xbmcgui.Dialog()
    
    while True:
        # Get current statuses
        pov_status = get_pov_status()
        fenlight_status = get_fenlight_status()
        skin_status = get_skin_status()
        
        # Build menu items
        menu_items = [
            f"{bold('POV Hebrew')}  -  {format_status(pov_status)}",
            f"{bold('FenLight Hebrew')}  -  {format_status(fenlight_status)}",
            f"{bold('Arctic Fuse Skin Hebrew')}  -  {format_status(skin_status)}",
            f"{color('─────────────────────────────────', COLOR_GRAY)}",
            f"{bold('Build Installation')}",
            f"{bold('Maintenance')}",
            f"{bold('Backup & Restore')}",
            f"{bold('Settings')}",
        ]
        
        # Show menu
        header = f"{color('MasterKodi IL Wizard', COLOR_GOLD)} v{ADDON_VERSION}"
        
        selection = dialog.select(
            header,
            menu_items,
            useDetails=False
        )
        
        if selection == -1:  # Back/Cancel
            break
        elif selection == 0:  # POV
            pov_menu()
        elif selection == 1:  # FenLight
            fenlight_menu()
        elif selection == 2:  # Skin
            skin_menu()
        elif selection == 3:  # Separator - do nothing
            continue
        elif selection == 4:  # Build
            build_menu()
        elif selection == 5:  # Maintenance
            maintenance_menu()
        elif selection == 6:  # Backup
            backup_menu()
        elif selection == 7:  # Settings
            ADDON.openSettings()


# ============================================
# POV MENU
# ============================================
def pov_menu():
    """POV Hebrew submenu"""
    dialog = xbmcgui.Dialog()
    
    while True:
        status = get_pov_status()
        
        if not status['addon']:
            dialog.ok(
                'POV',
                f"{color('POV לא מותקן!', COLOR_ERROR)}\n\n"
                "יש להתקין את POV לפני התקנת קבצי העברית."
            )
            return
        
        menu_items = []
        
        if status['hebrew']:
            ver_text = f" (v{status['version']})" if status['version'] and status['version'] != 'installed' else ''
            menu_items = [
                f"{bold('עדכון קבצי עברית')}",
                f"{bold('הסרת קבצי עברית')}",
                f"{bold('מידע')}{ver_text}",
            ]
        else:
            menu_items = [
                f"{bold('התקנת קבצי עברית')}",
            ]
        
        menu_items.append(f"{color('חזרה', COLOR_GRAY)}")
        
        selection = dialog.select(
            f"{color('POV Hebrew', COLOR_HEADER)} - {format_status(status)}",
            menu_items
        )
        
        if selection == -1 or menu_items[selection].startswith('[COLOR'):
            return
        
        if status['hebrew']:
            if selection == 0:  # Update
                install_pov_hebrew()
            elif selection == 1:  # Uninstall
                uninstall_pov_hebrew()
            elif selection == 2:  # Info
                show_pov_info()
        else:
            if selection == 0:  # Install
                install_pov_hebrew()


def install_pov_hebrew():
    """Install POV Hebrew files"""
    dialog = xbmcgui.Dialog()
    
    if not dialog.yesno(
        'התקנת עברית ל-POV',
        f"{bold('האם להתקין את קבצי העברית?')}\n\n"
        "הקבצים יורדו מ-GitHub ויותקנו אוטומטית."
    ):
        return
    
    progress = xbmcgui.DialogProgress()
    progress.create('התקנת עברית ל-POV', 'מתחיל...')
    
    try:
        from resources.libs.installer import POVHebrewInstaller
        installer = POVHebrewInstaller()
        
        def update_progress(msg, pct):
            progress.update(pct, msg)
        
        success = installer.install(progress_callback=update_progress)
        progress.close()
        
        if success:
            dialog.ok(
                'הצלחה!',
                f"{color('קבצי העברית הותקנו בהצלחה!', COLOR_SUCCESS)}\n\n"
                "מומלץ להפעיל מחדש את Kodi."
            )
            
            if dialog.yesno('הפעלה מחדש', 'האם להפעיל מחדש את Kodi עכשיו?'):
                xbmc.executebuiltin('Quit')
        else:
            dialog.ok('שגיאה', color('ההתקנה נכשלה!', COLOR_ERROR))
            
    except Exception as e:
        progress.close()
        dialog.ok('שגיאה', f"{color('שגיאה:', COLOR_ERROR)}\n{str(e)}")


def uninstall_pov_hebrew():
    """Uninstall POV Hebrew files"""
    dialog = xbmcgui.Dialog()
    
    if not dialog.yesno(
        'הסרת עברית מ-POV',
        f"{color('האם להסיר את קבצי העברית?', COLOR_WARNING)}\n\n"
        "הקבצים המקוריים ישוחזרו מהגיבוי."
    ):
        return
    
    try:
        from resources.libs.installer import POVHebrewInstaller
        installer = POVHebrewInstaller()
        
        success = installer.uninstall()
        
        if success:
            dialog.ok('הצלחה', color('קבצי העברית הוסרו!', COLOR_SUCCESS))
        else:
            dialog.ok('שגיאה', color('ההסרה נכשלה!', COLOR_ERROR))
            
    except Exception as e:
        dialog.ok('שגיאה', f"{color('שגיאה:', COLOR_ERROR)}\n{str(e)}")


def show_pov_info():
    """Show POV info"""
    dialog = xbmcgui.Dialog()
    status = get_pov_status()
    
    try:
        pov_addon = xbmcaddon.Addon('plugin.video.pov')
        pov_version = pov_addon.getAddonInfo('version')
    except:
        pov_version = 'לא ידוע'
    
    hebrew_ver = status['version'] if status['version'] and status['version'] != 'installed' else 'לא ידוע'
    
    dialog.textviewer(
        'POV - מידע',
        f"[B]גירסת POV:[/B] {pov_version}\n"
        f"[B]גירסת עברית:[/B] {hebrew_ver}\n"
        f"[B]סטטוס:[/B] {'מותקן' if status['hebrew'] else 'לא מותקן'}\n\n"
        "[B]קבצי עברית כוללים:[/B]\n"
        "- תמיכה בכתוביות עבריות אוטומטיות\n"
        "- התאמה לשירותי כתוביות ישראליים\n"
        "- Ktuvit, Wizdom, OpenSubtitles"
    )


# ============================================
# FENLIGHT MENU
# ============================================
def fenlight_menu():
    """FenLight Hebrew submenu"""
    dialog = xbmcgui.Dialog()
    
    while True:
        status = get_fenlight_status()
        
        if not status['addon']:
            dialog.ok(
                'FenLight',
                f"{color('FenLight לא מותקן!', COLOR_ERROR)}\n\n"
                "יש להתקין את FenLight לפני התקנת קבצי העברית."
            )
            return
        
        menu_items = []
        
        if status['hebrew']:
            ver_text = f" (v{status['version']})" if status['version'] and status['version'] != 'installed' else ''
            menu_items = [
                f"{bold('עדכון קבצי עברית')}",
                f"{bold('הסרת קבצי עברית')}",
                f"{bold('מידע')}{ver_text}",
            ]
        else:
            menu_items = [
                f"{bold('התקנת קבצי עברית')}",
            ]
        
        menu_items.append(f"{color('חזרה', COLOR_GRAY)}")
        
        selection = dialog.select(
            f"{color('FenLight Hebrew', COLOR_HEADER)} - {format_status(status)}",
            menu_items
        )
        
        if selection == -1 or menu_items[selection].startswith('[COLOR FFA0A0A0'):
            return
        
        if status['hebrew']:
            if selection == 0:  # Update
                install_fenlight_hebrew()
            elif selection == 1:  # Uninstall
                uninstall_fenlight_hebrew()
            elif selection == 2:  # Info
                show_fenlight_info()
        else:
            if selection == 0:  # Install
                install_fenlight_hebrew()


def install_fenlight_hebrew():
    """Install FenLight Hebrew files"""
    dialog = xbmcgui.Dialog()
    
    if not dialog.yesno(
        'התקנת עברית ל-FenLight',
        f"{bold('האם להתקין את קבצי העברית?')}\n\n"
        "הקבצים יורדו מ-GitHub ויותקנו אוטומטית."
    ):
        return
    
    progress = xbmcgui.DialogProgress()
    progress.create('התקנת עברית ל-FenLight', 'מתחיל...')
    
    try:
        from resources.libs.installer import FenLightHebrewInstaller
        installer = FenLightHebrewInstaller()
        
        def update_progress(msg, pct):
            progress.update(pct, msg)
        
        success = installer.install_hebrew_files(progress_callback=update_progress)
        progress.close()
        
        if success:
            dialog.ok(
                'הצלחה!',
                f"{color('קבצי העברית הותקנו בהצלחה!', COLOR_SUCCESS)}\n\n"
                "מומלץ להפעיל מחדש את Kodi."
            )
            
            if dialog.yesno('הפעלה מחדש', 'האם להפעיל מחדש את Kodi עכשיו?'):
                xbmc.executebuiltin('Quit')
        else:
            dialog.ok('שגיאה', color('ההתקנה נכשלה!', COLOR_ERROR))
            
    except Exception as e:
        progress.close()
        dialog.ok('שגיאה', f"{color('שגיאה:', COLOR_ERROR)}\n{str(e)}")


def uninstall_fenlight_hebrew():
    """Uninstall FenLight Hebrew files"""
    dialog = xbmcgui.Dialog()
    
    if not dialog.yesno(
        'הסרת עברית מ-FenLight',
        f"{color('האם להסיר את קבצי העברית?', COLOR_WARNING)}\n\n"
        "הקבצים המקוריים ישוחזרו מהגיבוי."
    ):
        return
    
    try:
        from resources.libs.installer import FenLightHebrewInstaller
        installer = FenLightHebrewInstaller()
        
        success = installer.uninstall()
        
        if success:
            dialog.ok('הצלחה', color('קבצי העברית הוסרו!', COLOR_SUCCESS))
        else:
            dialog.ok('שגיאה', color('ההסרה נכשלה!', COLOR_ERROR))
            
    except Exception as e:
        dialog.ok('שגיאה', f"{color('שגיאה:', COLOR_ERROR)}\n{str(e)}")


def show_fenlight_info():
    """Show FenLight info"""
    dialog = xbmcgui.Dialog()
    status = get_fenlight_status()
    
    try:
        fl_addon = xbmcaddon.Addon('plugin.video.fenlight')
        fl_version = fl_addon.getAddonInfo('version')
    except:
        fl_version = 'לא ידוע'
    
    hebrew_ver = status['version'] if status['version'] and status['version'] != 'installed' else 'לא ידוע'
    
    dialog.textviewer(
        'FenLight - מידע',
        f"[B]גירסת FenLight:[/B] {fl_version}\n"
        f"[B]גירסת עברית:[/B] {hebrew_ver}\n"
        f"[B]סטטוס:[/B] {'מותקן' if status['hebrew'] else 'לא מותקן'}\n\n"
        "[B]קבצי עברית כוללים:[/B]\n"
        "- תמיכה בכתוביות עבריות אוטומטיות\n"
        "- תקצירים בעברית\n"
        "- התאמה לשירותי כתוביות ישראליים"
    )


# ============================================
# SKIN MENU
# ============================================
def skin_menu():
    """Skin Hebrew submenu"""
    dialog = xbmcgui.Dialog()
    
    while True:
        status = get_skin_status()
        
        if not status['addon']:
            dialog.ok(
                'Arctic Fuse Skin',
                f"{color('הסקין לא מותקן!', COLOR_ERROR)}\n\n"
                "יש להתקין את Arctic Fuse 3 לפני התקנת קבצי העברית."
            )
            return
        
        menu_items = []
        
        if status['hebrew']:
            ver_text = f" (v{status['version']})" if status['version'] and status['version'] != 'installed' else ''
            menu_items = [
                f"{bold('עדכון קבצי עברית')}",
                f"{bold('הסרת קבצי עברית')}",
                f"{bold('מידע')}{ver_text}",
            ]
        else:
            menu_items = [
                f"{bold('התקנת קבצי עברית')}",
            ]
        
        menu_items.append(f"{color('חזרה', COLOR_GRAY)}")
        
        selection = dialog.select(
            f"{color('Arctic Fuse Skin Hebrew', COLOR_HEADER)} - {format_status(status)}",
            menu_items
        )
        
        if selection == -1 or menu_items[selection].startswith('[COLOR FFA0A0A0'):
            return
        
        if status['hebrew']:
            if selection == 0:  # Update
                install_skin_hebrew()
            elif selection == 1:  # Uninstall
                uninstall_skin_hebrew()
            elif selection == 2:  # Info
                show_skin_info()
        else:
            if selection == 0:  # Install
                install_skin_hebrew()


def install_skin_hebrew():
    """Install Skin Hebrew files"""
    dialog = xbmcgui.Dialog()
    
    if not dialog.yesno(
        'התקנת עברית לסקין',
        f"{bold('האם להתקין את קבצי העברית?')}\n\n"
        "הקבצים יורדו מ-GitHub ויותקנו אוטומטית.\n"
        "כולל: פונטים עבריים ותרגום ממשק."
    ):
        return
    
    progress = xbmcgui.DialogProgress()
    progress.create('התקנת עברית לסקין', 'מתחיל...')
    
    try:
        from resources.libs.installer import ArcticFuseHebrewInstaller
        installer = ArcticFuseHebrewInstaller()
        
        def update_progress(msg, pct):
            progress.update(pct, msg)
        
        success = installer.install(progress_callback=update_progress)
        progress.close()
        
        if success:
            dialog.ok(
                'הצלחה!',
                f"{color('קבצי העברית הותקנו בהצלחה!', COLOR_SUCCESS)}\n\n"
                "יש להפעיל מחדש את Kodi כדי לראות את השינויים."
            )
            
            if dialog.yesno('הפעלה מחדש', 'האם להפעיל מחדש את Kodi עכשיו?'):
                xbmc.executebuiltin('Quit')
        else:
            dialog.ok('שגיאה', color('ההתקנה נכשלה!', COLOR_ERROR))
            
    except Exception as e:
        progress.close()
        dialog.ok('שגיאה', f"{color('שגיאה:', COLOR_ERROR)}\n{str(e)}")


def uninstall_skin_hebrew():
    """Uninstall Skin Hebrew files"""
    dialog = xbmcgui.Dialog()
    
    if not dialog.yesno(
        'הסרת עברית מהסקין',
        f"{color('האם להסיר את קבצי העברית?', COLOR_WARNING)}\n\n"
        "הקבצים המקוריים ישוחזרו מהגיבוי."
    ):
        return
    
    try:
        from resources.libs.installer import ArcticFuseHebrewInstaller
        installer = ArcticFuseHebrewInstaller()
        
        success = installer.uninstall()
        
        if success:
            dialog.ok('הצלחה', color('קבצי העברית הוסרו!', COLOR_SUCCESS))
        else:
            dialog.ok('שגיאה', color('ההסרה נכשלה!', COLOR_ERROR))
            
    except Exception as e:
        dialog.ok('שגיאה', f"{color('שגיאה:', COLOR_ERROR)}\n{str(e)}")


def show_skin_info():
    """Show Skin info"""
    dialog = xbmcgui.Dialog()
    status = get_skin_status()
    
    hebrew_ver = status['version'] if status['version'] and status['version'] != 'installed' else 'לא ידוע'
    
    dialog.textviewer(
        'Arctic Fuse Skin - מידע',
        f"[B]סקין:[/B] Arctic Fuse 3\n"
        f"[B]גירסת עברית:[/B] {hebrew_ver}\n"
        f"[B]סטטוס:[/B] {'מותקן' if status['hebrew'] else 'לא מותקן'}\n\n"
        "[B]קבצי עברית כוללים:[/B]\n"
        "- פונט Rubik לתמיכה בעברית\n"
        "- תרגום ממשק לעברית\n"
        "- התאמות RTL"
    )


# ============================================
# BUILD MENU
# ============================================
def build_menu():
    """Build installation menu"""
    dialog = xbmcgui.Dialog()
    
    while True:
        menu_items = [
            f"{bold('התקנת בילד')}",
            f"{bold('עדכון בילד')}",
            f"{bold('מידע על בילד נוכחי')}",
            f"{color('חזרה', COLOR_GRAY)}",
        ]
        
        selection = dialog.select(
            color('Build Installation', COLOR_HEADER),
            menu_items
        )
        
        if selection == -1 or selection == 3:
            return
        elif selection == 0:
            install_build()
        elif selection == 1:
            update_build()
        elif selection == 2:
            show_build_info()


def install_build():
    """Install a build - uses builds_menu which handles skin selection"""
    try:
        from resources.libs.builds import builds_menu
        builds_menu()
    except Exception as e:
        dialog = xbmcgui.Dialog()
        dialog.ok('שגיאה', f"{color('שגיאה:', COLOR_ERROR)}\n{str(e)}")


def update_build():
    """Update current build"""
    dialog = xbmcgui.Dialog()
    dialog.ok('עדכון בילד', 'פיצ\'ר זה יהיה זמין בקרוב!')


def show_build_info():
    """Show current build info"""
    dialog = xbmcgui.Dialog()
    
    build_name = ADDON.getSetting('buildname') or 'לא מותקן'
    build_version = ADDON.getSetting('buildversion') or 'N/A'
    
    dialog.textviewer(
        'מידע על הבילד',
        f"[B]בילד נוכחי:[/B] {build_name}\n"
        f"[B]גירסה:[/B] {build_version}\n"
    )


# ============================================
# MAINTENANCE MENU
# ============================================
def maintenance_menu():
    """Maintenance menu"""
    dialog = xbmcgui.Dialog()
    
    while True:
        menu_items = [
            f"{bold('ניקוי Cache')}",
            f"{bold('ניקוי Packages')}",
            f"{bold('ניקוי Thumbnails')}",
            f"{bold('ניקוי הכל')}",
            f"{bold('Force Close Kodi')}",
            f"{color('חזרה', COLOR_GRAY)}",
        ]
        
        selection = dialog.select(
            color('Maintenance', COLOR_HEADER),
            menu_items
        )
        
        if selection == -1 or selection == 5:
            return
        elif selection == 0:
            clear_cache()
        elif selection == 1:
            clear_packages()
        elif selection == 2:
            clear_thumbnails()
        elif selection == 3:
            clear_all()
        elif selection == 4:
            force_close()


def clear_cache():
    """Clear cache"""
    dialog = xbmcgui.Dialog()
    
    if not dialog.yesno('ניקוי Cache', 'האם לנקות את ה-Cache?'):
        return
    
    try:
        from resources.libs.maintenance import clear_cache as do_clear
        cleared = do_clear()
        dialog.ok('הצלחה', f'{color("Cache נוקה!", COLOR_SUCCESS)}\n\nנמחקו: {cleared}')
    except Exception as e:
        dialog.ok('שגיאה', str(e))


def clear_packages():
    """Clear packages"""
    dialog = xbmcgui.Dialog()
    
    if not dialog.yesno('ניקוי Packages', 'האם לנקות את ה-Packages?'):
        return
    
    try:
        from resources.libs.maintenance import clear_packages as do_clear
        cleared = do_clear()
        dialog.ok('הצלחה', f'{color("Packages נוקה!", COLOR_SUCCESS)}\n\nנמחקו: {cleared}')
    except Exception as e:
        dialog.ok('שגיאה', str(e))


def clear_thumbnails():
    """Clear thumbnails"""
    dialog = xbmcgui.Dialog()
    
    if not dialog.yesno('ניקוי Thumbnails', 'האם לנקות את ה-Thumbnails?\n\nפעולה זו תמחק את כל התמונות השמורות.'):
        return
    
    try:
        from resources.libs.maintenance import clear_thumbnails as do_clear
        cleared = do_clear()
        dialog.ok('הצלחה', f'{color("Thumbnails נוקה!", COLOR_SUCCESS)}\n\nנמחקו: {cleared}')
    except Exception as e:
        dialog.ok('שגיאה', str(e))


def clear_all():
    """Clear everything"""
    dialog = xbmcgui.Dialog()
    
    if not dialog.yesno(
        'ניקוי הכל',
        f'{color("אזהרה!", COLOR_WARNING)}\n\n'
        'פעולה זו תנקה:\n'
        '- Cache\n'
        '- Packages\n'
        '- Thumbnails\n\n'
        'האם להמשיך?'
    ):
        return
    
    try:
        from resources.libs.maintenance import clear_cache, clear_packages, clear_thumbnails
        
        progress = xbmcgui.DialogProgress()
        progress.create('ניקוי', 'מנקה...')
        
        progress.update(0, 'מנקה Cache...')
        cache = clear_cache()
        
        progress.update(33, 'מנקה Packages...')
        packages = clear_packages()
        
        progress.update(66, 'מנקה Thumbnails...')
        thumbs = clear_thumbnails()
        
        progress.close()
        
        dialog.ok(
            'הצלחה',
            f'{color("הכל נוקה!", COLOR_SUCCESS)}\n\n'
            f'Cache: {cache}\n'
            f'Packages: {packages}\n'
            f'Thumbnails: {thumbs}'
        )
    except Exception as e:
        dialog.ok('שגיאה', str(e))


def force_close():
    """Force close Kodi"""
    dialog = xbmcgui.Dialog()
    
    if dialog.yesno('סגירת Kodi', 'האם לסגור את Kodi?'):
        xbmc.executebuiltin('Quit')


# ============================================
# BACKUP MENU
# ============================================
def backup_menu():
    """Backup & Restore menu"""
    dialog = xbmcgui.Dialog()
    
    while True:
        menu_items = [
            f"{bold('יצירת גיבוי')}",
            f"{bold('שחזור מגיבוי')}",
            f"{bold('מחיקת גיבויים')}",
            f"{color('חזרה', COLOR_GRAY)}",
        ]
        
        selection = dialog.select(
            color('Backup & Restore', COLOR_HEADER),
            menu_items
        )
        
        if selection == -1 or selection == 3:
            return
        elif selection == 0:
            create_backup()
        elif selection == 1:
            restore_backup()
        elif selection == 2:
            delete_backups()


def create_backup():
    """Create backup"""
    dialog = xbmcgui.Dialog()
    dialog.ok('גיבוי', 'פיצ\'ר זה יהיה זמין בקרוב!')


def restore_backup():
    """Restore from backup"""
    dialog = xbmcgui.Dialog()
    dialog.ok('שחזור', 'פיצ\'ר זה יהיה זמין בקרוב!')


def delete_backups():
    """Delete backups"""
    dialog = xbmcgui.Dialog()
    dialog.ok('מחיקת גיבויים', 'פיצ\'ר זה יהיה זמין בקרוב!')


# ============================================
# PARAMETER PARSING
# ============================================
def parse_params():
    """Parse addon parameters from sys.argv"""
    params = {}
    try:
        log(f"sys.argv = {sys.argv}")
        
        if len(sys.argv) > 2:
            param_string = sys.argv[2]
        elif len(sys.argv) > 1:
            param_string = sys.argv[1]
        else:
            return params
        
        if param_string:
            if param_string.startswith('?'):
                param_string = param_string[1:]
            
            pairs = param_string.split('&')
            for pair in pairs:
                if '=' in pair:
                    key, value = pair.split('=', 1)
                    params[key] = value
                elif pair:
                    params[pair] = 'true'
        
        log(f"Parsed params: {params}")
        
    except Exception as e:
        log(f"Error parsing params: {e}", xbmc.LOGERROR)
    
    return params


# ============================================
# ENTRY POINT
# ============================================
if __name__ == '__main__':
    log(f"Wizard started - v{ADDON_VERSION}")
    
    params = parse_params()
    mode = params.get('mode', '')
    
    if mode == 'builds':
        log("Opening Build Installation directly")
        build_menu()
    elif mode == 'pov':
        pov_menu()
    elif mode == 'fenlight':
        fenlight_menu()
    elif mode == 'skin':
        skin_menu()
    elif mode == 'maintenance':
        maintenance_menu()
    elif mode == 'backup':
        backup_menu()
    else:
        main_menu()
    
    log("Wizard closed")
