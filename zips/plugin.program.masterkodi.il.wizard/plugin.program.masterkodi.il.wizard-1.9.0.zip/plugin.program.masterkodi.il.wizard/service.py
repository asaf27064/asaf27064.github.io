# -*- coding: utf-8 -*-
"""
MasterKodi IL Wizard - Service
- Checks for FenLight AND Skin updates on startup
- Combined update prompt for both
- Monitors for addon updates via Kodi notifications
- Reinstalls Hebrew files after updates
"""
import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import json
import os
import re
import shutil
import zipfile
import urllib.request
import ssl
import time

try:
    import requests
except ImportError:
    requests = None

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'

ADDONS_PATH = xbmcvfs.translatePath('special://home/addons/')
PACKAGES_PATH = xbmcvfs.translatePath('special://home/addons/packages/')

# FenLight update sources
FENLIGHT_SOURCES = [
    {
        'name': 'FenlightAnonyMouse GitHub',
        'version_url': 'https://raw.githubusercontent.com/FenlightAnonyMouse/FenlightAnonyMouse.github.io/main/packages/fen_light_version',
        'zip_url': 'https://raw.githubusercontent.com/FenlightAnonyMouse/FenlightAnonyMouse.github.io/main/packages/plugin.video.fenlight-{version}.zip',
        'api_url': 'https://api.github.com/repos/FenlightAnonyMouse/FenlightAnonyMouse.github.io/contents/packages'
    },
    {
        'name': 'FenlightAnonyMouse Pages',
        'version_url': None,
        'zip_url': 'https://fenlightanonymouse.github.io/packages/plugin.video.fenlight-{version}.zip',
        'list_url': 'https://fenlightanonymouse.github.io/packages/'
    },
    {
        'name': 'tikipeter Repository',
        'version_url': 'https://github.com/tikimaniac/repository.tikipeter/raw/main/packages/fen_light_version',
        'zip_url': 'https://github.com/tikimaniac/repository.tikipeter/raw/main/packages/plugin.video.fenlight-{version}.zip',
    }
]

# Arctic Fuse Skin source
SKIN_GITHUB_API = 'https://api.github.com/repos/jurialmunkey/skin.arctic.fuse.3/releases/latest'
SKIN_ZIP_URL = 'https://github.com/jurialmunkey/skin.arctic.fuse.3/archive/refs/tags/v{version}.zip'


def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f'[{ADDON_ID}] {msg}', level)


log("Service loading...")


def url_get(url, timeout=15):
    """Download URL content"""
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        
        req = urllib.request.Request(url, headers={'User-Agent': 'Kodi/20.0'})
        with urllib.request.urlopen(req, timeout=timeout, context=ctx) as response:
            return response.read()
    except Exception as e:
        log(f"URL fetch error for {url}: {e}")
        return None


def download_file(url, dest, progress_dialog, title="מוריד..."):
    """Download file with resume support, retries, and progress display"""
    try:
        if requests is None:
            log("requests module not available, falling back to url_get")
            data = url_get(url, timeout=120)
            if data:
                os.makedirs(os.path.dirname(dest), exist_ok=True)
                with open(dest, 'wb') as f:
                    f.write(data)
                return True
            return False

        path = os.path.split(dest)[0]
        if not os.path.exists(path):
            os.makedirs(path)

        log(f"Downloading: {url}")

        mb = 1024 * 1024
        chunk_size = 512 * 1024
        max_retries = 3
        backoff_ms = 1200

        for attempt in range(1, max_retries + 1):
            try:
                resume_from = 0
                mode = 'wb'
                headers = {'user-agent': USER_AGENT}

                if os.path.exists(dest):
                    try:
                        resume_from = os.path.getsize(dest)
                    except:
                        resume_from = 0

                if resume_from > 0:
                    headers['Range'] = f'bytes={resume_from}-'
                    mode = 'ab'

                start_time = time.time()
                last_ui = 0.0
                total_size = None

                with requests.get(
                    url,
                    headers=headers,
                    timeout=(10, 120),
                    stream=True,
                    allow_redirects=True
                ) as response:

                    if not response:
                        raise Exception("No response")

                    if response.status_code == 416:
                        if os.path.exists(dest) and os.path.getsize(dest) > 0:
                            log("Already fully downloaded (416).")
                            return True
                        raise Exception("Range not satisfiable")

                    response.raise_for_status()

                    cl = response.headers.get('content-length')
                    cr = response.headers.get('content-range')

                    if cr and '/' in cr:
                        try:
                            total_size = int(cr.split('/')[-1])
                        except:
                            total_size = None
                    elif cl:
                        try:
                            total_size = int(cl) + (resume_from if response.status_code == 206 else 0)
                        except:
                            total_size = None

                    with open(dest, mode) as f:
                        downloaded = resume_from

                        for chunk in response.iter_content(chunk_size=chunk_size):
                            if not chunk:
                                continue
                            f.write(chunk)
                            downloaded += len(chunk)

                            now = time.time()
                            if now - last_ui < 0.15 and total_size:
                                continue
                            last_ui = now

                            if total_size and total_size > 0:
                                done = int(100 * downloaded / total_size)
                            else:
                                done = 0

                            elapsed = max(now - start_time, 0.001)
                            bps = (downloaded - resume_from) / elapsed
                            eta = int((total_size - downloaded) / bps) if (total_size and bps > 0 and downloaded < total_size) else 0

                            speed = bps / 1024
                            unit = 'KB'
                            if speed >= 1024:
                                speed /= 1024
                                unit = 'MB'

                            if total_size:
                                currently_downloaded = f'[COLOR yellow][B]גודל:[/B] [COLOR lime]{downloaded/mb:.2f}[/COLOR] MB מתוך [COLOR lime]{total_size/mb:.2f}[/COLOR] MB[/COLOR]'
                            else:
                                currently_downloaded = f'[COLOR yellow][B]גודל:[/B] [COLOR lime]{downloaded/mb:.2f}[/COLOR] MB[/COLOR]'

                            div = divmod(eta, 60)
                            speed_line = f'[COLOR yellow][B]מהירות:[/B] [COLOR cyan]{speed:.2f}[/COLOR] {unit}/s'
                            if total_size:
                                speed_line += f' | [B]זמן:[/B] [COLOR orange]{div[0]:02d}:{div[1]:02d}[/COLOR]'
                            speed_line += '[/COLOR]'

                            progress_dialog.update(done, f'{title}\n' + currently_downloaded + '\n' + speed_line)

                if total_size and os.path.exists(dest) and os.path.getsize(dest) >= total_size:
                    log(f"Downloaded: {dest}")
                    return True

                if (not total_size) and os.path.exists(dest) and os.path.getsize(dest) > 0:
                    log(f"Downloaded (unknown size): {dest}")
                    return True

                raise Exception("Download incomplete")

            except Exception as e:
                log(f"Download attempt {attempt}/{max_retries} failed: {e}", xbmc.LOGWARNING)
                if attempt < max_retries:
                    try:
                        xbmc.sleep(backoff_ms * attempt)
                    except:
                        pass
                    continue
                return False

    except Exception as e:
        log(f"Download error: {e}", xbmc.LOGERROR)
        return False


def get_addon_version(addon_id):
    """Get addon version from addon.xml"""
    try:
        addon_xml = os.path.join(ADDONS_PATH, addon_id, 'addon.xml')
        if os.path.exists(addon_xml):
            with open(addon_xml, 'r', encoding='utf-8') as f:
                content = f.read()
                match = re.search(r'<addon[^>]*version="([^"]+)"', content)
                if match:
                    return match.group(1)
    except:
        pass
    return None


def version_compare(v1, v2):
    """Compare versions. Returns: 1 if v1>v2, -1 if v1<v2, 0 if equal"""
    try:
        def normalize(v):
            parts = []
            for part in v.split('.'):
                num = ''.join(c for c in part if c.isdigit())
                parts.append(int(num) if num else 0)
            return parts
        
        v1_parts = normalize(v1)
        v2_parts = normalize(v2)
        
        max_len = max(len(v1_parts), len(v2_parts))
        v1_parts.extend([0] * (max_len - len(v1_parts)))
        v2_parts.extend([0] * (max_len - len(v2_parts)))
        
        for i in range(max_len):
            if v1_parts[i] > v2_parts[i]:
                return 1
            elif v1_parts[i] < v2_parts[i]:
                return -1
        return 0
    except:
        return 0


def find_latest_version_from_api(api_url):
    """Find latest version by scanning GitHub API"""
    try:
        data = url_get(api_url)
        if not data:
            return None
        
        files = json.loads(data.decode('utf-8'))
        versions = []
        
        for f in files:
            name = f.get('name', '')
            match = re.match(r'plugin\.video\.fenlight-(\d+\.\d+\.\d+)\.zip', name)
            if match:
                versions.append(match.group(1))
        
        if versions:
            versions.sort(key=lambda v: [int(x) for x in v.split('.')], reverse=True)
            return versions[0]
    except Exception as e:
        log(f"Error scanning API: {e}")
    return None


def find_latest_version_from_html(list_url):
    """Find latest version by scanning HTML directory listing"""
    try:
        data = url_get(list_url)
        if not data:
            return None
        
        html = data.decode('utf-8')
        versions = re.findall(r'plugin\.video\.fenlight-(\d+\.\d+\.\d+)\.zip', html)
        
        if versions:
            versions = list(set(versions))
            versions.sort(key=lambda v: [int(x) for x in v.split('.')], reverse=True)
            return versions[0]
    except Exception as e:
        log(f"Error scanning HTML: {e}")
    return None


def get_fenlight_online_version_and_url():
    """Try all sources to get latest FenLight version and download URL"""
    for source in FENLIGHT_SOURCES:
        log(f"Trying source: {source['name']}")
        
        online_version = None
        
        if source.get('version_url'):
            data = url_get(source['version_url'])
            if data:
                online_version = data.decode('utf-8').replace('\n', '').strip()
                log(f"Got version from version file: {online_version}")
        
        if not online_version and source.get('api_url'):
            online_version = find_latest_version_from_api(source['api_url'])
            if online_version:
                log(f"Got version from API: {online_version}")
        
        if not online_version and source.get('list_url'):
            online_version = find_latest_version_from_html(source['list_url'])
            if online_version:
                log(f"Got version from HTML: {online_version}")
        
        if online_version:
            zip_url = source['zip_url'].format(version=online_version)
            return online_version, zip_url, source['name']
    
    return None, None, None


def get_skin_online_version():
    """Get latest Arctic Fuse skin version from GitHub releases"""
    try:
        data = url_get(SKIN_GITHUB_API)
        if not data:
            log("Could not fetch skin releases")
            return None, None
        
        release = json.loads(data.decode('utf-8'))
        tag_name = release.get('tag_name', '')
        
        # Tag is usually "v3.1.15" - remove the 'v'
        version = tag_name.lstrip('v')
        
        if version:
            zip_url = SKIN_ZIP_URL.format(version=version)
            log(f"Skin latest version: {version}")
            return version, zip_url
        
    except Exception as e:
        log(f"Error getting skin version: {e}")
    
    return None, None


class POVHebrewService(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        log("Service initialized")
        
        self.pov_version = get_addon_version('plugin.video.pov')
        self.fenlight_version = get_addon_version('plugin.video.fenlight')
        self.skin_version = get_addon_version('skin.arctic.fuse.3')
        
        log(f"Initial versions - POV: {self.pov_version}, FenLight: {self.fenlight_version}, Skin: {self.skin_version}")
    
    def onNotification(self, sender, method, data):
        """Handle Kodi notifications - detect addon updates/reinstalls"""
        
        log(f"Notification: sender={sender}, method={method}")
        
        if method in ('Addon.OnInstalled', 'Addon.OnEnabled'):
            try:
                data_dict = json.loads(data)
                addon_id = data_dict.get('id', '')
                
                log(f"Addon event: {method} for {addon_id}")
                
                # Handle POV install/update/reinstall
                if addon_id == 'plugin.video.pov':
                    xbmc.sleep(3000)
                    new_version = get_addon_version('plugin.video.pov')
                    log(f"POV version: {new_version}")
                    
                    saved_hebrew_ver = ADDON.getSetting('pov_hebrew_version')
                    hebrew_was_installed = saved_hebrew_ver and saved_hebrew_ver != '0' and saved_hebrew_ver != ''
                    
                    if hebrew_was_installed:
                        try:
                            pov_addon = xbmcaddon.Addon('plugin.video.pov')
                            pov_path = pov_addon.getAddonInfo('path')
                            kodirdil_exists = os.path.exists(os.path.join(pov_path, 'resources', 'lib', 'kodirdil'))
                            
                            if not kodirdil_exists:
                                log("Hebrew files missing after POV update - triggering reinstall")
                                self.pov_version = new_version
                                xbmc.sleep(1000)
                                self.reinstall_pov_hebrew(new_version)
                        except Exception as e:
                            log(f"Error checking POV path: {e}")
                    
                    self.pov_version = new_version
                
                # Handle Arctic Fuse Skin updates
                elif addon_id == 'skin.arctic.fuse.3':
                    xbmc.sleep(3000)
                    log("Skin Arctic Fuse event detected")
                    
                    saved_hebrew_ver = ADDON.getSetting('skin_hebrew_version')
                    hebrew_was_installed = saved_hebrew_ver and saved_hebrew_ver != '0' and saved_hebrew_ver != ''
                    
                    if hebrew_was_installed:
                        skin_path = os.path.join(ADDONS_PATH, 'skin.arctic.fuse.3')
                        font_exists = os.path.exists(os.path.join(skin_path, 'fonts', 'Rubik-VariableFont_wght.ttf'))
                        
                        if not font_exists:
                            log("Hebrew files missing after Skin update - triggering reinstall")
                            xbmc.sleep(1000)
                            self.reinstall_skin_hebrew()
                        
            except Exception as e:
                log(f"Error handling notification: {e}", xbmc.LOGERROR)
    
    def reinstall_skin_hebrew(self):
        """Reinstall Hebrew files for Arctic Fuse Skin after update"""
        if not ADDON.getSettingBool('auto_reinstall_skin'):
            log("Auto reinstall for Skin is disabled")
            return
        
        try:
            from resources.libs.installer import ArcticFuseHebrewInstaller
            installer = ArcticFuseHebrewInstaller()
            
            dialog = xbmcgui.Dialog()
            dialog.notification(ADDON_NAME, "מעדכן עברית לסקין...", xbmcgui.NOTIFICATION_INFO, 3000)
            
            xbmc.sleep(2000)
            
            progress = xbmcgui.DialogProgress()
            progress.create(ADDON_NAME, "מתקין מחדש קבצי עברית לסקין...")
            
            success = installer.install(progress_callback=lambda msg, pct: progress.update(pct, msg))
            progress.close()
            
            if success:
                try:
                    GITHUB_BASE = "https://raw.githubusercontent.com/asaf27064/pov-modified-heb/main/"
                    online_data = url_get(GITHUB_BASE + 'skin_version.json')
                    if online_data:
                        online_info = json.loads(online_data.decode('utf-8'))
                        new_ver = online_info.get('version', '1.0.0')
                        ADDON.setSetting('skin_hebrew_version', new_ver)
                except:
                    pass
                
                dialog.ok(ADDON_NAME, "[COLOR lime]עברית לסקין הותקנה מחדש בהצלחה![/COLOR]\n\nKodi יופעל מחדש.")
                xbmc.executebuiltin('Quit')
            else:
                dialog.ok(ADDON_NAME, "[COLOR red]התקנת עברית נכשלה![/COLOR]")
                
        except Exception as e:
            log(f"Error reinstalling Skin Hebrew: {e}", xbmc.LOGERROR)
    
    def reinstall_pov_hebrew(self, new_version):
        """Reinstall Hebrew files for POV after update"""
        if not ADDON.getSettingBool('auto_reinstall_pov'):
            log("Auto reinstall for POV is disabled")
            return
        
        try:
            from resources.libs.installer import POVHebrewInstaller
            installer = POVHebrewInstaller()
            
            pov_hebrew_version = ADDON.getSetting('pov_hebrew_version')
            hebrew_was_installed = pov_hebrew_version and pov_hebrew_version != '0' and pov_hebrew_version != ''
            
            if not hebrew_was_installed:
                log("Hebrew was not installed for POV, skipping")
                return
            
            dialog = xbmcgui.Dialog()
            dialog.notification(ADDON_NAME, f"POV עודכן ל-{new_version}. מתקין עברית...", xbmcgui.NOTIFICATION_INFO, 3000)
            
            xbmc.sleep(2000)
            
            progress = xbmcgui.DialogProgress()
            progress.create(ADDON_NAME, f"POV עודכן ל-{new_version}\nמתקין מחדש קבצי עברית...")
            
            success = installer.install(progress_callback=lambda msg, pct: progress.update(pct, msg))
            progress.close()
            
            if success:
                ADDON.setSetting('last_pov_version', new_version)
                
                try:
                    GITHUB_BASE = "https://raw.githubusercontent.com/asaf27064/pov-modified-heb/main/"
                    online_data = url_get(GITHUB_BASE + 'version.json')
                    if online_data:
                        online_info = json.loads(online_data.decode('utf-8'))
                        heb_ver = online_info.get('version', '1.0.0')
                        ADDON.setSetting('pov_hebrew_version', heb_ver)
                except:
                    pass
                
                dialog.ok(ADDON_NAME, f"[COLOR lime]POV עודכן ל-{new_version}[/COLOR]\n\nעברית הותקנה מחדש!\n\nKodi יופעל מחדש.")
                xbmc.executebuiltin('Quit')
            else:
                dialog.ok(ADDON_NAME, "[COLOR red]התקנת עברית נכשלה![/COLOR]")
                
        except Exception as e:
            log(f"Error reinstalling POV Hebrew: {e}", xbmc.LOGERROR)
    
    def run(self):
        """Main service loop"""
        
        # Check if we should skip update check (after build install)
        skip_check = ADDON.getSetting('skip_update_check')
        if skip_check == 'true':
            log("Skipping update check (after build installation)")
            ADDON.setSetting('skip_update_check', 'false')
            while not self.abortRequested():
                if self.waitForAbort(300):
                    break
            return
        
        # Get configurable delay from settings (default 15 seconds)
        try:
            delay = int(ADDON.getSetting('update_check_delay'))
            if delay < 5:
                delay = 5
            elif delay > 60:
                delay = 60
        except:
            delay = 15
        
        log(f"Service started, waiting {delay} seconds...")
        xbmc.sleep(delay * 1000)
        
        # Check for Hebrew files updates first
        log("Checking for Hebrew files updates...")
        self.check_hebrew_updates()
        
        # Then check for FenLight AND Skin addon updates (combined)
        log("Starting addon update checks...")
        self.check_and_update_addons()
        
        # Keep service alive to catch notifications
        while not self.abortRequested():
            if self.waitForAbort(300):
                break
        
        log("Service stopped")
    
    def check_hebrew_updates(self):
        """Check if Hebrew files have updates available"""
        
        if not ADDON.getSettingBool('auto_update_check'):
            log("Auto update check is disabled")
            return
        
        GITHUB_BASE = "https://raw.githubusercontent.com/asaf27064/pov-modified-heb/main/"
        log(f"Checking Hebrew updates from: {GITHUB_BASE}")
        
        updates_available = []
        
        # Check POV Hebrew
        if ADDON.getSettingBool('auto_reinstall_pov'):
            try:
                from resources.libs.installer import POVHebrewInstaller
                installer = POVHebrewInstaller()
                if installer.is_installed():
                    local_ver = installer.get_installed_version()
                    if local_ver == 'installed':
                        local_ver = '0'
                    if not local_ver:
                        local_ver = '0'
                    
                    online_data = url_get(GITHUB_BASE + 'version.json')
                    if online_data:
                        online_info = json.loads(online_data.decode('utf-8'))
                        online_ver = online_info.get('version', '0')
                        
                        if version_compare(online_ver, local_ver) > 0:
                            updates_available.append(('POV', local_ver, online_ver, installer, 'pov_hebrew_version'))
            except Exception as e:
                log(f"Error checking POV Hebrew: {e}", xbmc.LOGERROR)
        
        # Check FenLight Hebrew
        if ADDON.getSettingBool('auto_reinstall_fenlight'):
            try:
                from resources.libs.installer import FenLightHebrewInstaller
                installer = FenLightHebrewInstaller()
                if installer.is_hebrew_installed():
                    local_ver = installer.get_installed_version()
                    if local_ver == 'installed':
                        local_ver = '0'
                    if not local_ver:
                        local_ver = '0'
                    
                    online_data = url_get(GITHUB_BASE + 'fenlight_version.json')
                    if online_data:
                        online_info = json.loads(online_data.decode('utf-8'))
                        online_ver = online_info.get('version', '0')
                        
                        if version_compare(online_ver, local_ver) > 0:
                            updates_available.append(('FenLight', local_ver, online_ver, installer, 'fenlight_hebrew_version'))
            except Exception as e:
                log(f"Error checking FenLight Hebrew: {e}", xbmc.LOGERROR)
        
        # Check Skin Hebrew
        if ADDON.getSettingBool('auto_reinstall_skin'):
            try:
                from resources.libs.installer import ArcticFuseHebrewInstaller
                installer = ArcticFuseHebrewInstaller()
                if installer.is_installed():
                    local_ver = installer.get_installed_version()
                    if local_ver == 'installed':
                        local_ver = '0'
                    if not local_ver:
                        local_ver = '0'
                    
                    online_data = url_get(GITHUB_BASE + 'skin_version.json')
                    if online_data:
                        online_info = json.loads(online_data.decode('utf-8'))
                        online_ver = online_info.get('version', '0')
                        
                        if version_compare(online_ver, local_ver) > 0:
                            updates_available.append(('Skin', local_ver, online_ver, installer, 'skin_hebrew_version'))
            except Exception as e:
                log(f"Error checking Skin Hebrew: {e}", xbmc.LOGERROR)
        
        if not updates_available:
            log("All Hebrew files are up to date")
            return
        
        # Show update prompt
        update_text = "\n".join([f"• {name}: {old} → {new}" for name, old, new, _, _ in updates_available])
        
        dialog = xbmcgui.Dialog()
        if not dialog.yesno(
            ADDON_NAME,
            f"[COLOR yellow]עדכוני עברית זמינים[/COLOR]\n\n{update_text}\n\nלעדכן עכשיו?",
            yeslabel="עדכן",
            nolabel="מאוחר יותר"
        ):
            log("User declined Hebrew updates")
            return
        
        # Perform updates
        progress = xbmcgui.DialogProgress()
        progress.create(ADDON_NAME, "מעדכן קבצי עברית...")
        
        success_count = 0
        total = len(updates_available)
        
        for i, (name, old_ver, new_ver, installer, setting_key) in enumerate(updates_available):
            progress.update(int((i / total) * 100), f"מעדכן עברית ל-{name}...")
            
            try:
                if hasattr(installer, 'install'):
                    result = installer.install(progress_callback=lambda msg, pct: None)
                elif hasattr(installer, 'install_hebrew_files'):
                    result = installer.install_hebrew_files(progress_callback=lambda msg, pct: None)
                else:
                    result = False
                
                if result:
                    ADDON.setSetting(setting_key, new_ver)
                    success_count += 1
                    log(f"{name} Hebrew updated to {new_ver}")
            except Exception as e:
                log(f"Error updating {name} Hebrew: {e}", xbmc.LOGERROR)
        
        progress.close()
        
        if success_count > 0:
            dialog.ok(
                ADDON_NAME,
                f"[COLOR lime]עודכנו {success_count}/{total} קבצי עברית[/COLOR]\n\nKodi יופעל מחדש."
            )
            xbmc.executebuiltin('Quit')
        else:
            dialog.ok(ADDON_NAME, "[COLOR red]עדכון עברית נכשל![/COLOR]")
    
    def check_and_update_addons(self):
        """Check for FenLight AND Skin updates - combined prompt"""
        
        updates_available = []
        
        # Check FenLight
        if ADDON.getSettingBool('auto_reinstall_fenlight'):
            fenlight_update = self.check_fenlight_update()
            if fenlight_update:
                updates_available.append(fenlight_update)
        
        # Check Skin
        if ADDON.getSettingBool('auto_reinstall_skin'):
            skin_update = self.check_skin_update()
            if skin_update:
                updates_available.append(skin_update)
        
        if not updates_available:
            log("All addons are up to date")
            return
        
        # Build combined prompt
        update_lines = []
        for update in updates_available:
            update_lines.append(f"• {update['name']}: {update['current']} → {update['online']}")
        
        update_text = "\n".join(update_lines)
        
        dialog = xbmcgui.Dialog()
        if not dialog.yesno(
            ADDON_NAME,
            f"[COLOR yellow]עדכונים זמינים[/COLOR]\n\n{update_text}\n\nלעדכן ולהתקין עברית?",
            yeslabel="עדכן",
            nolabel="מאוחר יותר"
        ):
            log("User declined addon updates")
            return
        
        # Perform updates
        self.perform_addon_updates(updates_available)
    
    def check_fenlight_update(self):
        """Check if FenLight has an update available"""
        fenlight_path = os.path.join(ADDONS_PATH, 'plugin.video.fenlight')
        if not os.path.exists(fenlight_path):
            log("FenLight not installed")
            return None
        
        try:
            from resources.libs.installer import FenLightHebrewInstaller
            installer = FenLightHebrewInstaller()
            if not installer.is_hebrew_installed():
                log("Hebrew not installed for FenLight, skipping")
                return None
        except Exception as e:
            log(f"Error checking Hebrew: {e}")
            return None
        
        current_version = get_addon_version('plugin.video.fenlight')
        if not current_version:
            return None
        
        log(f"Current FenLight version: {current_version}")
        
        online_version, zip_url, source_name = get_fenlight_online_version_and_url()
        
        if not online_version:
            log("Could not get online FenLight version")
            return None
        
        log(f"Online FenLight version: {online_version} (from {source_name})")
        
        if version_compare(online_version, current_version) <= 0:
            log("FenLight is up to date")
            return None
        
        return {
            'type': 'fenlight',
            'name': 'FenLight',
            'current': current_version,
            'online': online_version,
            'zip_url': zip_url,
            'source': source_name
        }
    
    def check_skin_update(self):
        """Check if Arctic Fuse Skin has an update available"""
        skin_path = os.path.join(ADDONS_PATH, 'skin.arctic.fuse.3')
        if not os.path.exists(skin_path):
            log("Skin not installed")
            return None
        
        try:
            from resources.libs.installer import ArcticFuseHebrewInstaller
            installer = ArcticFuseHebrewInstaller()
            if not installer.is_installed():
                log("Hebrew not installed for Skin, skipping")
                return None
        except Exception as e:
            log(f"Error checking Skin Hebrew: {e}")
            return None
        
        current_version = get_addon_version('skin.arctic.fuse.3')
        if not current_version:
            return None
        
        log(f"Current Skin version: {current_version}")
        
        online_version, zip_url = get_skin_online_version()
        
        if not online_version:
            log("Could not get online Skin version")
            return None
        
        log(f"Online Skin version: {online_version}")
        
        if version_compare(online_version, current_version) <= 0:
            log("Skin is up to date")
            return None
        
        return {
            'type': 'skin',
            'name': 'Arctic Fuse Skin',
            'current': current_version,
            'online': online_version,
            'zip_url': zip_url,
            'source': 'GitHub'
        }
    
    def perform_addon_updates(self, updates):
        """Perform the actual addon updates"""
        progress = xbmcgui.DialogProgress()
        progress.create(ADDON_NAME, "מעדכן...")
        
        success_list = []
        failed_list = []
        
        # 3 steps per addon: extract, install, hebrew (download has its own progress)
        total_steps = len(updates) * 3
        current_step = 0
        
        for update in updates:
            addon_name = update['name']
            version = update['online']
            zip_url = update['zip_url']
            
            try:
                # Determine addon info
                if update['type'] == 'fenlight':
                    addon_id = 'plugin.video.fenlight'
                    zip_name = f'plugin.video.fenlight-{version}.zip'
                else:
                    addon_id = 'skin.arctic.fuse.3'
                    zip_name = f'skin.arctic.fuse.3-{version}.zip'
                
                zip_location = os.path.join(PACKAGES_PATH, zip_name)
                os.makedirs(PACKAGES_PATH, exist_ok=True)
                
                # Remove old partial download if exists
                if os.path.exists(zip_location):
                    try:
                        os.remove(zip_location)
                    except:
                        pass
                
                # Download with progress, resume, and retries
                download_title = f"מוריד {addon_name} {version}"
                if not download_file(zip_url, zip_location, progress, download_title):
                    raise Exception("ההורדה נכשלה")
                
                # Extract to temp location first
                current_step += 1
                progress.update(int((current_step / total_steps) * 100), f"מחלץ {addon_name}...")
                
                temp_extract = os.path.join(PACKAGES_PATH, f'temp_{addon_id}')
                if os.path.exists(temp_extract):
                    shutil.rmtree(temp_extract)
                
                with zipfile.ZipFile(zip_location, 'r') as zf:
                    zf.extractall(temp_extract)
                
                # Find the extracted folder (might have version in name)
                extracted_items = os.listdir(temp_extract)
                if extracted_items:
                    extracted_folder = os.path.join(temp_extract, extracted_items[0])
                    if os.path.isdir(extracted_folder):
                        source_folder = extracted_folder
                    else:
                        source_folder = temp_extract
                else:
                    raise Exception("חילוץ נכשל")
                
                # Install new version
                current_step += 1
                progress.update(int((current_step / total_steps) * 100), f"מתקין {addon_name} חדש...")
                
                addon_path = os.path.join(ADDONS_PATH, addon_id)
                
                if update['type'] == 'skin':
                    # For skin: overwrite files instead of delete (skin is in use!)
                    # First, clear the existing folder contents
                    if os.path.exists(addon_path):
                        log(f"Clearing contents of {addon_path}")
                        for item in os.listdir(addon_path):
                            item_path = os.path.join(addon_path, item)
                            try:
                                if os.path.isdir(item_path):
                                    shutil.rmtree(item_path)
                                else:
                                    os.remove(item_path)
                            except Exception as e:
                                log(f"Could not remove {item_path}: {e}")
                    else:
                        os.makedirs(addon_path)
                    
                    # Copy new files (skip git files like Kodi does)
                    git_files = {'.git', '.github', '.gitattributes', '.gitignore', '.gitmodules'}
                    log(f"Copying new files from {source_folder} to {addon_path}")
                    for item in os.listdir(source_folder):
                        if item in git_files:
                            log(f"Skipping git file: {item}")
                            continue
                        src = os.path.join(source_folder, item)
                        dst = os.path.join(addon_path, item)
                        try:
                            if os.path.isdir(src):
                                shutil.copytree(src, dst)
                            else:
                                shutil.copy2(src, dst)
                        except Exception as e:
                            log(f"Error copying {item}: {e}")
                    
                    log(f"Installed new skin at {addon_path}")
                else:
                    # For FenLight: regular delete and move (addon not in use)
                    if os.path.exists(addon_path):
                        for attempt in range(5):
                            try:
                                shutil.rmtree(addon_path)
                                log(f"Removed old {addon_id}")
                                break
                            except Exception as e:
                                log(f"Remove attempt {attempt + 1} failed: {e}")
                                xbmc.sleep(500)
                        else:
                            try:
                                old_backup = addon_path + '_old_' + str(int(time.time()))
                                shutil.move(addon_path, old_backup)
                                log(f"Moved old addon to {old_backup}")
                            except Exception as e:
                                raise Exception(f"לא ניתן להסיר את הגרסה הישנה: {e}")
                    
                    # Remove git files from source before moving
                    git_files = {'.git', '.github', '.gitattributes', '.gitignore', '.gitmodules'}
                    for git_item in git_files:
                        git_path = os.path.join(source_folder, git_item)
                        if os.path.exists(git_path):
                            try:
                                if os.path.isdir(git_path):
                                    shutil.rmtree(git_path)
                                else:
                                    os.remove(git_path)
                                log(f"Removed git file: {git_item}")
                            except:
                                pass
                    
                    shutil.move(source_folder, addon_path)
                    log(f"Installed new {addon_id} at {addon_path}")
                
                # Cleanup
                try:
                    shutil.rmtree(temp_extract)
                    os.remove(zip_location)
                except:
                    pass
                
                # Install Hebrew
                current_step += 1
                progress.update(int((current_step / total_steps) * 100), f"מתקין עברית ל-{addon_name}...")
                
                if update['type'] == 'fenlight':
                    from resources.libs.installer import FenLightHebrewInstaller
                    installer = FenLightHebrewInstaller()
                    hebrew_success = installer.install_hebrew_files(progress_callback=lambda msg, pct: None)
                    if hebrew_success:
                        ADDON.setSetting('last_fenlight_version', version)
                else:
                    from resources.libs.installer import ArcticFuseHebrewInstaller
                    installer = ArcticFuseHebrewInstaller()
                    hebrew_success = installer.install(progress_callback=lambda msg, pct: None)
                    if hebrew_success:
                        ADDON.setSetting('last_skin_version', version)
                
                if hebrew_success:
                    success_list.append(f"{addon_name} {version}")
                else:
                    success_list.append(f"{addon_name} {version} (עברית נכשלה)")
                
            except Exception as e:
                log(f"Error updating {addon_name}: {e}", xbmc.LOGERROR)
                failed_list.append(addon_name)
                current_step += (3 - (current_step % 3))
                try:
                    temp_extract = os.path.join(PACKAGES_PATH, f'temp_{addon_id}')
                    if os.path.exists(temp_extract):
                        shutil.rmtree(temp_extract)
                except:
                    pass
        
        progress.close()
        
        # Show result
        dialog = xbmcgui.Dialog()
        
        if success_list:
            success_text = "\n".join([f"✓ {item}" for item in success_list])
            failed_text = "\n".join([f"✗ {item}" for item in failed_list]) if failed_list else ""
            
            msg = f"[COLOR lime]עודכנו בהצלחה:[/COLOR]\n{success_text}"
            if failed_text:
                msg += f"\n\n[COLOR red]נכשלו:[/COLOR]\n{failed_text}"
            msg += "\n\nKodi יופעל מחדש."
            
            dialog.ok(ADDON_NAME, msg)
            xbmc.executebuiltin('Quit')
        else:
            dialog.ok(ADDON_NAME, "[COLOR red]כל העדכונים נכשלו![/COLOR]")


if __name__ == '__main__':
    service = POVHebrewService()
    service.run()
