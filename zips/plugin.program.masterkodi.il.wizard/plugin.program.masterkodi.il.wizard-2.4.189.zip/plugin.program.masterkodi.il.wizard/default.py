# -*- coding: utf-8 -*-
"""
MasterKodi IL Wizard - Beautiful Dialog-Based UI
"""
import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import xbmcplugin
import os
import sys

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_PATH = ADDON.getAddonInfo('path')
ADDON_VERSION = ADDON.getAddonInfo('version')
ADDON_DATA = xbmcvfs.translatePath(f'special://userdata/addon_data/{ADDON_ID}')

# Colors
COLOR_HEADER = 'FF00BFFF'  # Deep Sky Blue
COLOR_SUCCESS = 'FF00FF00'  # Lime
COLOR_WARNING = 'FFFFFF00'  # Yellow
COLOR_ERROR = 'FFFF0000'   # Red
COLOR_INFO = 'FF87CEEB'    # Sky Blue
COLOR_GOLD = 'FFFFD700'    # Gold
COLOR_WHITE = 'FFFFFFFF'
COLOR_GRAY = 'FFA0A0A0'


def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f'[{ADDON_ID}] {msg}', level)


def color(text, hex_color):
    """Wrap text with color"""
    return f'[COLOR {hex_color}]{text}[/COLOR]'


def bold(text):
    """Make text bold"""
    return f'[B]{text}[/B]'


# Branded custom-window menu helpers now live in resources/libs/ui.py so the
# install/build flow (builds.py) shares the exact same look as this menu.
from resources.libs.ui import menu_item, wizard_select  # noqa: E402


# ============================================
# STATUS HELPERS
# ============================================
def get_gearsai_status():
    """AI Subs (service.subtitles.gearsai) install status."""
    try:
        # disk truth: gearsai ships via the manifest, its version lives in its
        # own addon.xml (the legacy pov-modified-heb installer is retired)
        import re
        xml = os.path.join(xbmcvfs.translatePath('special://home/addons/'),
                           'service.subtitles.gearsai', 'addon.xml')
        if not os.path.isfile(xml):
            return {'addon': False, 'hebrew': False, 'version': None}
        with open(xml, 'r', encoding='utf-8', errors='replace') as fh:
            head = fh.read(4000)
        m = re.search(r'<addon\s+[^>]*version="([^"]+)"', head)
        return {'addon': True, 'hebrew': True, 'version': (m.group(1) if m else None)}
    except Exception as e:
        log(f"Error getting AI Subs status: {e}")
        return {'addon': False, 'hebrew': False, 'version': None}


def format_status(status):
    """Format status for display"""
    if not status['addon']:
        return color('לא מותקן', COLOR_GRAY)
    elif not status['hebrew']:
        return color('עברית לא מותקנת', COLOR_WARNING)
    else:
        ver = status['version'] if status['version'] and status['version'] != 'installed' else ''
        if ver:
            return color(f'מותקן (v{ver})', COLOR_SUCCESS)
        else:
            return color('מותקן', COLOR_SUCCESS)


def build_status_menu():
    """Show every installed addon + its version, checked against the manifest.
    A read-only view of the build's actual state (a new capability of the
    manifest model)."""
    import os, re
    dialog = xbmcgui.Dialog()
    addons_path = xbmcvfs.translatePath('special://home/addons/')

    def _ver(aid):
        try:
            with open(os.path.join(addons_path, aid, 'addon.xml'), encoding='utf-8', errors='replace') as fh:
                m = re.search(r'<addon[^>]*version="([^"]+)"', fh.read())
            return m.group(1) if m else '?'
        except Exception:
            return None

    try:
        from resources.libs import modular_update
        manifest = modular_update.fetch_manifest()
        m_addons = manifest.get('addons', [])
    except Exception as e:
        dialog.ok(ADDON_NAME, f"{color('לא ניתן לטעון מאניפסט:', COLOR_ERROR)}\n{e}")
        return

    rows = []
    n_ok = n_missing = n_old = 0
    for a in sorted(m_addons, key=lambda x: (x.get('channel', 'core'), x['id'])):
        installed = _ver(a['id'])
        if installed is None:
            if a.get('channel') == 'optional':
                continue  # optional not installed -> not relevant here
            state = color('חסר', COLOR_ERROR); n_missing += 1
        elif installed == a['version']:
            state = color('מעודכן', COLOR_SUCCESS); n_ok += 1
        else:
            state = color(f'{installed} -> {a["version"]}', COLOR_WARNING); n_old += 1
        tag = ' [Skin]' if a.get('channel') == 'optional' else ''
        rows.append(menu_item(f"{a['id']}{tag}", f"v{a.get('version','?')}  |  {state}", 'DefaultAddonInfoProvider.png'))

    header = (f"{color('סטטוס הבילד', COLOR_GOLD)}  |  "
              f"{color(str(n_ok)+' מעודכנים', COLOR_SUCCESS)}"
              + (f" | {color(str(n_old)+' לעדכון', COLOR_WARNING)}" if n_old else '')
              + (f" | {color(str(n_missing)+' חסרים', COLOR_ERROR)}" if n_missing else ''))
    wizard_select(header, rows)


# ============================================
# MAIN MENU
# ============================================
def main_menu():
    """Show beautiful main menu"""
    dialog = xbmcgui.Dialog()
    
    while True:
        gearsai_status = get_gearsai_status()

        # Menu reflects the manifest model: everything (Gears + Hebrew, skins,
        # AI subs) is pre-merged and delivered/updated by "בדוק עדכונים". The old
        # per-addon "reinstall Hebrew overlay" flows (Gears/Skin/POV) are gone --
        # they downloaded the legacy overlay zips and no longer apply.
        items, handlers = [], []
        items.append(menu_item('בדוק עדכונים', 'עדכון כל הבילד | אימות SHA256 | רק מה שהשתנה', 'DefaultAddonsUpdates.png'))
        handlers.append(check_updates_now)
        items.append(menu_item('התקנה / החלפת בילד', 'התקן בילד | בחר סקין (Estuary | Nimbus | Arctic Fuse)', 'DefaultAddonProgram.png'))
        handlers.append(build_menu)
        items.append(menu_item('סקינים', 'החלפה / התקנה / הסרה של סקין', 'DefaultAddonSkin.png'))
        handlers.append(open_skins_menu)
        items.append(menu_item('מקור תוכן (Gears / POV)', 'החלף בין Gears ל-POV לתפריטים והוידג\'טים של הסקין', 'DefaultAddonVideo.png'))
        handlers.append(content_source_menu)
        items.append(menu_item('סטטוס הבילד', 'מה מותקן וגרסאות | מהמאניפסט', 'DefaultAddonInfoProvider.png'))
        handlers.append(build_status_menu)
        items.append(menu_item('כתוביות AI (Gemini)', format_status(gearsai_status), 'DefaultAddonSubtitles.png'))
        handlers.append(gearsai_menu)
        items.append(menu_item('תחזוקה', 'ניקוי מטמון | חבילות | תמונות | OLED | HDR/DV', 'DefaultAddonService.png'))
        handlers.append(maintenance_menu)
        items.append(menu_item('גיבוי ושחזור', 'מפתח Gemini | דבריד | הגדרות', 'DefaultHardDisk.png'))
        handlers.append(backup_menu)
        items.append(menu_item('הגדרות האשף', 'עדכון אוטומטי | השהיות | אפשרויות', 'DefaultAddonProgram.png'))
        handlers.append(lambda: ADDON.openSettings())

        header = f"{color('MasterKodi IL Wizard', COLOR_GOLD)} v{ADDON_VERSION}"
        selection = wizard_select(header, items)
        if selection == -1:
            break
        handlers[selection]()


# ============================================
# POV MENU
# ============================================






# ============================================
# GEARS + AI SUBS MENUS
# ============================================


def gearsai_menu():
    """AI Subs (gearsai) submenu - settings / info / install."""
    dialog = xbmcgui.Dialog()
    status = get_gearsai_status()
    if not status['addon']:
        if dialog.yesno('כתוביות AI',
                        f"{color('כתוביות AI (gearsai) לא מותקנות.', COLOR_WARNING)}\n\nלהתקין עכשיו?"):
            install_gearsai()
        return
    items = [
        menu_item('הגדרות כתוביות AI', 'מפתח Gemini | מודל | מאגר קהילתי', 'DefaultAddonProgram.png'),
        menu_item('מידע', f"v{status['version']}", 'DefaultAddonInfoProvider.png'),
        menu_item('חזרה', '', 'DefaultFolderBack.png'),
    ]
    sel = wizard_select(f"{color('כתוביות AI (Gemini)', COLOR_HEADER)} - {format_status(status)}", items)
    if sel == 0:
        try:
            xbmcaddon.Addon('service.subtitles.gearsai').openSettings()
        except Exception as e:
            dialog.ok('שגיאה', str(e))
    elif sel == 1:
        dialog.textviewer('כתוביות AI - מידע',
                          f"[B]גרסה:[/B] {status['version']}\n\n"
                          "כתוביות עברית אוטומטיות עם תרגום AI (Gemini) ומאגר קהילתי.\n"
                          "מפתח Gemini ומודל נקבעים ב'הגדרות כתוביות AI'.")


def install_gearsai():
    """Install/enable the AI Subs add-on."""
    dialog = xbmcgui.Dialog()
    progress = xbmcgui.DialogProgress()
    progress.create('כתוביות AI', 'מתקין...')
    try:
        # manifest install: sha-verified zip from the fleet's own manifest --
        # the legacy pov-modified-heb zip (unhashed, could diverge) is retired
        from resources.libs import modular_update as mu
        manifest = mu.fetch_manifest()
        entry = next((a for a in manifest.get('addons', [])
                      if a['id'] == 'service.subtitles.gearsai'), None)
        ok = False
        if entry:
            progress.update(30, 'מוריד ומתקין...')
            mu._apply_one(entry)
            state = mu._load_state()
            state['service.subtitles.gearsai'] = entry['sha256']
            mu._save_state(state)
            from resources.libs.builds import BuildManager
            BuildManager().enable_addons_in_db(['service.subtitles.gearsai'])
            xbmc.executebuiltin('UpdateLocalAddons()')
            ok = True
        progress.close()
        dialog.ok('כתוביות AI',
                  color('הותקנו בהצלחה!', COLOR_SUCCESS) if ok else color('ההתקנה נכשלה!', COLOR_ERROR))
    except Exception as e:
        progress.close()
        dialog.ok('שגיאה', f"{color('שגיאה:', COLOR_ERROR)}\n{str(e)}")


# ============================================
# SKIN MENU
# ============================================
def open_skins_menu():
    """Dedicated skin manager (switch / install / remove) in builds.py."""
    try:
        from resources.libs.builds import skins_menu
        skins_menu()
    except Exception as e:
        xbmcgui.Dialog().ok(ADDON_NAME, f"{color('שגיאה:', COLOR_ERROR)}\n{e}")


def content_source_menu():
    """Switch the current skin's menus/widgets/search between Gears and POV."""
    try:
        from resources.libs import content_source
        content_source.menu()
    except Exception as e:
        xbmcgui.Dialog().ok(ADDON_NAME, f"{color('שגיאה:', COLOR_ERROR)}\n{e}")




# ============================================
# BUILD MENU
# ============================================
def build_menu():
    """Build installation menu"""
    dialog = xbmcgui.Dialog()
    
    while True:
        items = [
            menu_item('התקנת בילד', 'התקנה נקייה | בחירת סקין (Estuary | Nimbus | Arctic Fuse) | מוחק את הקיים', 'DefaultAddonProgram.png'),
            menu_item('תיקון / רענון בילד', 'התקנה מחדש של כל התוספים מהמאניפסט (ההגדרות והמפתחות נשמרים)', 'DefaultAddonsUpdates.png'),
            menu_item('מידע על בילד נוכחי', 'שם | גרסה | סקין מותקן', 'DefaultAddonInfoProvider.png'),
        ]

        selection = wizard_select(color('התקנה / עדכון בילד', COLOR_HEADER), items)

        if selection == -1:
            return
        elif selection == 0:
            install_build()
        elif selection == 1:
            update_build()
        elif selection == 2:
            show_build_info()


def install_build():
    """Install a build - uses builds_menu which handles skin selection"""
    try:
        from resources.libs.builds import builds_menu
        builds_menu()
    except Exception as e:
        dialog = xbmcgui.Dialog()
        dialog.ok('שגיאה', f"{color('שגיאה:', COLOR_ERROR)}\n{str(e)}")


def update_build():
    """Repair / resync the build: reinstall every manifest addon regardless of
    version (keeping settings + keys). Distinct from the main-menu 'בדוק
    עדכונים', which only pulls what actually changed."""
    try:
        from resources.libs import modular_update
        modular_update.repair_build()
    except Exception as e:
        xbmcgui.Dialog().ok(ADDON_NAME, f"{color('שגיאה בתיקון:', COLOR_ERROR)}\n{e}")


def show_build_info():
    """Quick offline snapshot of the installed build: skin + key addon versions
    + config + last update. (The full per-addon manifest comparison is under
    'סטטוס הבילד'.) The old buildname/buildversion settings are unused in the
    manifest model, so read the real state from disk + applied_manifest.json."""
    import os, re, json, time
    addons_path = xbmcvfs.translatePath('special://home/addons/')

    def ver(aid):
        try:
            with open(os.path.join(addons_path, aid, 'addon.xml'), encoding='utf-8', errors='replace') as fh:
                m = re.search(r'<addon[^>]*version="([^"]+)"', fh.read())
            return m.group(1) if m else '-'
        except Exception:
            return 'לא מותקן'

    skin_names = {'skin.arctic.fuse.3': 'Arctic Fuse', 'skin.nimbus': 'Nimbus',
                  'skin.estuary': 'Estuary'}
    try:
        skin_id = xbmc.getSkinDir()
    except Exception:
        skin_id = ''
    skin = skin_names.get(skin_id, skin_id or '-')

    cfg_ver, n_addons, last = '-', 0, '-'
    state_file = os.path.join(ADDON_DATA, 'applied_manifest.json')
    try:
        with open(state_file, encoding='utf-8') as fh:
            state = json.load(fh)
        cfg = state.get('__config__', '')
        if cfg.startswith('config:'):
            cfg_ver = cfg.split(':', 1)[1]
        n_addons = len([k for k in state if not k.startswith('__')])
        last = time.strftime('%Y-%m-%d %H:%M', time.localtime(os.path.getmtime(state_file)))
    except Exception:
        pass

    xbmcgui.Dialog().textviewer(
        'מידע על הבילד',
        f"[B]בילד:[/B] MasterKodi IL\n"
        f"[B]סקין נוכחי:[/B] {skin}\n"
        f"[B]Gears:[/B] {ver('plugin.video.gears')}\n"
        f"[B]כתוביות AI:[/B] {ver('service.subtitles.gearsai')}\n"
        f"[B]אשף:[/B] {ver(ADDON_ID)}\n"
        f"[B]תצורה (config):[/B] {cfg_ver}\n"
        f"[B]תוספים מנוהלים:[/B] {n_addons}\n"
        f"[B]עדכון אחרון:[/B] {last}\n"
    )


# ============================================
# MAINTENANCE MENU
# ============================================

# ============================================
# OLED SETTINGS
# ============================================
def apply_oled_to_guisettings():
    """Apply the OLED screen-protection settings.

    Kept under the old name so existing callers keep working, but it no longer
    edits guisettings.xml: Kodi holds its settings in memory and rewrites that
    file on exit, so a mid-session edit is discarded (measured 2026-08-13 --
    screensaver.mode came back EMPTY, which is the setting that actually turns
    the black screensaver on). resources/libs/oled.py goes through Kodi's
    settings API instead, so the change is persisted like a GUI change.
    """
    try:
        from resources.libs import oled as oled_mod
        applied, failed = oled_mod.apply_oled_settings()
        return not failed
    except Exception as e:
        log(f"Error applying OLED: {e}")
        return False


def oled_menu():
    """OLED settings menu"""
    dialog = xbmcgui.Dialog()
    
    result = dialog.yesno(
        color('הגדרות OLED', COLOR_HEADER),
        f'{bold("יש לך מסך OLED?")}\n\n'
        f'אם כן, נגדיר הגדרות להגנה על המסך:\n'
        f'- Screensaver שחור (לא אנימציה)\n'
        f'- הפעלה אחרי דקה\n'
        f'- עמעום בזמן השהיה\n'
        f'- כיבוי המסך אחרי 5 דקות',
        yeslabel='כן, יש לי OLED',
        nolabel='לא'
    )
    
    if result:
        if apply_oled_to_guisettings():
            dialog.ok('הצלחה', f'{color("הגדרות OLED הוחלו!", COLOR_SUCCESS)}\n\n'
                     f'- Screensaver: Black\n'
                     f'- זמן המתנה: דקה\n'
                     f'- עמעום בהשהיה: פעיל\n\n'
                     f'{color("יש להפעיל מחדש את Kodi", COLOR_WARNING)}')
        else:
            dialog.ok('שגיאה', 'לא הצלחתי להחיל את ההגדרות')


# ============================================
# SDR-ONLY (display cannot show HDR)
# ============================================
def sdr_menu():
    """Turn the persistent 'hide HDR/DV sources' filter on or off.

    The engines already offer this as a one-off filter inside the source window;
    what this does is make the answer STICK, so a user whose TV cannot display
    HDR stops re-applying it on every search. It writes the ENGINES' OWN
    filter settings (POV filter_hdr/filter_dv, Gears filter.hdr/filter.dv) --
    see resources/libs/sdr.py for why ours would have been the weaker choice.
    """
    dialog = xbmcgui.Dialog()
    try:
        from resources.libs import sdr as sdr_mod
    except Exception as e:
        log(f"Error loading sdr module: {e}")
        dialog.ok('שגיאה', 'לא הצלחתי לטעון את ההגדרה')
        return

    state = sdr_mod.status()
    installed = [k for k, v in state.items() if v is not None]
    if not installed:
        dialog.ok('מסך ללא HDR/DV', 'לא נמצא מנוע מקורות מותקן')
        return
    enabled = any(state[k] for k in installed)

    # Bidi: every line is Hebrew-leading with at most ONE Latin run, at its end.
    now = color('פעיל - מוסתרים מקורות HDR/DV', COLOR_SUCCESS) if enabled \
        else color('כבוי - כל המקורות מוצגים', COLOR_WARNING)
    heading = color('מסך ללא HDR/DV', COLOR_HEADER)
    body = (f'{bold("הטלוויזיה שלך תומכת ב-HDR / Dolby Vision?")}\n\n'
            f'מצב נוכחי: {now}\n\n'
            f'במסך שאינו תומך, סרט בפורמט הזה נראה דהוי או בצבעים שגויים.\n'
            f'בבחירת "מסך רגיל" יוסתרו אוטומטית בכל חיפוש מקורות HDR/DV')
    labels = {'yeslabel': 'כן, תומך ב-HDR/DV', 'nolabel': 'לא, מסך רגיל'}
    # Focus whatever is already true, so a stray OK press changes NOTHING.
    # (Kodi focuses NO by default; defaultbutton exists from Kodi 20 up.)
    try:
        result = dialog.yesno(
            heading, body,
            defaultbutton=(xbmcgui.DLG_YESNO_NO_BTN if enabled
                           else xbmcgui.DLG_YESNO_YES_BTN),
            **labels)
    except (TypeError, AttributeError):
        result = dialog.yesno(heading, body, **labels)

    # yes = the display handles HDR -> only clear the filter if it is actually on
    if result and not enabled:
        return
    res = sdr_mod.apply_sdr_only(not result)
    failed = sdr_mod.failures(res)
    if failed:
        dialog.ok('שגיאה', f'{color("ההגדרה לא הוחלה", COLOR_WARNING)}\n\n'
                           f'{", ".join(failed)}')
    elif result:
        dialog.ok('בוצע', color('הסינון בוטל - כל המקורות יוצגו', COLOR_SUCCESS))
    else:
        deferred = [k for k, v in res.items() if v == 'deferred']
        tail = '\n\nההגדרה תוחל בהפעלה הבאה' if deferred else ''
        dialog.ok('בוצע', f'{color("מעכשיו יוסתרו מקורות HDR/DV", COLOR_SUCCESS)}{tail}')


def maintenance_menu():
    """Maintenance menu"""
    dialog = xbmcgui.Dialog()
    
    while True:
        try:
            from resources.libs.maintenance import current_sizes
            sizes = current_sizes()
        except Exception:
            sizes = {'cache': '?', 'packages': '?', 'thumbnails': '?', 'total': '?'}

        menu_items = [
            # keep every description Hebrew-leading with ONE Latin run (the size)
            # at the end -- mixed Hebrew/Latin runs get reordered by bidi and the
            # size lands in the middle of the sentence
            menu_item('ניקוי Cache', f'מחיקת מטמון זמני ופינוי מקום  |  {sizes["cache"]}', 'DefaultAddonService.png'),
            menu_item('ניקוי Packages', f'מחיקת קובצי התקנה שמורים  |  {sizes["packages"]}', 'DefaultAddonService.png'),
            menu_item('ניקוי Thumbnails', f'מחיקת תמונות ממוזערות שמורות  |  {sizes["thumbnails"]}', 'DefaultAddonService.png'),
            menu_item('ניקוי הכל', f'מטמון, חבילות ותמונות יחד  |  {sizes["total"]}', 'DefaultAddonService.png'),
            menu_item('סגירת Kodi', 'סגירה מלאה (לרענון אחרי שינויים)', 'DefaultAddonService.png'),
            menu_item('הגדרות OLED', 'חיסכון בשחיקת מסך | בהירות | הגנת פיקסלים', 'DefaultAddonPVRClient.png'),
            menu_item('מסך ללא HDR/DV', 'לטלוויזיה שאינה תומכת | הסתרת מקורות HDR/DV', 'DefaultAddonPVRClient.png'),
        ]

        selection = wizard_select(color('תחזוקה', COLOR_HEADER), menu_items)

        if selection == -1:
            return
        elif selection == 0:
            clear_cache()
        elif selection == 1:
            clear_packages()
        elif selection == 2:
            clear_thumbnails()
        elif selection == 3:
            clear_all()
        elif selection == 4:
            force_close()
        elif selection == 5:
            oled_menu()
        elif selection == 6:
            sdr_menu()


def clear_cache():
    """Clear cache"""
    dialog = xbmcgui.Dialog()
    
    if not dialog.yesno('ניקוי Cache', 'האם לנקות את ה-Cache?'):
        return
    
    try:
        from resources.libs.maintenance import clear_cache as do_clear
        cleared = do_clear()
        dialog.ok('הצלחה', f'{color("Cache נוקה!", COLOR_SUCCESS)}\n\nנמחקו: {cleared}')
    except Exception as e:
        dialog.ok('שגיאה', str(e))


def clear_packages():
    """Clear packages"""
    dialog = xbmcgui.Dialog()
    
    if not dialog.yesno('ניקוי Packages', 'האם לנקות את ה-Packages?'):
        return
    
    try:
        from resources.libs.maintenance import clear_packages as do_clear
        cleared = do_clear()
        dialog.ok('הצלחה', f'{color("Packages נוקה!", COLOR_SUCCESS)}\n\nנמחקו: {cleared}')
    except Exception as e:
        dialog.ok('שגיאה', str(e))


def clear_thumbnails():
    """Clear thumbnails"""
    dialog = xbmcgui.Dialog()

    if not dialog.yesno('ניקוי Thumbnails', 'האם לנקות את ה-Thumbnails?\n\nפעולה זו תמחק את כל התמונות השמורות.'):
        return

    # Textures*.db is OPEN by Kodi. Dropping it without restarting leaves the
    # texture cache broken (SQLITE_READONLY_DBMOVED on Android), so we only drop
    # it when the user agrees to restart right away.
    restart = dialog.yesno(
        'ניקוי Thumbnails',
        'לניקוי מלא (כולל מסד התמונות) צריך לסגור את Kodi.\n\n'
        'לסגור את Kodi בסיום?',
        yeslabel='סגור בסיום', nolabel='ניקוי חלקי')

    try:
        from resources.libs.maintenance import clear_thumbnails as do_clear
        cleared = do_clear(drop_texture_db=restart)
        dialog.ok('הצלחה', f'{color("Thumbnails נוקה!", COLOR_SUCCESS)}\n\nנמחקו: {cleared}')
        if restart:
            fast_exit()
    except Exception as e:
        dialog.ok('שגיאה', str(e))


def clear_all():
    """Clear everything"""
    dialog = xbmcgui.Dialog()

    if not dialog.yesno(
        'ניקוי הכל',
        f'{color("אזהרה!", COLOR_WARNING)}\n\n'
        'פעולה זו תנקה:\n'
        '- Cache\n'
        '- Packages\n'
        '- Thumbnails\n\n'
        'האם להמשיך?'
    ):
        return

    try:
        from resources.libs.maintenance import clear_cache, clear_packages, clear_thumbnails

        progress = xbmcgui.DialogProgress()
        progress.create('ניקוי', 'מנקה...')

        progress.update(0, 'מנקה Cache...')
        cache = clear_cache()

        progress.update(33, 'מנקה Packages...')
        packages = clear_packages()

        progress.update(66, 'מנקה Thumbnails...')
        # keep Textures*.db -- clear_all runs unattended behind a progress bar,
        # so there is no restart to pair a DB drop with
        thumbs = clear_thumbnails(drop_texture_db=False)

        progress.close()

        dialog.ok(
            'הצלחה',
            f'{color("הכל נוקה!", COLOR_SUCCESS)}\n\n'
            f'Cache: {cache}\n'
            f'Packages: {packages}\n'
            f'Thumbnails: {thumbs}'
        )
    except Exception as e:
        dialog.ok('שגיאה', str(e))


def fast_exit():
    """Exit Kodi fast. Kodi's native quit waits 5 SECONDS PER python service
    that doesn't stop (wizard/nimbus.helper/all_subs = 15-25s of frozen window
    on every exit, log-measured). Instead: trigger the normal quit -- the
    critical writes (settings save + DB vacuum) complete within ~0.5s of it --
    give it a 3.5s grace, then hard-exit the process. time.sleep is native, so
    Kodi's script-abort cannot interrupt this thread: the os._exit always fires."""
    import time
    log("fast_exit: Quit + 3.5s grace, then hard exit")
    xbmc.executebuiltin('Quit')
    time.sleep(3.5)
    log("fast_exit: grace over, hard-exiting now")
    os._exit(0)


def force_close():
    """Force close Kodi"""
    dialog = xbmcgui.Dialog()

    if dialog.yesno('סגירת Kodi', 'האם לסגור את Kodi?'):
        fast_exit()


# ============================================
# BACKUP MENU
# ============================================
def backup_menu():
    """Backup & Restore menu"""
    dialog = xbmcgui.Dialog()
    
    while True:
        items = [
            menu_item('יצירת גיבוי', 'מהיר (מפתח Gemini | טוקני דבריד | הגדרות | מועדפים) או מלא', 'DefaultAddonService.png'),
            menu_item('שחזור מגיבוי', 'שחזר מפתחות והגדרות אחרי התקנה מחדש', 'DefaultAddonsUpdates.png'),
            menu_item('מחיקת גיבויים', 'ניקוי גיבויים ישנים ופינוי מקום', 'DefaultAddonService.png'),
        ]

        selection = wizard_select(color('גיבוי ושחזור', COLOR_HEADER), items)

        if selection == -1:
            return
        elif selection == 0:
            create_backup()
        elif selection == 1:
            restore_backup()
        elif selection == 2:
            delete_backups()


def create_backup():
    """Create backup (Quick settings/keys or Full userdata)."""
    try:
        from resources.libs import backup
        backup.create_flow()
    except Exception as e:
        log(f"create_backup error: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok('שגיאה', f"{color('הגיבוי נכשל:', COLOR_ERROR)}\n{str(e)}")


def restore_backup():
    """Restore from a saved backup."""
    try:
        from resources.libs import backup
        backup.restore_flow()
    except Exception as e:
        log(f"restore_backup error: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok('שגיאה', f"{color('השחזור נכשל:', COLOR_ERROR)}\n{str(e)}")


def delete_backups():
    """Delete saved backups."""
    try:
        from resources.libs import backup
        backup.manage_flow()
    except Exception as e:
        log(f"delete_backups error: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok('שגיאה', f"{color('שגיאה:', COLOR_ERROR)}\n{str(e)}")


def check_updates_now():
    """Manually trigger the manifest-driven update check.

    The whole build is now delivered from the MasterKodi-IL-Build manifest:
    every addon carries a version + sha256, and the updater fetches only what
    changed, verifies the hash, and installs it. This one button updates Gears,
    the AI subs, skins, the wizard itself -- everything -- in one pass."""
    dialog = xbmcgui.Dialog()
    try:
        from resources.libs import modular_update
        modular_update.check_and_prompt()
    except BaseException as e:
        log(f"check_updates_now error: {e}", xbmc.LOGERROR)
        dialog.ok(ADDON_NAME, f"{color('בדיקת העדכונים נכשלה:', COLOR_ERROR)}\n{str(e)}")


# ============================================
# PARAMETER PARSING
# ============================================
def maintenance_folder():
    """Browsable plugin folder of maintenance actions, for skins whose home shows
    widget folders (AF3/Nimbus) rather than action panels. Each item is a
    non-folder action tile that, when clicked, runs its wizard mode."""
    try:
        handle = int(sys.argv[1])
    except Exception:
        # not called as a directory (e.g. RunPlugin) -> open the dialog instead
        maintenance_menu()
        return
    base = sys.argv[0]
    # skin-independent icons bundled with the wizard (special://skin/ paths only
    # resolve on skins that ship those files -- Nimbus doesn't)
    ICON = 'special://home/addons/plugin.program.masterkodi.il.wizard/resources/art/maint/%s'
    # Content-addon cache tile: POV boxes get the POV cleaner, everyone else
    # keeps the Gears one (fleet default). Detection by installed addon dir.
    _pov_dir = xbmcvfs.translatePath('special://home/addons/plugin.video.pov')
    _has_pov = os.path.isdir(_pov_dir)
    _content_tile = (('ניקוי קאש POV', 'maint_pov', ICON % 'broom.png') if _has_pov
                     else ('ניקוי קאש Gears', 'maint_gears', ICON % 'broom.png'))
    items = [
        _content_tile,
        ('ניקוי קאש Gears AI',  'maint_gearsai', ICON % 'broom-ball.png'),
        ('שלח לוגים לתמיכה',    'send_logs',     ICON % 'circle-info.png'),
        ('עדכון מהיר',          'check_updates', ICON % 'arrows-rotate.png'),
    ]
    xbmcplugin.setContent(handle, 'files')
    for label, mode, icon in items:
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': icon, 'thumb': icon, 'poster': icon})
        li.setProperty('IsPlayable', 'false')
        li.setInfo('video', {'title': label, 'plot': ' '})
        url = '%s?mode=%s' % (base, mode)
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=False)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def maint_pov():
    """Clear POV cache (fire-and-forget for a home tile). Shown on POV boxes."""
    xbmc.executebuiltin('RunPlugin(plugin://plugin.video.pov/?mode=clear_all_cache)')
    xbmcgui.Dialog().notification(ADDON_NAME, 'מנקה קאש POV...', xbmcgui.NOTIFICATION_INFO, 3000)


def maint_gears():
    """Clear Gears cache (fire-and-forget for a home tile)."""
    xbmc.executebuiltin('RunPlugin(plugin://plugin.video.gears/?mode=clear_all_cache)')
    xbmcgui.Dialog().notification(ADDON_NAME, 'מנקה קאש Gears...', xbmcgui.NOTIFICATION_INFO, 3000)


def maint_gearsai():
    """Clear GearsAI cache (fire-and-forget for a home tile)."""
    xbmc.executebuiltin(
        'RunScript(special://home/addons/service.subtitles.gearsai/resources/modules/clean_cache_functions.py,clean_all_cache)')
    xbmcgui.Dialog().notification(ADDON_NAME, 'מנקה קאש Gears AI...', xbmcgui.NOTIFICATION_INFO, 3000)


def parse_params():
    """Parse addon parameters from sys.argv"""
    params = {}
    try:
        log(f"sys.argv = {sys.argv}")
        
        if len(sys.argv) > 2:
            param_string = sys.argv[2]
        elif len(sys.argv) > 1:
            param_string = sys.argv[1]
        else:
            return params
        
        if param_string:
            if param_string.startswith('?'):
                param_string = param_string[1:]
            
            pairs = param_string.split('&')
            for pair in pairs:
                if '=' in pair:
                    key, value = pair.split('=', 1)
                    params[key] = value
                elif pair:
                    params[pair] = 'true'
        
        log(f"Parsed params: {params}")
        
    except Exception as e:
        log(f"Error parsing params: {e}", xbmc.LOGERROR)
    
    return params


# ============================================
# ENTRY POINT
# ============================================
if __name__ == '__main__':
    log(f"Wizard started - v{ADDON_VERSION}")
    
    params = parse_params()
    mode = params.get('mode', '')
    
    if mode == 'builds':
        log("Opening Build Installation directly")
        build_menu()
    elif mode == 'gearsai':
        gearsai_menu()
    elif mode == 'maintenance':
        maintenance_menu()
    elif mode == 'fast_exit':
        fast_exit()
    elif mode == 'maintenance_folder':
        maintenance_folder()
    elif mode == 'maint_pov':
        maint_pov()
    elif mode == 'maint_gears':
        maint_gears()
    elif mode == 'maint_gearsai':
        maint_gearsai()
    elif mode == 'backup':
        backup_menu()
    elif mode == 'check_updates':
        check_updates_now()
    elif mode == 'send_logs':
        from resources.libs import logs
        logs.send_logs()
    elif mode == 'status':
        build_status_menu()
    elif mode == 'skins':
        log("Opening Skins menu directly")
        open_skins_menu()
    else:
        main_menu()
    
    log("Wizard closed")
